# KAON Benchmark — 全局配置 & 版本说明

**版本：** v2.2  
**日期：** 2026年4月  
**作者：** Rian (Product)  
**模型：** Claude Opus 4.6（锁定版本）

---

## 变更记录 v2.1 → v2.2

| 变更 | 理由 |
|------|------|
| D2 Step 1：自由文本散文 → 结构化JSON + 场景描述 | 结构化字段（6个维度）便于Step 2逐项精确比对，同时保留scene_description提供整体语境。输出格式：`{"description": {6字段}, "scene_description": "散文"}` |
| D4：单一整数分数 → 4个子分数加权 | 与D1/D2/D3计算方式对齐，系统侧统一为子项加权求和。输出格式：`{"scores": {"facial_distortion": N, "body_structure": N, "coherence": N, "physics": N}}`，权重0.40/0.30/0.20/0.10 |
| D4：硬惩罚规则更新 | facial_distortion ≤ 1 时整体加权分封顶至1.0（替代原"面部扭曲→整体分封顶"的模糊描述） |
| 全文术语统一 | "对齐度"→"一致性"、"身体比例"→"体型比例"、"散文"→"连续段落"、"按重要性加权"→"按权重排序" |

---

## 变更记录 v2.0 → v2.1

| 变更 | 理由 |
|------|------|
| D1/D3/D4：Section结构对齐DreamBench++格式 | 新增独立的[评分范围]section，每个等级配锚定描述。DreamBench++验证此结构可提升VLM评分稳定性 |
| D1/D2/D3/D4：Prefill新增执行计划+衔接句 | DreamBench++ Self-Alignment机制第二步（总结&规划）：prefill须包含评估步骤计划，并以"请提供需要评估的样本"结尾衔接下一条用户消息 |
| D1/D2/D3：子项权重行内标注 | K-Sort Eval消融实验：在每个子项标签后直接嵌入权重百分比（如"facial (30%)"），使VLM自然分配与权重成比例的注意力，令原始分数更接近后处理加权结果 |
| D1-D4：评分范围采用文本等级锚定 | Q-Align (2312.17090)：离散文本等级（优秀/良好/一般/较差/差）比纯数字分数更贴合VLM的语言先验。即使不做SFT，文本等级提示也能提升zero-shot评分与人类判断的一致性 |
| D3 attractiveness：面���清晰度提升为最高优先 | 线上A/B数据：面部清晰度是用户"喜欢"最强驱动因素——现为子项首条，明确标注为最关键因素 |
| D3 expressiveness：新增角色气质/氛围匹配 | 线上数据：用户需要"感觉上还是那个角色"——不只是正确的表情，还要整体气场匹配 |
| D4：面部完整性提升至检查清单首位 | 线上数据：面部畸变是高敏感度负向因素——用户可以容忍粗糙但不能容忍"脸不对" |
| D4：CoT OFF → CoT ON（缺陷观察引导） | ECCV 2024 (2403.10854)：分步评估 > 整体直接打分。M3-AGIQA (2502.15167)：先描述再打分 +2.3% SRCC。AI结构性缺陷 ≠ 传统IQA——打分前先观察可提升一致性 |
| D4：6个细粒度检查项 → 4个感知类别 | AGHI-QA (2504.21308)：VLM数手指准确率=0.699（接近随机），但整体质量感知SRCC=0.84+。将精确测量任务替换为"这看起来对不对？"的感知判断 |
| D4：输出格式新增缺陷观察（1-3句） | M3-AGIQA：打分前先口头表述观察结果可提升人类一致性。与D3认知观察模式一致 |
| D4：缺陷类别新增权重标注 | facial_distortion (40%) > body_structure (30%) > coherence (20%) > physics (10%)。权重引导VLM注意力分配 |
| D2：单次VLM调用 → 两步流水线（VLM描述 + LLM打分） | 核心���路：同时做跨模态比对（读对话+看图+打分）导致认知过载和确认偏误。拆分为纯视觉描述（Step 1, VLM）+ 纯文本对齐打分（Step 2, LLM）可消除确认偏误，发挥各模型所长 |
| D2 Step 1：VLM仅接收生成图（无对话、无参考图） | 防止确认偏误——VLM无法"看到"对话告诉它应该期待的内容。描述包含角色外貌特征，供下游对齐使用 |
| D2 Step 2：LLM纯文本比对替代VLM跨模态打分 | 文本语义匹配是LLM的成熟能力。评分标准保留（event/scene/emotion/interaction/props），新增对齐分析输出 |
| D2 Step 2：新增"对齐分析"输出（2-3句） | 与D3认知观察、D4缺陷观察模式一致——打分前先口头表述推理可提升人类一致性 |

---

## 通用设置

| 参数 | 值 |
|------|-----|
| 评分刻度 | 每子项0-4整数 |
| 展示映射 | ×2.5线性映射 → 0-10（仅报告层） |
| 模型 | Claude Opus 4.6（锁定版本） |
| ICL | 禁用（不提供示例图片） |

---

## 维度纵览表

| 维度 | 名称 | 权重 | CoT | 子分数 | 输出格式 | 系统输出 | 文件 |
|------|------|------|-----|--------|----------|----------|------|
| D1 | 角色一致性 | 0.30 | 关闭 | facial, hair, eye_color, body, signature | JSON（reasoning+scores） | float 0.0-4.0 | D1_character_consistency.md |
| D2 | 剧情匹配 | 0.30 | 开启（两步式） | event, scene, emotion, props, interaction | Step 1: JSON（description+scene_description，VLM）→ Step 2: JSON（reasoning+scores，LLM） | float 0.0-4.0 | D2_story_match.md |
| D3 | 视觉吸引力 | 0.25 | 开启（认知引导） | attractiveness, expressiveness, composition, color_lighting, finish | JSON（reasoning+scores） | float 0.0-4.0 | D3_visual_appeal.md |
| D4 | 技术质量 | 0.15 | 开启（缺陷观察引导） | facial_distortion, body_structure, coherence, physics | JSON（reasoning+scores） | float 0.0-4.0 | D4_technical_quality.md |

---

## 系统侧计算

```python
# ── 子项权重 ──
DIM1_WEIGHTS = {"facial": 0.30, "hair": 0.30, "eye_color": 0.15, "body": 0.10, "signature": 0.15}
DIM2_WEIGHTS = {"event": 0.30, "scene": 0.25, "emotion": 0.20, "props": 0.10, "interaction": 0.15}
DIM3_WEIGHTS = {"attractiveness": 0.25, "expressiveness": 0.25, "composition": 0.20, "color_lighting": 0.15, "finish": 0.15}
DIM4_WEIGHTS = {"facial_distortion": 0.40, "body_structure": 0.30, "coherence": 0.20, "physics": 0.10}

# ── 维度分数（保持浮点数，仅在报告时四舍五入） ──
dim1_score = sum(sub_scores[k] * DIM1_WEIGHTS[k] for k in DIM1_WEIGHTS)  # float 0.0-4.0
dim2_score = sum(sub_scores[k] * DIM2_WEIGHTS[k] for k in DIM2_WEIGHTS)  # float 0.0-4.0（来自Step 2 LLM输出）
dim3_score = sum(sub_scores[k] * DIM3_WEIGHTS[k] for k in DIM3_WEIGHTS)  # float 0.0-4.0
dim4_score = sum(sub_scores[k] * DIM4_WEIGHTS[k] for k in DIM4_WEIGHTS)  # float 0.0-4.0

# ── 综合分数 ──
composite_raw = dim1_score * 0.30 + dim2_score * 0.30 + dim3_score * 0.25 + dim4_score * 0.15

# ── 硬性惩罚（基于n=99真实数据校准） ──
if dim4_score <= 1.0:
    composite_raw = min(composite_raw, 3.0)
if sub_scores.get("facial_distortion", 4) <= 1:
    dim4_score = min(dim4_score, 1.0)
if dim1_score <= 0.5:
    composite_raw = min(composite_raw, 1.0)

# ── 展示分数 ──
composite_display = round(composite_raw * 2.5, 1)  # 0-10刻度
```

---

## 统一解析器规范

### D1、D2 Step 2、D3、D4：JSON子分数解析器

```python
def parse_sub_scores(raw_output: str, expected_keys: list[str]) -> dict | None:
    """
    解析优先级：
    1. 去除markdown代码围栏（```json ... ```）
    2. 找到包含 {"reasoning": ..., "scores": ...} 的行并解析
    3. 尝试将整个输出解析为单个JSON
    4. 正则回退：提取 {"scores": {...}} 模式
    5. 全部失败 → 返回 None → 标记为 parse_error

    验证：所有expected_keys存在，所有值为0-4整数。
    """
```

**适用于：** D1（keys: facial, hair, eye_color, body, signature）、D2 Step 2（keys: event, scene, emotion, interaction, props）、D3（keys: attractiveness, expressiveness, composition, color_lighting, finish）、D4（keys: facial_distortion, body_structure, coherence, physics）。

### D2 Step 1：结构化视觉分析解析器

```python
def parse_visual_analysis(raw_output: str) -> dict | None:
    """
    解析优先级：
    1. 去除markdown代码围栏
    2. 解析为JSON，验证包含 "description" (dict with 6 keys) 和 "scene_description" (str)
    3. 验证description包含：characters, action, setting, objects, spatial, mood
    4. 全部失败 → 返回 None → 标记为 parse_error

    输出原样传递至Step 2作为输入。
    """
```
