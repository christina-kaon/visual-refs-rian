# KAON Image Generation Benchmark Tool — Claude Code 开发指令 v4

## 项目概述

构建一个完整的Python项目：KAON Image Generation Benchmark Tool。

核心流程：读取测试用例CSV → 调用图像生成API生成图片 → 调用VLM/LLM API对生成图做四维度评分 → 输出HTML可视化报告。

---

## 1. 整体架构

- 完整的Python包，`pip install -e .` 安装，命令行运行
- 项目名：kaon-benchmark
- 入口命令：`kaon-bench run --config config.yaml`
- 异步并发调用API（I/O bound任务，用asyncio + aiohttp）

### 必须支持的CLI参数

```bash
kaon-bench run --config config.yaml                    # 全量运行
kaon-bench run --config config.yaml --limit 20         # 只跑前20条（smoke test）
kaon-bench run --config config.yaml --limit 5 --smoke  # smoke模式：跑5条 + 输出独立smoke报告
kaon-bench run --config config.yaml --resume            # 断点续跑（默认行为）
kaon-bench run --config config.yaml --dims 1,3          # 只跑指定维度
kaon-bench probe --config config.yaml                   # 不跑评测，只用1条probe测试所有API连接和prefill权限
kaon-bench dry-run --config config.yaml                 # 验证prompts可读 + API可连 + CSV可parse，不实际调用API
```

**dry-run模式要求：** 
不消耗任何API调用，只验证四件事：
(1) prompts/目录下所有prompt文件可读且格式正确；
(2) config.yaml里的API endpoint可以ping通（不发实际请求）；
(3) input CSV可正常解析、必填列存在、图片路径可访问；
(4) `tag_registry.yaml` 可读且格式正确。
验证通过输出绿色checkmark，失败输出具体错误信息。

**Smoke模式要求：** `--smoke` 跑完后输出一份独立的 `results/smoke_report.html`，重点展示：每个维度的原始VLM/LLM输出（用于诊断parser bug）、API调用成功/失败统计、各维度分数分布直方图。全量跑之前必须先smoke通过。

---

## 2. 输入格式

CSV文件，列至少包含：

| 列名 | 说明 | 是否必填 |
|------|------|----------|
| test_id | 用例编号 | 必填 |
| character_name | 角色名 | 必填 |
| ref_image_path | 角色参考图路径（本地文件路径或URL） | 必填 |
| prompt | 生图prompt | 必填 |
| dialogue_context | 前5轮对话文本 | 可选，可为空 |
| a_tags | A线标签（image-only），JSON字符串 | 可选 |
| p_tags | P线标签（text-only），JSON字符串 | 可选 |

### 2.1 标签列格式

`a_tags` 和 `p_tags` 列存储JSON字符串，key为标签维度名，value为标签值字符串。

**CSV示例：**
```csv
test_id,character_name,ref_image_path,prompt,dialogue_context,a_tags,p_tags
001,Luna,refs/luna.png,a girl in a garden,,"{""category"":""Anime"",""gender_age"":""bishojo"",""hair_color_family"":""pink"",""eye_color"":""blue"",""outfit"":""school_uniform"",""accessories"":""hair_ribbon""}","{""genre"":""romance"",""setting"":""garden"",""mood"":""romantic"",""composition"":""solo"",""pose"":""standing"",""shot_angle"":""mid_shot"",""rating"":""general"",""scene_archetype"":""solitary_moment""}"
```

**关键规则：**
- 每张图片不一定打满所有维度的标签，JSON中只包含实际打了的维度，缺失维度不出现在JSON中（不填 `null` 或空字符串）
- `a_tags` / `p_tags` 列可以整列缺失（早期数据可能没打标），代码当空dict `{}` 处理
- 多值标签（如 `accessories` 一个角色可能有多个配饰）：value用逗号分隔的字符串，如 `"earrings,necklace,tattoo"`，代码解析时按逗号split

### 2.2 向后兼容旧标签格式

如果CSV中仍存在旧的 `style_tag` / `category_tag` 列（而没有 `a_tags` / `p_tags`），代码自动映射：

```python
# 向后兼容逻辑
if "a_tags" not in csv_columns and "style_tag" in csv_columns:
    a_tags = {"category": row["style_tag"]} if row["style_tag"] else {}
if "p_tags" not in csv_columns and "category_tag" in csv_columns:
    p_tags = {"genre": row["category_tag"]} if row["category_tag"] else {}
```

**通用兼容原则不变：** CSV里的列数和内容可能随时间变化（比如初期可能没有dialogue_context列），代码要兼容——缺失的列当空值处理，不要报错。测试用例数量从20条到1000条不等，要能灵活适配。

---

## 3. 图像生成

- 通过公司API中转平台调用图像生成模型（自研模型和闭源对比模型）
- API连接方式在config.yaml里配置（base_url, api_key, model_name等）
- 支持配置多个生成模型，对同一条用例分别生成，用于横向对比
- 生成的图片保存到本地output目录，按 `model_name/test_id/` 命名

---

## 4. 评分系统

### 4.0 通用规则

**四个评分维度，每个维度独立调用VLM/LLM API。**

- **评分prompt已经写好**，每个维度/步骤一个YAML文件，代码从YAML读取，**不要把prompt硬编码在代码里**
- 每个YAML文件结构：

```yaml
# prompts/dim1.yaml 示例
instruction: |
  [任务说明]
  你是一名角色扮演聊天应用中角色一致性生图的专业评估员...
  ...完整的evaluation instruction...

prefill: |
  好的，我理解任务。任务是根据五个具体特征...
  ...完整的assistant prefill...

trigger: "请根据上述指令提供评分结果。"
```

- 三个字段：`instruction`（评分指令）、`prefill`（助手预填）、`trigger`（第三条user message）
- D2因为是两步pipeline，拆成两个文件：`dim2_step1.yaml` 和 `dim2_step2.yaml`

**Prompt文件清单：**
```
prompts/
├── dim1.yaml            # D1 角色一致性
├── dim2_step1.yaml      # D2 Step 1 视觉场景描述（VLM）
├── dim2_step2.yaml      # D2 Step 2 剧情对齐打分（LLM）
├── dim3.yaml            # D3 视觉吸引力
└── dim4.yaml            # D4 技术质量
```

### 4.1 各维度图片输入规则

**不同维度传入的图片数量和类型不同，代码必须根据维度区分处理：**

| 维度/步骤 | 输入图片 | 说明 |
|-----------|----------|------|
| D1 角色一致性 | 参考图 + 生成图 | 两张图都在user message中，参考图在前 |
| D2 Step 1 视觉描述 | 仅生成图 | 不传参考图、不传对话上下文（防止确认偏误） |
| D2 Step 2 对齐打分 | 无图片（纯文本） | 输入是Step 1的文本输出 + 对话上下文 |
| D3 视觉吸引力 | 参考图 + 生成图 | 参考图用于风格参考，参考图在前 |
| D4 技术质量 | 仅生成图 | 只检测技术缺陷，不需要参考图 |

### 4.2 各维度API调用结构

**所有维度/步骤统一使用三消息 + 助手预填结构：**

```python
messages = [
    {"role": "user", "content": [instruction + 图片（按维度规则）]},
    {"role": "assistant", "content": prefill},
    {"role": "user", "content": trigger}
]
```

- instruction、prefill、trigger 均从对应YAML文件读取
- D2 Step 2 的 user message 中，instruction 后面拼接 Step 1 的结构化输出 + 对话上下文（不含图片）

### 4.3 维度1：角色一致性（D1，权重 0.30，CoT OFF）

- 三消息结构，输入参考图 + 生成图
- 输出：一行JSON，仅含scores，**无reasoning**
- 输出格式：`{"scores": {"facial": N, "hair": N, "eye_color": N, "body": N, "signature": N}}`
- 子项权重：

```python
DIM1_WEIGHTS = {
    "facial": 0.30,
    "hair": 0.30,
    "eye_color": 0.15,
    "body": 0.10,
    "signature": 0.15
}
```

### 4.4 维度2：剧情匹配（D2，权重 0.30，CoT ON — 两步pipeline）

**D2是唯一的两步pipeline维度，代码结构与其他维度不同。**

#### Step 1：视觉场景描述（VLM调用）

- 三消息结构，**仅输入生成图**（不传参考图、不传对话上下文）
- 输出：结构化JSON，包含6字段描述 + 连续场景描述
- 输出格式：
```json
{
  "description": {
    "characters": "...",
    "action": "...",
    "setting": "...",
    "objects": "...",
    "spatial": "...",
    "mood": "..."
  },
  "scene_description": "80-150词的连续场景描述"
}
```
- 使用专用parser `parse_visual_analysis()` 解析（见5.3节）

#### Step 2：剧情对齐打分（LLM调用）

- 三消息结构，**纯文本，不传图片**
- user message内容：instruction + Step 1的完整JSON输出 + 对话上下文（dialogue_context）
- 输出：JSON，包含reasoning + scores
- 输出格式：
```json
{
  "reasoning": "2-3句对齐分析",
  "scores": {"event": N, "scene": N, "emotion": N, "interaction": N, "props": N}
}
```
- 子项权重：

```python
DIM2_WEIGHTS = {
    "event": 0.30,
    "scene": 0.25,
    "emotion": 0.20,
    "props": 0.10,
    "interaction": 0.15
}
```

#### D2 执行逻辑

```python
# Step 1: VLM视觉描述
step1_raw = await call_vlm(dim2_step1_prompt, images=[generated_image])
step1_parsed = parse_visual_analysis(step1_raw)

if step1_parsed is None:
    # Step 1 parse失败 → 重试（最多3次）
    # 3次均失败 → 该条D2标记为error，跳过

# Step 2: LLM对齐打分
step2_input = format_step2_input(step1_parsed, dialogue_context)
step2_raw = await call_llm(dim2_step2_prompt, text_input=step2_input)
step2_parsed = parse_sub_scores(step2_raw, expected_keys=["event","scene","emotion","interaction","props"])

if step2_parsed is None:
    # Step 2 parse失败 → 重试（最多3次）
    # 3次均失败 → 该条D2标记为error，跳过
```

- Step 1或Step 2任一步失败均重试3次，仍失败则该条D2评测标记为error，直接跳到下一条
- 断点续跑需要记录Step 1的中间结果：如果Step 1已成功但Step 2失败，续跑时跳过Step 1直接重跑Step 2

### 4.5 维度3：视觉吸引力（D3，权重 0.25，CoT ON — 认知引导）

- 三消息结构，输入参考图 + 生成图
- CoT ON：prefill引导VLM按认知路径（入口点→引导路径→视觉层次）评估
- 输出：JSON，包含reasoning + scores
- 输出格式：
```json
{
  "reasoning": "2-3句认知观察",
  "scores": {"attractiveness": N, "expressiveness": N, "composition": N, "color_lighting": N, "finish": N}
}
```
- 子项权重：

```python
DIM3_WEIGHTS = {
    "attractiveness": 0.25,
    "expressiveness": 0.25,
    "composition": 0.20,
    "color_lighting": 0.15,
    "finish": 0.15
}
```

### 4.6 维度4：技术质量（D4，权重 0.15，CoT ON — 缺陷观察引导）

- 三消息结构，**仅输入生成图**
- CoT ON：prefill引导VLM按权重顺序扫描缺陷类别
- 输出：JSON，包含reasoning + scores
- 输出格式：
```json
{
  "reasoning": "1-3句缺陷观察",
  "scores": {"facial_distortion": N, "body_structure": N, "coherence": N, "physics": N}
}
```
- 子项权重：

```python
DIM4_WEIGHTS = {
    "facial_distortion": 0.40,
    "body_structure": 0.30,
    "coherence": 0.20,
    "physics": 0.10
}
```

### 4.7 综合分计算与硬惩罚

```python
# ── 维度加权分（float 0.0-4.0）──
dim1_score = sum(sub_scores[k] * DIM1_WEIGHTS[k] for k in DIM1_WEIGHTS)
dim2_score = sum(sub_scores[k] * DIM2_WEIGHTS[k] for k in DIM2_WEIGHTS)  # 来自Step 2
dim3_score = sum(sub_scores[k] * DIM3_WEIGHTS[k] for k in DIM3_WEIGHTS)
dim4_score = sum(sub_scores[k] * DIM4_WEIGHTS[k] for k in DIM4_WEIGHTS)

# ── 硬惩罚（执行顺序严格固定，不可调换）──
# 第一步：facial_distortion子分 ≤ 1 → D4维度分封顶至1.0
if sub_scores.get("facial_distortion", 4) <= 1:
    dim4_score = min(dim4_score, 1.0)

# 第二步：计算composite，然后检查D4封顶
composite_raw = dim1_score * 0.30 + dim2_score * 0.30 + dim3_score * 0.25 + dim4_score * 0.15
if dim4_score <= 1.0:
    composite_raw = min(composite_raw, 3.0)

# 第三步：D1维度分 ≤ 0.5 → composite封顶至1.0
if dim1_score <= 0.5:
    composite_raw = min(composite_raw, 1.0)

# ── 展示分数 ──
composite_display = round(composite_raw * 2.5, 1)  # 0.0-10.0
```

**关键：**
- 所有维度分数保持float，不做round，直到最终reporting层才round
- 硬惩罚的执行顺序必须严格按上述1→2→3顺序，因为第一步的封顶可能触发第二步
- composite_raw先计算，然后被惩罚规则覆盖

---

## 5. 模型连接与容错

### 5.1 Probe & Fallback

- `kaon-bench probe` 命令：用1条dummy请求测试所有配置的API连接，验证：
  - 图像生成API是否能正常返回图片
  - VLM API是否能正常返回评分
  - **VLM是否支持assistant prefill（3-message结构）**——如果返回400，自动报告"prefill not supported for this model"
  - **所有维度独立配置的模型均需probe**——包括D2 Step 2的LLM
- config.yaml的每个evaluator配置支持 `model_fallback` 列表：

```yaml
evaluator:
  default:
    base_url: "https://xxx"
    api_key: "${VLM_API_KEY}"
    model: "claude-opus-4-6"
    model_fallback:
      - "claude-haiku-4-5-20251001"
      - "gpt-4o-2024-08-06"
```

- probe时如果主模型不可用，自动尝试fallback列表，使用第一个通过probe的模型

### 5.2 图片格式嗅探

- **不信任文件扩展名。** 使用 `filetype` 库或读取文件前几个字节做magic-byte检测，确定真实的content-type
- 支持的格式：PNG, JPEG, WebP, GIF
- 如果检测到的真实格式和扩展名不一致，以真实格式为准
- 如果格式不在支持列表内，标记为error并跳过

### 5.3 Parser规范

#### 统一JSON子分数Parser（D1 / D2 Step 2 / D3 / D4）

```python
def parse_sub_scores(raw_output: str, expected_keys: list[str]) -> dict | None:
    """
    解析优先级：
    1. 去除markdown代码围栏（```json ... ```）
    2. 找到包含 {"reasoning": ..., "scores": ...} 或 {"scores": ...} 的行并解析
    3. 尝试将整个输出解析为单个JSON
    4. 正则回退：提取 {"scores": {...}} 模式
    5. 全部失败 → 返回 None → 标记为 parse_error

    验证：所有expected_keys存在于scores中，所有值为0-4整数。
    reasoning字段如存在则一并返回，不存在也不报错（D1无reasoning）。
    
    返回格式：{"scores": {...}, "reasoning": "..." | None}
    """
```

**各维度expected_keys：**
- D1: `["facial", "hair", "eye_color", "body", "signature"]`
- D2 Step 2: `["event", "scene", "emotion", "interaction", "props"]`
- D3: `["attractiveness", "expressiveness", "composition", "color_lighting", "finish"]`
- D4: `["facial_distortion", "body_structure", "coherence", "physics"]`

#### D2 Step 1 专用Parser

```python
def parse_visual_analysis(raw_output: str) -> dict | None:
    """
    解析优先级：
    1. 去除markdown代码围栏
    2. 解析为JSON
    3. 验证包含 "description" (dict) 和 "scene_description" (str)
    4. 验证 description 包含6个key: characters, action, setting, objects, spatial, mood
    5. 全部失败 → 返回 None → 标记为 parse_error

    输出原样传递至Step 2作为输入文本。
    """
```

- Parse失败不crash，标记为 `parse_error`，该条用例的对应维度分数记为None
- Smoke报告里要展示所有原始VLM/LLM输出，方便诊断parser问题

### 5.4 NSFW Refuse检测

- 某些API对NSFW内容会直接refuse整个请求（不是打低分，是拒绝回答）
- evaluator.py必须检测refuse response（通常包含 "I cannot" / "I'm unable" / "content policy" / safety相关的拒绝文本）
- Refuse是独立的failure mode，不混入正常分数
- 在结果CSV中标记为 `nsfw_refused`，在报告中单独统计refuse率

### 5.5 并发与重试

- 基于 `asyncio` + `aiohttp` 的异步并发
- 可配置的并发数（默认10）
- **Exponential backoff with jitter：** 不要用固定delay，按response header的 `retry-after` 做退避，如果没有retry-after header则用 `min(2^attempt * base_delay + random_jitter, max_delay)` 策略
- 429/5xx 自动重试，最多retry_count次（默认3）
- 其他错误（400 bad request等）不重试，直接标记为error
- **D2特殊处理：** Step 1或Step 2任一步失败均重试3次，仍失败则该条D2评测标记为error，跳到下一条

### 5.6 断点续跑

- **使用JSONL格式（append-only），不用JSON文件**，避免多协程并发写冲突
- 每完成一条用例的一个维度（或子步骤），立即append一行到 `results/progress.jsonl`
- **D2的进度粒度：** 分别记录Step 1和Step 2。格式：
  - Step 1完成：`{"test_id": "xxx", "model": "xxx", "dim": "d2_step1", "result": {...}, "status": "success"}`
  - Step 2完成：`{"test_id": "xxx", "model": "xxx", "dim": "d2_step2", "result": {...}, "status": "success"}`
- 重新运行时读取progress.jsonl，跳过已完成的组合。D2续跑时：如果Step 1已成功但Step 2失败，直接从Step 1的缓存结果重跑Step 2
- 进度条显示（用rich库，展示总进度+当前阶段）

---

## 6. 标签系统

### 6.1 标签注册表（tag_registry.yaml）

项目根目录新增 `tag_registry.yaml`，描述所有标签维度的元信息。代码启动时加载。

**作用：**
1. 报告生成时，知道有哪些维度可以做聚类分析
2. 定义每个维度的显示名和所属线（A/P）
3. 定义哪些维度在用例详情表主表中展示（`pinned: true`）
4. 未来新增维度只需编辑这个文件，不改代码

**文件结构：**

```yaml
# tag_registry.yaml

# pinned: true 的维度会出现在用例详情表的主表列中（建议不超过3个）
# line: A（image-only）或 P（text-only）
# multi_value: true 表示该维度可能有多个值（逗号分隔）

a_line:
  - key: category
    display_name: "渲染管线"
    pinned: true
    multi_value: false
  - key: game_ip_style
    display_name: "IP源流"
    pinned: false
    multi_value: false
  - key: gender_age
    display_name: "性别×年龄"
    pinned: false
    multi_value: false
  - key: body_shape
    display_name: "体型"
    pinned: false
    multi_value: false
  - key: skin_tone
    display_name: "肤色"
    pinned: false
    multi_value: false
  - key: hair_length
    display_name: "发型/发长"
    pinned: false
    multi_value: false
  - key: hair_color_family
    display_name: "发色"
    pinned: false
    multi_value: false
  - key: eye_color
    display_name: "瞳色"
    pinned: false
    multi_value: false
  - key: outfit
    display_name: "服装"
    pinned: false
    multi_value: false
  - key: accessories
    display_name: "配饰"
    pinned: false
    multi_value: true
  - key: expression
    display_name: "表情"
    pinned: false
    multi_value: false

p_line:
  - key: genre
    display_name: "题材"
    pinned: true
    multi_value: false
  - key: setting
    display_name: "场景"
    pinned: false
    multi_value: false
  - key: time_of_day
    display_name: "时段"
    pinned: false
    multi_value: false
  - key: weather
    display_name: "天气"
    pinned: false
    multi_value: false
  - key: composition
    display_name: "人数构图"
    pinned: false
    multi_value: false
  - key: pose
    display_name: "姿态"
    pinned: false
    multi_value: false
  - key: shot_angle
    display_name: "景别"
    pinned: false
    multi_value: false
  - key: rating
    display_name: "NSFW等级"
    pinned: true
    multi_value: false
  - key: mood
    display_name: "情绪基调"
    pinned: false
    multi_value: false
  - key: interaction
    display_name: "互动模式"
    pinned: false
    multi_value: false
  - key: scene_archetype
    display_name: "场景原型"
    pinned: false
    multi_value: false
  - key: pose_detail
    display_name: "动作细节"
    pinned: false
    multi_value: false
```

**代码读取逻辑：**
- 启动时从项目根目录加载 `tag_registry.yaml`，获取所有维度定义
- 如果registry中没有的key出现在CSV的JSON中，不报错，正常保留（前向兼容——先打标后更新registry的情况）
- `pinned: true` 的维度出现在用例详情表主表列中
- **代码不应硬编码任何标签维度名或标签值。** 所有维度信息从 `tag_registry.yaml` 读取，所有标签值从数据中动态提取

### 6.2 标签聚合函数

报告生成时，需要一个统一的标签聚合函数，被热力图和薄弱项总结共用：

```python
def aggregate_scores_by_tag(
    results: list[dict],        # 所有用例结果
    tag_line: str,              # "a" 或 "p"
    tag_key: str,               # 标签维度key，如 "category"、"genre"
    score_key: str,             # 分数字段，如 "composite_raw"、"dim1_score"
    min_samples: int = 5        # 最低样本数
) -> list[dict]:
    """
    按指定标签维度聚合分数。
    
    处理逻辑：
    1. 从每条结果的 a_tags/p_tags JSON 中提取 tag_key 对应的值
    2. 如果是 multi_value 维度（如 accessories），按逗号 split 后每个值单独计入
    3. 按标签值分组，计算平均分和样本数
    4. 过滤掉样本数 < min_samples 的组
    5. 返回 [{"tag_value": "...", "mean_score": ..., "count": ...}, ...]
    """
```

---

## 7. 输出

### 7.1 原始数据

`results/raw_scores.csv`——每行一条用例，包含：

- 所有原始CSV列（包括 `a_tags`、`p_tags` JSON字符串原样保留）
- model_name
- pinned_category（从 `a_tags` JSON中提取的 `category` 值，冗余平铺列，方便Excel筛选）
- pinned_genre（从 `p_tags` JSON中提取的 `genre` 值）
- pinned_rating（从 `p_tags` JSON中提取的 `rating` 值）
- dim1_score（0-4 float，加权后）
- dim1_sub_scores（JSON字符串：`{"facial":N,"hair":N,"eye_color":N,"body":N,"signature":N}`）
- dim2_score（0-4 float，加权后，来自Step 2）
- dim2_sub_scores（JSON字符串：`{"event":N,"scene":N,"emotion":N,"interaction":N,"props":N}`）
- dim2_step1_description（JSON字符串，Step 1的完整结构化输出）
- dim2_reasoning（字符串，Step 2的reasoning文本）
- dim3_score（0-4 float，加权后）
- dim3_sub_scores（JSON字符串：`{"attractiveness":N,"expressiveness":N,"composition":N,"color_lighting":N,"finish":N}`）
- dim3_reasoning（字符串，D3的认知观察）
- dim4_score（0-4 float，加权后，已应用facial_distortion封顶）
- dim4_sub_scores（JSON字符串：`{"facial_distortion":N,"body_structure":N,"coherence":N,"physics":N}`）
- dim4_reasoning（字符串，D4的缺陷观察）
- composite_raw（0-4 float，已应用硬惩罚）
- composite_display（0-10 float，round到1位小数）
- 每个维度的status（success / error / parse_error / nsfw_refused）
- penalty_applied（JSON字符串，记录触发了哪些硬惩罚规则，如 `{"facial_distortion_cap": true, "dim4_cap": true, "dim1_cap": false}`）

### 7.2 HTML可视化报告

`results/report.html`，**单文件自包含**（CSS/JS全部内联），**chart-heavy, prose-minimal**设计原则。使用Chart.js内联。

#### 页面结构：

**Section 1: 摘要仪表盘**
- 4个大数字卡片：总用例数、成功率、平均综合分（0-10）、error/refuse数量
- 4个仪表盘（gauge chart）：四个维度的平均分，颜色编码（红<1.5, 黄1.5-2.5, 绿>2.5，按0-4标尺）

**Section 2: 模型对比（如有多个生成模型）**
- 分组柱状图：X轴=模型名，Y轴=分数，4组柱子分别代表4个维度
- Radar/雷达图：每个模型一个多边形，4个轴=4个维度

**Section 3: 标签聚类分析**

分为两个子区域：

**3a. Top/Bottom 标签卡片（自动计算，无需用户操作）**

报告加载时自动遍历所有标签维度的所有标签值，计算每个标签值对应用例的平均 composite_display，过滤样本数 < 5 的标签值。展示两组卡片：

- **"表现最好的标签"（绿色区域，3-5个）：** 平均分最高的标签值，格式 `[维度显示名]: [标签值] — 平均分 X.X（N条用例）`
- **"表现最差的标签"（红色区域，3-5个）：** 平均分最低的标签值，同上格式

示例效果：
```
🟢 表现最好                          🔴 表现最差
渲染管线: Anime — 8.2 (142条)         姿态: fighting — 4.1 (23条)
题材: romance — 7.9 (89条)            景别: from_below — 4.5 (15条)
情绪基调: romantic — 7.8 (67条)       人数构图: group — 4.8 (31条)
```

**3b. 交互式热力图**

在Top/Bottom卡片下方：

- **下拉选择器：** 选择标签维度，按A线/P线分组，显示display_name。默认选中 `category`（A线第一个维度）
- **热力图区域：**
  - X轴 = 选中维度的所有标签值（从数据中动态提取，按样本数降序排列）
  - Y轴 = 四个评分维度（D1 角色一致性 / D2 剧情匹配 / D3 视觉吸引力 / D4 技术质量）
  - 颜色 = 平均分（0-4标尺，红<1.5 黄1.5-2.5 绿>2.5）
  - 每个格子tooltip显示：标签值、维度名、平均分、样本数
- **样本数过滤器：** slider或输入框，最低样本数 ≥ N，默认5，过滤掉样本不足的标签值
- **技术实现：** 数据全部内联在HTML中（JS对象），下拉切换时JS动态重绘。热力图用原生HTML table + CSS背景色实现（比Chart.js matrix插件更轻量，适合单文件自包含）

**Section 4: 分布与异常值**
- 每个维度的分数分布直方图（0/1/2/3/4各多少条）
- 综合分分布直方图
- Scatter plot：X轴=dim1, Y轴=dim3（角色一致性 vs 视觉吸引力），点的颜色=综合分，方便发现"角色像但不好看"或"好看但不像"的case
- D4子分数分布：facial_distortion的分数分布（重点关注≤1的占比，即触发硬惩罚的比例）

**Section 5: 用例详情表**
- 使用 DataTables（从CDN内联引入 https://cdn.datatables.net）实现搜索和排序，不要手写JS
- 可搜索（按test_id, character_name, 以及pinned标签列过滤）
- 可排序（按任意维度分数或综合分排序）
- 主表每行展示：test_id、character_name、ref图缩略图（64px）、生成图缩略图（64px）、**pinned标签列**（默认3列：category、genre、rating，从registry的 `pinned: true` 维度动态生成）、4个维度分数（颜色编码）、综合分、status、是否触发硬惩罚（图标标注）
  - pinned标签列的值从 `a_tags` / `p_tags` JSON中提取对应key，如果缺失显示 `—`
- **点击行可展开：**
  - 大图对比（ref vs generated并排）
  - 完整dialogue_context
  - 各维度子分数明细
  - **reasoning文本**（D2显示对齐分析、D3显示认知观察、D4显示缺陷观察；D1无reasoning则不显示）
  - D2 Step 1的场景描述
  - **标签信息**（新增区域）：按A线/P线分组展示该用例的全部标签。每个维度显示 `display_name: value` 格式，只展示实际有值的维度，多值标签用逗号+空格分隔。示例：
    ```
    ── 标签信息 ──
    A线（角色特征）：
      渲染管线: Anime | IP源流: otome_anime | 性别×年龄: bishojo | 体型: slim
      肤色: fair | 发型: long | 发色: pink | 瞳色: blue
      服装: school_uniform | 配饰: hair_ribbon, earrings | 表情: soft_smile

    P线（场景特征）：
      题材: romance | 场景: garden | 时段: afternoon | 天气: sunny
      人数构图: solo | 姿态: standing | 景别: mid_shot | NSFW等级: general
      情绪基调: romantic | 互动模式: solo | 场景原型: solitary_moment | 动作细节: none
    ```
  - 如果有error/refuse展示原因
- 默认按综合分升序（最差的排最前面，方便找badcase）

**Section 6: 薄弱项总结**
- 自动列出综合分最低的10%用例（表格形式，含缩略图）
- **标签维度薄弱项：** 遍历所有标签维度，对每个维度找出平均composite最低的标签值（样本数 ≥ 5），按平均分升序排列，展示前10个最差的（维度显示名、标签值、平均分、样本数）。数据与Section 3 Top/Bottom卡片一致，但展示更多条目并附带受影响的用例列表
- 如有NSFW refuse，单独列出refuse率和受影响的用例
- 硬惩罚触发统计：多少条用例触发了facial_distortion封顶、D4封顶、D1封顶

### 7.3 Smoke报告（--smoke模式专用）

`results/smoke_report.html`，重点不同于全量报告：

- API连接状态：每个API endpoint的probe结果（成功/失败/延迟ms），包括各维度独立配置的模型
- **每条用例的原始输出全文**（D2展示Step 1和Step 2两步的原始输出）
- Parser解析结果：原始输出 → 解析出的分数/描述，高亮任何parse失败的case
- 每个维度的分数分布（即使只有5-20条也画直方图，看分布是否合理）
- reasoning文本展示（验证reasoning内容是否合理）

---

## 8. Config文件结构

```yaml
# 图像生成模型（支持多个，用于横向对比）
generators:
  - name: "kaon_v1.5"
    base_url: "https://xxx"
    api_key: "${KAON_API_KEY}"
    model: "kaon-image-v1.5"
  - name: "baseline_gpt4o"
    base_url: "https://xxx"
    api_key: "${BASELINE_API_KEY}"
    model: "gpt-4o-image"

# VLM/LLM评分模型配置
# default: 所有维度的默认模型
# 可按维度覆盖：dim1 / dim2_step1 / dim2_step2 / dim3 / dim4
evaluator:
  default:
    base_url: "https://xxx"
    api_key: "${VLM_API_KEY}"
    model: "claude-opus-4-6"
    model_fallback:
      - "claude-haiku-4-5-20251001"
      - "gpt-4o-2024-08-06"

  # 可选：按维度/步骤覆盖默认模型（不配则用default）
  # dim1:
  #   base_url: "https://xxx"
  #   api_key: "${VLM_API_KEY}"
  #   model: "claude-opus-4-6"
  # dim2_step1:
  #   model: "claude-opus-4-6"
  # dim2_step2:
  #   base_url: "https://xxx"
  #   api_key: "${LLM_API_KEY}"
  #   model: "claude-opus-4-6"    # 纯文本LLM，可配置不同模型
  # dim3:
  #   model: "claude-opus-4-6"
  # dim4:
  #   model: "gpt-4o-2024-08-06"

# 运行参数
concurrency: 10
retry_count: 3
backoff_base_delay: 1.0    # 秒，exponential backoff的基础延迟
backoff_max_delay: 60.0    # 秒，最大延迟
input_csv: "data/test_cases.csv"
output_dir: "results/"
prompts_dir: "prompts/"
images_dir: "generated_images/"
```

**Config加载逻辑：**
- evaluator配置合并规则：维度配置继承default的所有字段，仅覆盖显式指定的字段
- 例如dim4只配了model，则base_url和api_key从default继承
- 环境变量展开：`${VAR_NAME}` 从环境变量读取

---

## 9. 项目结构

```
kaon-benchmark/
├── pyproject.toml
├── README.md
├── config.yaml
├── tag_registry.yaml        # 标签维度元信息注册表（A线/P线所有维度定义）
├── prompts/
│   ├── dim1.yaml            # D1 角色一致性（instruction + prefill + trigger）
│   ├── dim2_step1.yaml      # D2 Step 1 视觉场景描述
│   ├── dim2_step2.yaml      # D2 Step 2 剧情对齐打分
│   ├── dim3.yaml            # D3 视觉吸引力
│   └── dim4.yaml            # D4 技术质量
├── data/
│   └── test_cases.csv       (示例文件，5条sample数据，含a_tags/p_tags列)
├── src/
│   └── kaon_benchmark/
│       ├── __init__.py
│       ├── cli.py            # 命令行入口（run / probe / dry-run / --smoke / --limit / --dims）
│       ├── config.py          # 配置加载 + 环境变量展开 + 维度模型合并逻辑
│       ├── tag_registry.py    # 标签注册表加载 + 标签解析 + 聚合函数
│       ├── probe.py           # API连接测试 + prefill权限验证（覆盖所有维度配置的模型）
│       ├── generator.py       # 图像生成调用
│       ├── evaluator.py       # VLM/LLM评分调用（四维度 + D2两步pipeline + NSFW refuse检测）
│       ├── parser.py          # VLM/LLM输出解析（parse_sub_scores + parse_visual_analysis）
│       ├── scorer.py          # 综合分计算（子项加权 + 硬惩罚三步逻辑）
│       ├── progress.py        # JSONL断点续跑管理（支持D2子步骤粒度）
│       ├── reporter.py        # HTML全量报告生成（Chart.js内联，含标签聚类分析 + reasoning展示）
│       ├── smoke_reporter.py  # HTML smoke报告生成（含D2两步原始输出）
│       └── utils.py           # 图片magic-byte嗅探、base64编码、backoff逻辑
└── results/
    └── .gitkeep
```

---

## 10. 重点注意事项

1. **Prompt内容不要硬编码**，从prompts/目录的YAML文件读取，每个YAML包含instruction、prefill、trigger三个字段
2. **CSV列要兼容缺失**，缺失列当空值处理不报错；`a_tags`/`p_tags` 列缺失时当空dict处理
3. **标签系统向后兼容**：如果CSV中有旧的 `style_tag`/`category_tag` 列但没有 `a_tags`/`p_tags`，自动映射为 `a_tags: {"category": style_tag}` 和 `p_tags: {"genre": category_tag}`
4. **标签维度不硬编码**：所有维度信息从 `tag_registry.yaml` 读取，标签值从数据中动态提取。新增/删除维度只改registry文件，不改代码
5. **多值标签**（如accessories）按逗号split，聚合统计时每个值单独计入
6. **断点续跑用JSONL append-only**，不用JSON覆盖写；D2记录Step 1和Step 2两步进度
7. **图片格式用magic-byte嗅探**，不信任扩展名
8. **不同维度传不同图片**：D1/D3传参考图+生成图，D2 Step 1/D4只传生成图，D2 Step 2不传图片
9. **D2是两步pipeline**：Step 1（VLM视觉描述）→ Step 2（LLM文本对齐打分），任一步失败重试3次后标记error跳过
10. **所有维度统一用JSON parser**（parse_sub_scores），D2 Step 1用专用parser（parse_visual_analysis）；parse失败不crash
11. **D4从单分数变为4个子分数**，使用加权计算，加上facial_distortion硬惩罚封顶
12. **硬惩罚三步逻辑执行顺序严格固定**：①facial_distortion≤1→D4封顶1.0 ②D4≤1.0→composite封顶3.0 ③D1≤0.5→composite封顶1.0
13. **NSFW refuse要作为独立failure mode检测**，不混入正常分数
14. **重试用exponential backoff with jitter**，不用固定delay
15. **HTML报告chart-heavy prose-minimal**，用Chart.js内联，单文件自包含；Section 3用CSS table热力图（不用Chart.js matrix插件）；用例展开后显示reasoning文本和完整标签信息
16. **evaluator支持按维度独立配置模型**，不配则用default，配了则覆盖（继承未指定字段）
17. **raw_scores.csv输出**：保留 `a_tags`/`p_tags` JSON列原样输出，新增 `pinned_category`/`pinned_genre`/`pinned_rating` 三个冗余平铺列
18. **dry-run验证**增加 `tag_registry.yaml` 可读性检查
19. **先跑 `kaon-bench probe` 验证所有API连接，再跑 `--smoke --limit 5` 验证全流程，最后才跑全量**
20. 请生成完整的项目代码，包括pyproject.toml、README（含quick start步骤）、示例config、示例tag_registry.yaml、示例CSV（含a_tags/p_tags）和示例prompt YAML文件
