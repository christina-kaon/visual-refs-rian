#!/usr/bin/env python3
from collections import defaultdict
import csv, sys

style = {}
with open('/tmp/persona_split/bot_style.tsv') as f:
    next(f)
    for line in f:
        parts = line.rstrip('\n').split('\t')
        if len(parts) >= 2 and parts[1] in ('anime','realistic'):
            style[parts[0]] = parts[1]

tags = {}
with open('/tmp/persona_split/bot_tags_classified.tsv') as f:
    for line in f:
        parts = line.rstrip('\n').split('\t')
        if len(parts) < 5: continue
        tags[parts[0]] = {'v8p': parts[1] if parts[1] != 'NULL' else '_未分类',
                          'title': parts[3], 'lang': parts[4]}

# style × v8_primary 聚合
agg = defaultdict(lambda: {'chats':0, 'bots':set(), 'female':0, 'male':0,
                            '18_25':0, '26_30':0, '30plus':0,
                            'country':defaultdict(int)})

bot_chats = defaultdict(lambda: {'chats':0, 'female':0, 'male':0, 'country':defaultdict(int)})

with open('/tmp/persona_split/persona_classified.tsv') as f:
    for line in f:
        parts = line.rstrip('\n').split('\t')
        if len(parts) < 5: continue
        pid, g, a, c = parts[0], parts[1], parts[2], parts[3]
        try: chats = int(parts[4])
        except: continue
        if pid not in style: continue
        s = style[pid]
        t = tags.get(pid, {}).get('v8p', '_未分类')
        key = (s, t)
        agg[key]['chats'] += chats
        agg[key]['bots'].add(pid)
        if g == 'Female': agg[key]['female'] += chats
        elif g == 'Male': agg[key]['male'] += chats
        if a == '18-25': agg[key]['18_25'] += chats
        elif a == '26-30': agg[key]['26_30'] += chats
        elif a == '30+': agg[key]['30plus'] += chats
        agg[key]['country'][c] += chats
        # bot-level
        bot_chats[pid]['chats'] += chats
        if g == 'Female': bot_chats[pid]['female'] += chats
        elif g == 'Male': bot_chats[pid]['male'] += chats
        bot_chats[pid]['country'][c] += chats

# 输出 style × primary_tag 表
with open('/tmp/persona_split/style_tag_breakdown.csv','w',newline='') as f:
    w = csv.writer(f)
    w.writerow(['image_style','primary_tag','bots','chats_7d','pct_within_style',
                'female_pct_gendered','top5_countries','18_25_pct','26_30_pct','30plus_pct'])
    for sn in ('anime','realistic'):
        rows = [(k[1], d) for k, d in agg.items() if k[0]==sn]
        rows.sort(key=lambda x: -x[1]['chats'])
        total = sum(d['chats'] for _, d in rows)
        print(f"\n=== {sn} ({total:,} chats / 占 image_style) ===", flush=True)
        print(f"{'tag':<33} {'bots':>6} {'chats':>12} {'%':>5} {'女%':>5}  top5 country", flush=True)
        for tag, d in rows[:25]:
            pct = d['chats']*100/total
            g_tot = d['female']+d['male']
            f_pct = d['female']*100/g_tot if g_tot else 0
            a_tot = d['18_25']+d['26_30']+d['30plus']
            top5 = sorted(d['country'].items(), key=lambda x:-x[1])[:5]
            top5_str = ', '.join(f"{c}({v*100/d['chats']:.0f}%)" for c, v in top5)[:55]
            print(f"{tag[:33]:<33} {len(d['bots']):>6} {d['chats']:>12,} {pct:>4.1f}% {f_pct:>4.1f}%  {top5_str}", flush=True)
            w.writerow([sn, tag, len(d['bots']), d['chats'], round(pct,2),
                       round(f_pct,1), top5_str,
                       round(d['18_25']*100/a_tot,1) if a_tot else 0,
                       round(d['26_30']*100/a_tot,1) if a_tot else 0,
                       round(d['30plus']*100/a_tot,1) if a_tot else 0])
print("\n--- style_tag_breakdown.csv saved ---", flush=True)

# top 100 bot 明细 per style
for sn in ('anime','realistic'):
    rows = []
    for pid, d in bot_chats.items():
        if style.get(pid) != sn: continue
        meta = tags.get(pid, {})
        g_tot = d['female']+d['male']
        f_pct = d['female']*100/g_tot if g_tot else 0
        top3 = sorted(d['country'].items(), key=lambda x:-x[1])[:3]
        top3_str = ', '.join(f"{c}({v*100/d['chats']:.0f}%)" for c, v in top3)
        rows.append((pid, meta.get('title',''), meta.get('v8p',''), meta.get('lang',''),
                    d['chats'], round(f_pct,1), top3_str))
    rows.sort(key=lambda x: -x[4])
    rows = rows[:100]
    fn = f'/tmp/persona_split/top100_{sn}_bots.csv'
    with open(fn,'w',newline='') as f:
        w = csv.writer(f)
        w.writerow(['prompt_id','title','v8_primary_tag','language','chats_7d','female_pct','top3_countries'])
        for r in rows:
            w.writerow(r)
    print(f"top100_{sn}_bots.csv saved ({len(rows)} rows)", flush=True)
