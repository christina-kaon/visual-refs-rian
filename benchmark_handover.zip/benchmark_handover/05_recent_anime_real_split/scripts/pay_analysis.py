#!/usr/bin/env python3
"""每种 style 用户付费渗透率分析."""
from collections import defaultdict
import csv

# 1) load classified bot styles
style = {}
with open('/tmp/persona_split/bot_style.tsv') as f:
    next(f)
    for line in f:
        parts = line.rstrip('\n').split('\t')
        if len(parts) >= 2 and parts[1] in ('anime','realistic'):
            style[parts[0]] = parts[1]
print(f"classified bots: {len(style)}", flush=True)

# 2) load paying users
paying = set()
with open('/tmp/persona_split/paying_users_7d.tsv') as f:
    next(f)
    for line in f:
        parts = line.rstrip('\n').split('\t')
        if not parts: continue
        paying.add(parts[0])
print(f"paying users: {len(paying)}", flush=True)

# 3) load user × bot × chats, aggregate per user-style
user_style_chats = defaultdict(lambda: {'anime':0, 'realistic':0})
total_users = set()
with open('/tmp/persona_split/user_bot_chats_7d.tsv') as f:
    next(f)
    for line in f:
        parts = line.rstrip('\n').split('\t')
        if len(parts) < 3: continue
        try: chats = int(parts[2])
        except: continue
        uid, pid = parts[0], parts[1]
        total_users.add(uid)
        if pid in style:
            s = style[pid]
            user_style_chats[uid][s] += chats

print(f"total active users (had any chat with classified bot or other): {len(total_users)}", flush=True)
print(f"users who chatted with classified bots: {len(user_style_chats)}", flush=True)

# 4) classify users by main style + payment
buckets = defaultdict(lambda: {'users':0, 'paying':0, 'chats':0, 'paying_chats':0})
for uid, sc in user_style_chats.items():
    a, r = sc['anime'], sc['realistic']
    if a == 0 and r == 0:
        continue
    total_chats = a + r
    is_paying = uid in paying
    # 按主 style 分桶
    if a > r * 2:
        bucket = 'anime_primary'
    elif r > a * 2:
        bucket = 'realistic_primary'
    elif a == 0:
        bucket = 'realistic_only'
    elif r == 0:
        bucket = 'anime_only'
    else:
        bucket = 'mixed'
    buckets[bucket]['users'] += 1
    if is_paying:
        buckets[bucket]['paying'] += 1
    buckets[bucket]['chats'] += total_chats
    if is_paying:
        buckets[bucket]['paying_chats'] += total_chats

print(f"\n=== 用户主风格 × 付费渗透率 ===", flush=True)
print(f"{'bucket':<22} {'users':>8} {'paying':>7} {'paying%':>8} {'chats':>14} {'paying_chats%':>14}", flush=True)
for b in ('anime_only','anime_primary','mixed','realistic_primary','realistic_only'):
    d = buckets[b]
    pay_pct = d['paying']*100/d['users'] if d['users'] else 0
    pay_chats_pct = d['paying_chats']*100/d['chats'] if d['chats'] else 0
    print(f"{b:<22} {d['users']:>8,} {d['paying']:>7,} {pay_pct:>7.2f}% {d['chats']:>14,} {pay_chats_pct:>13.2f}%", flush=True)

# 5) Aggregate to coarse: anime vs realistic (combine *_only and *_primary)
anime_users = buckets['anime_only']['users'] + buckets['anime_primary']['users']
anime_paying = buckets['anime_only']['paying'] + buckets['anime_primary']['paying']
real_users = buckets['realistic_only']['users'] + buckets['realistic_primary']['users']
real_paying = buckets['realistic_only']['paying'] + buckets['realistic_primary']['paying']
mix_users = buckets['mixed']['users']
mix_paying = buckets['mixed']['paying']
print(f"\n=== 粗分（only + primary 合并） ===", flush=True)
print(f"  anime-leaning  : {anime_users:,} users / {anime_paying:,} paying / {anime_paying*100/anime_users if anime_users else 0:.2f}% 付费率", flush=True)
print(f"  realistic-lean : {real_users:,} users / {real_paying:,} paying / {real_paying*100/real_users if real_users else 0:.2f}% 付费率", flush=True)
print(f"  mixed          : {mix_users:,} users / {mix_paying:,} paying / {mix_paying*100/mix_users if mix_users else 0:.2f}% 付费率", flush=True)

# 6) 总付费 baseline
all_active = len(total_users)
all_paying = sum(1 for uid in total_users if uid in paying)
print(f"\n  总活跃用户 (any classified bot chat): {all_active:,}", flush=True)
print(f"  总付费率 baseline                   : {all_paying*100/all_active if all_active else 0:.2f}% ({all_paying:,} / {all_active:,})", flush=True)

# Save
with open('/tmp/persona_split/style_payment.csv','w',newline='') as f:
    w = csv.writer(f)
    w.writerow(['user_bucket','users','paying','paying_pct','chats','paying_chats_pct'])
    for b in ('anime_only','anime_primary','mixed','realistic_primary','realistic_only'):
        d = buckets[b]
        w.writerow([b, d['users'], d['paying'],
                   round(d['paying']*100/d['users'],2) if d['users'] else 0,
                   d['chats'], round(d['paying_chats']*100/d['chats'],2) if d['chats'] else 0])
print("\nstyle_payment.csv saved", flush=True)
