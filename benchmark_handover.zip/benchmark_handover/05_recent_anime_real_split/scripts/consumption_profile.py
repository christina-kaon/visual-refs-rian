#!/usr/bin/env python3
"""用户消费深度画像：chats per user / 付费类型 / 留存 / 重度用户."""
from collections import defaultdict
import csv
import statistics

# 1) bot style
style = {}
with open('/tmp/persona_split/bot_style.tsv') as f:
    next(f)
    for line in f:
        parts = line.rstrip('\n').split('\t')
        if len(parts) >= 2 and parts[1] in ('anime','realistic'):
            style[parts[0]] = parts[1]

# 2) paying detail
paying_detail = {}  # uid -> (sub_orders, flux_orders, sub_rev, flux_rev)
with open('/tmp/persona_split/paying_detail_7d.tsv') as f:
    next(f)
    for line in f:
        parts = line.rstrip('\n').split('\t')
        if len(parts) < 5: continue
        try:
            paying_detail[parts[0]] = (int(parts[1]), int(parts[2]),
                                       float(parts[3]), float(parts[4]))
        except: pass

# 3) retention
retention = {}
with open('/tmp/persona_split/user_retention_7d.tsv') as f:
    next(f)
    for line in f:
        parts = line.rstrip('\n').split('\t')
        if len(parts) < 6: continue
        try:
            retention[parts[0]] = {
                'd1': parts[1] == '1', 'd7': parts[2] == '1',
                'd14': parts[3] == '1', 'd30': parts[4] == '1',
                'is_new': int(parts[5]) if parts[5] else 0
            }
        except: pass

# 4) user × bot chats aggregate by user → style
user_style = defaultdict(lambda: {'anime': 0, 'realistic': 0,
                                   'anime_bots': set(), 'realistic_bots': set()})
with open('/tmp/persona_split/user_bot_chats_7d.tsv') as f:
    next(f)
    for line in f:
        parts = line.rstrip('\n').split('\t')
        if len(parts) < 3: continue
        try: c = int(parts[2])
        except: continue
        pid = parts[1]
        if pid in style:
            uid = parts[0]
            s = style[pid]
            user_style[uid][s] += c
            user_style[uid][f'{s}_bots'].add(pid)

print(f"users with classified bot chats: {len(user_style)}", flush=True)
print(f"paying users: {len(paying_detail)}", flush=True)

# 5) Classify users by primary style
def get_bucket(d):
    a, r = d['anime'], d['realistic']
    if a == 0 and r == 0: return None
    if a > 0 and r == 0: return 'anime_only'
    if r > 0 and a == 0: return 'realistic_only'
    if a > r * 2: return 'anime_primary'
    if r > a * 2: return 'realistic_primary'
    return 'mixed'

# 6) 各 bucket stats
buckets = defaultdict(lambda: {
    'users': [],          # list of (uid, total_chats, bot_count)
    'sub_only': 0,
    'flux_only': 0,
    'both_pay': 0,
    'paying_total': 0,
    'd7_retained': 0,
    'is_new': 0,
})

for uid, d in user_style.items():
    b = get_bucket(d)
    if b is None: continue
    total_chats = d['anime'] + d['realistic']
    bot_count = len(d['anime_bots']) + len(d['realistic_bots'])
    buckets[b]['users'].append((uid, total_chats, bot_count))
    if uid in paying_detail:
        so, fo, sr, fr = paying_detail[uid]
        buckets[b]['paying_total'] += 1
        if so > 0 and fo > 0: buckets[b]['both_pay'] += 1
        elif so > 0: buckets[b]['sub_only'] += 1
        elif fo > 0: buckets[b]['flux_only'] += 1
    if uid in retention:
        if retention[uid]['d7']: buckets[b]['d7_retained'] += 1
        if retention[uid]['is_new']: buckets[b]['is_new'] += 1

# Output
print(f"\n=== 消费深度（每用户） ===", flush=True)
print(f"{'bucket':<22} {'users':>9} {'mid chats':>10} {'p90 chats':>10} {'mid bots':>9} {'p90 bots':>9}", flush=True)
for b in ('anime_only','anime_primary','mixed','realistic_primary','realistic_only'):
    d = buckets[b]
    if not d['users']: continue
    chats = sorted(u[1] for u in d['users'])
    bots = sorted(u[2] for u in d['users'])
    mid_c = chats[len(chats)//2]
    p90_c = chats[int(len(chats)*0.9)]
    mid_b = bots[len(bots)//2]
    p90_b = bots[int(len(bots)*0.9)]
    print(f"{b:<22} {len(d['users']):>9,} {mid_c:>10} {p90_c:>10} {mid_b:>9} {p90_b:>9}", flush=True)

print(f"\n=== 付费类型偏好（仅付费用户内）===", flush=True)
print(f"{'bucket':<22} {'paying':>8} {'sub_only':>9} {'flux_only':>10} {'both':>6}", flush=True)
for b in ('anime_only','anime_primary','mixed','realistic_primary','realistic_only'):
    d = buckets[b]
    if not d['users']: continue
    p = d['paying_total']
    if p == 0: continue
    so_pct = d['sub_only']*100/p
    fo_pct = d['flux_only']*100/p
    bo_pct = d['both_pay']*100/p
    print(f"{b:<22} {p:>8,} {so_pct:>8.1f}% {fo_pct:>9.1f}% {bo_pct:>5.1f}%", flush=True)

print(f"\n=== 留存 & 新用户 ===", flush=True)
print(f"{'bucket':<22} {'users':>9} {'d7_retained':>12} {'d7%':>6} {'is_new':>7} {'new%':>6}", flush=True)
for b in ('anime_only','anime_primary','mixed','realistic_primary','realistic_only'):
    d = buckets[b]
    if not d['users']: continue
    u = len(d['users'])
    d7p = d['d7_retained']*100/u
    np_pct = d['is_new']*100/u
    print(f"{b:<22} {u:>9,} {d['d7_retained']:>12,} {d7p:>5.1f}% {d['is_new']:>7,} {np_pct:>5.1f}%", flush=True)

# 重度用户（top 10% by chats）
print(f"\n=== 重度用户 (top 10% chats per bucket) 风格分布 ===", flush=True)
all_users_with_chats = []
for b in ('anime_only','anime_primary','mixed','realistic_primary','realistic_only'):
    for uid, c, bc in buckets[b]['users']:
        all_users_with_chats.append((uid, c, b))
all_users_with_chats.sort(key=lambda x: -x[1])
top10 = all_users_with_chats[:len(all_users_with_chats)//10]
print(f"  total users: {len(all_users_with_chats):,}, top 10% = {len(top10):,}", flush=True)
from collections import Counter
top10_dist = Counter(x[2] for x in top10)
all_dist = Counter(x[2] for x in all_users_with_chats)
print(f"\n  bucket               | top 10% users | all users | top%/all% lift", flush=True)
for b in ('anime_only','anime_primary','mixed','realistic_primary','realistic_only'):
    if all_dist[b] == 0: continue
    t_pct = top10_dist[b]*100/len(top10)
    a_pct = all_dist[b]*100/len(all_users_with_chats)
    lift = t_pct/a_pct if a_pct else 0
    print(f"  {b:<22} {top10_dist[b]:>8,} ({t_pct:.1f}%) {all_dist[b]:>8,} ({a_pct:.1f}%)  lift={lift:.2f}x", flush=True)

# Save CSV
with open('/tmp/persona_split/consumption_profile.csv','w',newline='') as f:
    w = csv.writer(f)
    w.writerow(['bucket','users','mid_chats','p90_chats','mid_bots','p90_bots',
                'paying','sub_only_pct','flux_only_pct','both_pay_pct',
                'd7_retained','d7_pct','is_new','new_pct',
                'top10_users','top10_lift'])
    for b in ('anime_only','anime_primary','mixed','realistic_primary','realistic_only'):
        d = buckets[b]
        if not d['users']: continue
        chats = sorted(u[1] for u in d['users'])
        bots = sorted(u[2] for u in d['users'])
        u = len(d['users'])
        p = d['paying_total']
        all_p = all_dist[b]
        t_p = top10_dist[b]
        t_pct = t_p*100/len(top10) if len(top10) else 0
        a_pct = all_p*100/len(all_users_with_chats) if len(all_users_with_chats) else 0
        lift = t_pct/a_pct if a_pct else 0
        w.writerow([b, u, chats[len(chats)//2], chats[int(len(chats)*0.9)],
                   bots[len(bots)//2], bots[int(len(bots)*0.9)],
                   p,
                   round(d['sub_only']*100/p,2) if p else 0,
                   round(d['flux_only']*100/p,2) if p else 0,
                   round(d['both_pay']*100/p,2) if p else 0,
                   d['d7_retained'], round(d['d7_retained']*100/u,2),
                   d['is_new'], round(d['is_new']*100/u,2),
                   t_p, round(lift,2)])
print("\nCSV: consumption_profile.csv saved", flush=True)
