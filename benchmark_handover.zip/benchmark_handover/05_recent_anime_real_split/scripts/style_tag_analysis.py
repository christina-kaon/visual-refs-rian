#!/usr/bin/env python3
"""image_style × v8_primary_tag aggregation."""
from collections import defaultdict
import csv

# 1) load bot style
style = {}
with open('/tmp/persona_split/bot_style.tsv') as f:
    next(f)
    for line in f:
        parts = line.rstrip('\n').split('\t')
        if len(parts) < 2:
            continue
        if parts[1] in ('anime', 'realistic'):
            style[parts[0]] = parts[1]
print(f"classified bots: {len(style)}", flush=True)

# 2) load bot tags
tags = {}
with open('/tmp/persona_split/bot_tags_all_7d.tsv') as f:
    next(f)
    for line in f:
        parts = line.rstrip('\n').split('\t')
        if len(parts) < 5:
            continue
        pid, v8p, v8pa, title, lang = parts[0], parts[1], parts[2], parts[3], parts[4]
        tags[pid] = {'v8_primary': v8p, 'v8_parent': v8pa, 'title': title, 'language': lang}
print(f"bots with tags: {len(tags)}", flush=True)

# 3) Load persona aggregate
agg = defaultdict(lambda: {'chats': 0, 'bots': set(), 'female': 0, 'male': 0, 'country': defaultdict(int)})
row_cnt = 0
with open('/tmp/persona_split/all_persona_7d.tsv') as f:
    for line in f:
        row_cnt += 1
        parts = line.rstrip('\n').split('\t')
        if len(parts) < 5:
            continue
        pid, gender, age, country = parts[0], parts[1], parts[2], parts[3]
        try:
            chats = int(parts[4])
        except (ValueError, IndexError):
            continue
        if pid not in style or pid not in tags:
            continue
        s = style[pid]
        t = tags[pid].get('v8_primary') or 'NULL'
        if t == 'NULL':
            t = '_未分类'
        key = (s, t)
        agg[key]['chats'] += chats
        agg[key]['bots'].add(pid)
        if gender == 'Female':
            agg[key]['female'] += chats
        elif gender == 'Male':
            agg[key]['male'] += chats
        agg[key]['country'][country] += chats
print(f"persona rows processed: {row_cnt}", flush=True)

# Output
with open('/tmp/persona_split/style_tag_breakdown.csv', 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['image_style', 'primary_tag', 'bots', 'chats_7d', 'pct_within_style',
                'female_chats', 'male_chats', 'female_pct_among_gendered', 'top5_countries'])
    for style_name in ('anime', 'realistic'):
        rows = [(k[1], d) for k, d in agg.items() if k[0] == style_name]
        rows.sort(key=lambda x: -x[1]['chats'])
        total = sum(d['chats'] for _, d in rows)
        print(f"\n=== {style_name} 内题材分布 ===", flush=True)
        print(f"{'primary_tag':<35} {'bots':>7} {'chats_7d':>12} {'%':>6} {'female%':>8} top5_country", flush=True)
        for tag, d in rows[:20]:
            pct = d['chats'] * 100 / total if total else 0
            g_total = d['female'] + d['male']
            f_pct = d['female'] * 100 / g_total if g_total else 0
            top5 = sorted(d['country'].items(), key=lambda x: -x[1])[:5]
            top5_str = ', '.join(f"{c}({v*100/d['chats']:.0f}%)" for c, v in top5)[:60]
            print(f"{tag[:35]:<35} {len(d['bots']):>7} {d['chats']:>12,} {pct:>5.1f}% {f_pct:>7.1f}% {top5_str}", flush=True)
            w.writerow([style_name, tag, len(d['bots']), d['chats'], round(pct, 2),
                        d['female'], d['male'], round(f_pct, 1), top5_str])
print("\nCSV saved: style_tag_breakdown.csv", flush=True)
