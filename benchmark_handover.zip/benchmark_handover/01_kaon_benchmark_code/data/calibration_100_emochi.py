"""Convert calibration_100.csv (v4 synthetic, flat columns) into emochi-bench schema.

Maps the flat columns into a_tags / p_tags JSON, drops dialogue_context placeholder,
keeps generated_image_path so the run only needs the evaluator (not the generator).
"""

from __future__ import annotations

import csv
import json
import sys
from pathlib import Path


# Map flat input columns to the emochi tag registry.
A_LINE_KEYS = {
    "category": "category",
    "technique": "game_ip_style",   # closest registry slot for technique
    "outfit": "outfit",
    "hair": "hair_color_family",    # source column carries hair color or texture
    "expression": "expression",
}

P_LINE_KEYS = {
    "genre": "genre",
    "color_tone": "mood",           # closest registry slot for tone
    "lighting": "weather",          # registry has weather; use lighting as analogue
    "composition": "composition",
    "shot_angle": "shot_angle",
    "pose": "pose",
    "setting": "setting",
    "rating": "rating",
}


def convert(in_path: Path, out_path: Path) -> int:
    rows_out: list[dict] = []
    with in_path.open("r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            a_tags = {}
            for src, dst in A_LINE_KEYS.items():
                v = (row.get(src) or "").strip()
                if v:
                    a_tags[dst] = v
            p_tags = {}
            for src, dst in P_LINE_KEYS.items():
                v = (row.get(src) or "").strip()
                if v:
                    p_tags[dst] = v
            rows_out.append({
                "test_id": row["test_id"],
                "character_name": row["character_name"],
                "ref_image_path": row["ref_image_path"],
                "prompt": row["prompt"],
                "generated_image_path": row["generated_image_path"],
                "dialogue_context": "",   # source dataset has no real dialogue
                "a_tags": json.dumps(a_tags, ensure_ascii=False),
                "p_tags": json.dumps(p_tags, ensure_ascii=False),
                "nsfw_flag": row.get("nsfw_flag", ""),
                "baseline_v4_opus46": row.get("composite_raw_v4_opus46", ""),
            })

    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows_out[0].keys()))
        writer.writeheader()
        writer.writerows(rows_out)
    return len(rows_out)


if __name__ == "__main__":
    in_path = Path(sys.argv[1] if len(sys.argv) > 1 else "/tmp/calibration_100.csv")
    out_path = Path(sys.argv[2] if len(sys.argv) > 2 else "data/calibration_100_emochi.csv")
    n = convert(in_path, out_path)
    print(f"converted {n} rows → {out_path}")
