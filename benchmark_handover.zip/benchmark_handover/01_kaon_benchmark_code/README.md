# KAON Image Generation Benchmark Tool

A Python benchmark for evaluating roleplay-chat character-illustration generators across four dimensions (character / story / visual appeal / technical quality), with VLM/LLM judges, hard-penalty composite scoring, and a self-contained interactive HTML report.

## Quick Start

```bash
# 1) Install (editable mode is recommended during iteration)
pip install -e .

# 2) Set the API keys you reference in config.yaml
export KAON_API_KEY=...
export BASELINE_API_KEY=...
export VLM_API_KEY=...

# 3) Validate everything is wired up before spending API quota
kaon-bench dry-run --config config.yaml
# ✔ config loaded   ✔ prompts/*.yaml   ✔ endpoints   ✔ CSV   ✔ tag_registry

# 4) Probe live API connectivity (1 request per generator + 1 per evaluator)
kaon-bench probe --config config.yaml

# 5) Smoke run on 5 cases — emits results/smoke_report.html with raw VLM/LLM output
kaon-bench run --config config.yaml --limit 5 --smoke

# 6) Full run — emits results/report.html
kaon-bench run --config config.yaml
```

CLI flags:

| Flag                   | Effect                                                        |
|------------------------|---------------------------------------------------------------|
| `--config FILE`        | Path to `config.yaml` (default: `./config.yaml`)              |
| `--limit N`            | Run only the first N cases                                    |
| `--smoke`              | Smoke-mode report (`results/smoke_report.html`)               |
| `--dims 1,3`           | Only evaluate selected dimensions                             |
| `--resume / --no-resume` | Resume from `results/progress.jsonl` (default on)           |

## Configuration

Three files live at the project root:

- `config.yaml` — generator + evaluator endpoints, runtime parameters
- `tag_registry.yaml` — A-line / P-line tag dimension metadata (which dimensions are pinned, which are multi-value, etc.)
- `prompts/dim*.yaml` — VLM/LLM scoring prompts (instruction + assistant prefill + trigger)

Per-dimension evaluator overrides inherit unspecified fields from `evaluator.default`. Example:

```yaml
evaluator:
  default:
    base_url: "https://api.example.com/v1"
    api_key: "${VLM_API_KEY}"
    model: "claude-opus-4-6"
    model_fallback:
      - "claude-haiku-4-5-20251001"
  dim2_step2:
    api_key: "${LLM_API_KEY}"
    model: "claude-opus-4-6"   # text-only LLM for D2 alignment scoring
```

## Input CSV

Required columns: `test_id`, `character_name`, `ref_image_path`, `prompt`.
Optional: `dialogue_context`, `a_tags`, `p_tags` (JSON strings).

`a_tags` and `p_tags` legacy mapping: if only `style_tag` / `category_tag` are present, the loader maps them to `{"category": ...}` and `{"genre": ...}` automatically.

Multi-value tag dimensions (`accessories`, etc.) use comma-separated values.

## Scoring

Each case produces four dimension scores (0.0-4.0 floats), then:

```python
composite_raw = dim1*0.30 + dim2*0.30 + dim3*0.25 + dim4*0.15

# Hard-penalty steps — order is fixed (step 1 may trigger step 2):
if facial_distortion <= 1: dim4 = min(dim4, 1.0)
if dim4 <= 1.0:            composite_raw = min(composite_raw, 3.0)
if dim1 <= 0.5:            composite_raw = min(composite_raw, 1.0)

composite_display = round(composite_raw * 2.5, 1)   # 0-10 scale
```

D2 is a two-step pipeline: a VLM produces a structured visual analysis from the generated image alone (no narrative context, no reference image — to prevent confirmation bias), then an LLM scores that analysis against the dialogue context. Both steps are tracked separately in `progress.jsonl`, so a step-1 success + step-2 failure only retries step 2 on resume.

## Project Layout

```
kaon-benchmark/
├── pyproject.toml
├── README.md
├── config.yaml
├── tag_registry.yaml
├── prompts/
│   ├── dim1.yaml          D1 character consistency (CoT off)
│   ├── dim2_step1.yaml    D2 step 1 — VLM visual analysis
│   ├── dim2_step2.yaml    D2 step 2 — LLM narrative alignment
│   ├── dim3.yaml          D3 visual appeal (CoT on, cognitive-guided)
│   └── dim4.yaml          D4 technical quality (CoT on, defect-observation)
├── data/
│   └── test_cases.csv     sample 3-row input
├── src/kaon_benchmark/
│   ├── cli.py             click entry point: run / probe / dry-run
│   ├── config.py          YAML loader, ${ENV} expansion, evaluator merge
│   ├── tag_registry.py    A/P registry, JSON tag parsing, aggregation
│   ├── probe.py           connectivity + prefill validation
│   ├── generator.py       image-generation API client
│   ├── evaluator.py       four-dim VLM/LLM evaluator + D2 two-step
│   ├── parser.py          parse_sub_scores + parse_visual_analysis + NSFW refuse
│   ├── scorer.py          weighted dim scores + 3-step hard penalty
│   ├── progress.py        JSONL append-only progress log (D2 step granularity)
│   ├── reporter.py        full HTML report (Section 1-6, interactive heatmap)
│   ├── smoke_reporter.py  smoke HTML report (raw outputs + parser status)
│   ├── dryrun.py          dry-run validation
│   └── utils.py           magic-byte sniffing, base64, exponential backoff
└── results/
    ├── progress.jsonl     append-only progress log (created on first run)
    ├── raw_scores.csv     final per-case scores
    ├── report.html        full report
    └── smoke_report.html  smoke report (only with --smoke)
```

## Running the Sample Reports

```bash
python tests/test_reports.py
# → results/report.html (full mock benchmark)
# → results/smoke_report.html (5 successful + 1 parse-error case)
```

Open the generated HTML files in a browser. The full report includes:

- Section 1 — summary cards (total, success rate, average composite, error/refuse) + 4 dimension gauges
- Section 2 — per-model bar + radar chart (when ≥2 generators)
- Section 3 — top/bottom tag cards, plus an interactive heatmap (dimension dropdown + min-samples slider; CSS-table heatmap, no Chart.js matrix plugin)
- Section 4 — score histograms + D1×D3 scatter + facial_distortion sub-score distribution
- Section 5 — DataTables case detail (search, sort, click-to-expand for full reasoning + tag breakdown)
- Section 6 — bottom-10% cases, weakest tag dimensions, hard-penalty trigger statistics, NSFW refuses

## Versioning

This is `v0.1.0` — Stage 1-4 of the v4 spec is complete. The `run` command in this build delegates per-case orchestration to a follow-up integration milestone; `dry-run` and `probe` are fully wired to live APIs.
