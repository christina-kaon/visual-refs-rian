"""Smoke test: generate mock report data and render reports/smoke_report HTML."""

from __future__ import annotations

import random
from pathlib import Path

from kaon_benchmark.reporter import ReportContext, render_report
from kaon_benchmark.smoke_reporter import SmokeContext, render_smoke_report
from kaon_benchmark.tag_registry import load_tag_registry
from kaon_benchmark.scorer import compute_composite


CATEGORIES = ["Anime", "Realistic", "CGI"]
GENRES = ["romance", "fantasy", "urban", "horror", "slice_of_life"]
RATINGS = ["general", "questionable", "R18"]
MOODS = ["romantic", "tense", "calm", "brooding", "excited"]
SETTINGS = ["garden", "alley", "courtyard", "bedroom", "rooftop"]
COMPOSITIONS = ["solo", "2boys", "duo"]
POSES = ["standing", "leaning", "sitting", "lying_down"]
SHOT = ["mid_shot", "half_shot", "full_shot", "close_up"]


def _mk_case(test_id: str, character: str, model: str, *, force_pattern: str | None = None) -> dict:
    rng = random.Random(test_id + model)

    def rs(low: int = 0, high: int = 4) -> int:
        return rng.randint(low, high)

    if force_pattern == "fd_cap":
        d4_sub = {"facial_distortion": 1, "body_structure": 4, "coherence": 4, "physics": 4}
    elif force_pattern == "d1_cap":
        d4_sub = {"facial_distortion": 4, "body_structure": 4, "coherence": 4, "physics": 4}
    else:
        d4_sub = {"facial_distortion": rs(2, 4), "body_structure": rs(2, 4), "coherence": rs(2, 4), "physics": rs(2, 4)}

    if force_pattern == "d1_cap":
        d1_sub = {"facial": 0, "hair": 0, "eye_color": 1, "body": 1, "signature": 4}
    else:
        d1_sub = {"facial": rs(2, 4), "hair": rs(2, 4), "eye_color": rs(2, 4), "body": rs(2, 4), "signature": rs(2, 4)}

    d2_sub = {"event": rs(1, 4), "scene": rs(1, 4), "emotion": rs(1, 4), "interaction": rs(1, 4), "props": rs(1, 4)}
    d3_sub = {"attractiveness": rs(2, 4), "expressiveness": rs(2, 4), "composition": rs(2, 4),
              "color_lighting": rs(2, 4), "finish": rs(2, 4)}

    score = compute_composite(dim1_sub=d1_sub, dim2_sub=d2_sub, dim3_sub=d3_sub, dim4_sub=d4_sub)

    a_tags = {
        "category": rng.choice(CATEGORIES),
        "gender_age": rng.choice(["bishojo", "young_man", "young_woman"]),
        "hair_color_family": rng.choice(["pink", "silver", "black", "blonde", "white"]),
        "outfit": rng.choice(["school_uniform", "casual", "leather_jacket", "ceremonial_robe"]),
        "accessories": rng.choice(["hair_ribbon", "earrings,necklace", "silver_chain", ""]),
    }
    p_tags = {
        "genre": rng.choice(GENRES),
        "setting": rng.choice(SETTINGS),
        "rating": rng.choice(RATINGS),
        "mood": rng.choice(MOODS),
        "composition": rng.choice(COMPOSITIONS),
        "pose": rng.choice(POSES),
        "shot_angle": rng.choice(SHOT),
    }
    a_tags = {k: v for k, v in a_tags.items() if v}
    p_tags = {k: v for k, v in p_tags.items() if v}

    return {
        "test_id": test_id,
        "character_name": character,
        "model_name": model,
        "ref_image_path": "https://via.placeholder.com/64?text=ref",
        "generated_image_path": "https://via.placeholder.com/64?text=gen",
        "dialogue_context": "User: hey | Char: hi there | User: where are you? | Char: in the garden | User: come here",
        "a_tags": a_tags,
        "p_tags": p_tags,
        "dim1_score": score.dim1_score,
        "dim2_score": score.dim2_score,
        "dim3_score": score.dim3_score,
        "dim4_score": score.dim4_score,
        "dim1_sub_scores": d1_sub,
        "dim2_sub_scores": d2_sub,
        "dim3_sub_scores": d3_sub,
        "dim4_sub_scores": d4_sub,
        "dim2_step1_description": {
            "characters": "one girl with pink hair", "action": "standing in a garden",
            "setting": "sunlit garden", "objects": "roses",
            "spatial": "alone, centered", "mood": "romantic",
        },
        "dim2_reasoning": "Strong scene match; weak interaction.",
        "dim3_reasoning": "Clear visual entry on the face; gaze guides to the rose.",
        "dim4_reasoning": "No visible defects at normal viewing distance.",
        "composite_raw": score.composite_raw,
        "composite_display": score.composite_display,
        "statuses": {"d1": "success", "d2": "success", "d3": "success", "d4": "success"},
        "penalty_applied": score.penalty_applied,
        "errors": {},
    }


def main() -> None:
    repo_root = Path(__file__).resolve().parent.parent
    registry = load_tag_registry(repo_root / "tag_registry.yaml")

    cases = []
    for i in range(40):
        case = _mk_case(f"{i:03d}", f"Char_{i % 7}", "kaon_v1.5")
        cases.append(case)
    for i in range(40):
        case = _mk_case(f"{i:03d}", f"Char_{i % 7}", "baseline_gpt4o")
        cases.append(case)
    cases.append(_mk_case("099", "BadFace", "kaon_v1.5", force_pattern="fd_cap"))
    cases.append(_mk_case("100", "BadID", "kaon_v1.5", force_pattern="d1_cap"))
    refuse_case = _mk_case("101", "BlockedNSFW", "kaon_v1.5")
    refuse_case["statuses"] = {"d1": "nsfw_refused", "d2": "nsfw_refused", "d3": "nsfw_refused", "d4": "nsfw_refused"}
    refuse_case["dim1_score"] = refuse_case["dim2_score"] = refuse_case["dim3_score"] = refuse_case["dim4_score"] = None
    refuse_case["composite_raw"] = refuse_case["composite_display"] = None
    cases.append(refuse_case)

    ctx = ReportContext(
        results=cases,
        registry=registry,
        model_names=["kaon_v1.5", "baseline_gpt4o"],
        title="KAON Benchmark — Mock Smoke",
    )
    out = render_report(ctx, repo_root / "results" / "report.html")
    print(f"report → {out}  ({out.stat().st_size} bytes)")

    smoke_cases = []
    for c in cases[:5]:
        smoke_cases.append({
            "test_id": c["test_id"],
            "character_name": c["character_name"],
            "model_name": c["model_name"],
            "composite_display": c["composite_display"],
            "dim1_score": c["dim1_score"], "dim2_score": c["dim2_score"],
            "dim3_score": c["dim3_score"], "dim4_score": c["dim4_score"],
            "per_dim_raw": {
                "d1": '{"scores": {"facial":4,"hair":4,"eye_color":3,"body":4,"signature":4}}',
                "d2_step1": '{"description":{"characters":"one girl","action":"standing","setting":"garden","objects":"roses","spatial":"alone","mood":"romantic"},"scene_description":"a calm romantic scene"}',
                "d2_step2": '{"reasoning":"strong setting match","scores":{"event":3,"scene":4,"emotion":3,"interaction":2,"props":2}}',
                "d3": '{"reasoning":"clear focus on face","scores":{"attractiveness":3,"expressiveness":4,"composition":3,"color_lighting":4,"finish":3}}',
                "d4": '{"reasoning":"no defects","scores":{"facial_distortion":4,"body_structure":4,"coherence":4,"physics":4}}',
            },
            "per_dim_parsed": {
                "d1": {"scores": c["dim1_sub_scores"], "reasoning": None},
                "d2_step1": c["dim2_step1_description"],
                "d2_step2": {"scores": c["dim2_sub_scores"], "reasoning": c["dim2_reasoning"]},
                "d3": {"scores": c["dim3_sub_scores"], "reasoning": c["dim3_reasoning"]},
                "d4": {"scores": c["dim4_sub_scores"], "reasoning": c["dim4_reasoning"]},
            },
            "per_dim_status": {"d1": "success", "d2_step1": "success", "d2_step2": "success", "d3": "success", "d4": "success"},
        })
    # one parse_error case to show the visual treatment
    smoke_cases.append({
        "test_id": "999",
        "character_name": "ParseFail",
        "model_name": "kaon_v1.5",
        "composite_display": None,
        "dim1_score": None, "dim2_score": None, "dim3_score": None, "dim4_score": None,
        "per_dim_raw": {"d1": "Sorry, I can't comply.", "d2_step1": "garbled output {not valid", "d2_step2": "", "d3": "", "d4": ""},
        "per_dim_parsed": {"d1": None, "d2_step1": None, "d2_step2": None, "d3": None, "d4": None},
        "per_dim_status": {"d1": "nsfw_refused", "d2_step1": "parse_error", "d2_step2": "error", "d3": "error", "d4": "error"},
    })

    smoke_ctx = SmokeContext(
        probe_outcomes=[
            {"name": "kaon_v1.5", "kind": "generator", "model": "kaon-image-v1.5", "ok": True, "detail": "got 9421 bytes", "latency_ms": 4231},
            {"name": "baseline_gpt4o", "kind": "generator", "model": "gpt-4o-image", "ok": True, "detail": "got 11108 bytes", "latency_ms": 5890},
            {"name": "default", "kind": "evaluator", "model": "claude-opus-4-6", "ok": True, "detail": '{"ok": true}', "latency_ms": 1820},
            {"name": "dim4", "kind": "evaluator", "model": "gpt-4o-2024-08-06", "ok": False, "detail": "prefill not supported for this model"},
        ],
        cases=smoke_cases,
    )
    out2 = render_smoke_report(smoke_ctx, repo_root / "results" / "smoke_report.html")
    print(f"smoke_report → {out2}  ({out2.stat().st_size} bytes)")


if __name__ == "__main__":
    main()
