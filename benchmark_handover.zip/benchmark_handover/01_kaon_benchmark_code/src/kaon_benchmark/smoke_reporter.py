"""Smoke report: API connectivity status + per-case raw VLM/LLM output for parser debugging."""

from __future__ import annotations

import html
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class SmokeContext:
    """Smoke-mode-specific data the report needs.

    `probe_outcomes`: list of {name, kind, model, ok, detail, latency_ms?}
    `cases`: list of dicts with at minimum:
        test_id, character_name, model_name,
        per_dim_raw: {"d1": str, "d2_step1": str, "d2_step2": str, "d3": str, "d4": str},
        per_dim_parsed: same shape (None when parse failed),
        per_dim_status: same shape (success / parse_error / nsfw_refused / error),
        composite_display, dim1..dim4 score
    """

    probe_outcomes: list[dict[str, Any]]
    cases: list[dict[str, Any]]
    title: str = "KAON Image Benchmark — Smoke Report"
    extra: dict[str, Any] = field(default_factory=dict)


def render_smoke_report(ctx: SmokeContext, output_path: str | Path) -> Path:
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(_build_html(ctx), encoding="utf-8")
    return out


def _safe(v: Any) -> str:
    if v is None:
        return ""
    return html.escape(str(v))


def _summary_row(label: str, value: str) -> str:
    return f'<tr><th style="text-align:left">{html.escape(label)}</th><td>{html.escape(value)}</td></tr>'


def _build_probe_section(ctx: SmokeContext) -> str:
    kind_zh = {"generator": "生成", "evaluator": "评分"}
    rows: list[str] = []
    for o in ctx.probe_outcomes:
        marker = "✔" if o.get("ok") else "✘"
        cls = "ok" if o.get("ok") else "fail"
        latency = o.get("latency_ms")
        latency_str = f" · {latency:.0f}ms" if isinstance(latency, (int, float)) else ""
        rows.append(
            f'<tr class="{cls}"><td>{marker}</td>'
            f'<td>{html.escape(kind_zh.get(str(o.get("kind","")), str(o.get("kind",""))))}</td>'
            f'<td>{_safe(o.get("name"))}</td><td>{_safe(o.get("model"))}{latency_str}</td>'
            f'<td>{_safe(o.get("detail"))}</td></tr>'
        )
    return (
        '<section><h2><span class="num">01</span>API 连接状态</h2>'
        '<p class="section-desc">每个生成器和评分器的探活结果，用于在跑全量前确认凭证、prefill 支持和延迟。</p>'
        '<table class="probe-table"><thead><tr><th></th><th>类型</th><th>名称</th><th>模型</th><th>详情</th></tr></thead>'
        f'<tbody>{"".join(rows)}</tbody></table></section>'
    )


def _build_dim_dist_section(ctx: SmokeContext) -> str:
    bins = {"d1": [0]*5, "d2": [0]*5, "d3": [0]*5, "d4": [0]*5}
    for c in ctx.cases:
        for dim_short, score_key in (("d1","dim1_score"),("d2","dim2_score"),("d3","dim3_score"),("d4","dim4_score")):
            s = c.get(score_key)
            if s is None:
                continue
            idx = max(0, min(int(round(s)), 4))
            bins[dim_short][idx] += 1
    rows = []
    dim_zh = {"d1": "D1 角色", "d2": "D2 剧情", "d3": "D3 视觉", "d4": "D4 技术"}
    for dim_short in ("d1","d2","d3","d4"):
        cells = "".join(f'<td>{bins[dim_short][i]}</td>' for i in range(5))
        rows.append(f'<tr><th>{dim_zh[dim_short]}</th>{cells}</tr>')
    return (
        '<section><h2><span class="num">02</span>各维度分数分布（粗略）</h2>'
        '<p class="section-desc">smoke 跑通后各维度分数的整体分布，看 VLM/LLM 输出是否合理（极端集中或全 0 通常意味着 prompt 或 parser 有问题）。</p>'
        '<table class="dist-table"><thead><tr><th></th><th>0</th><th>1</th><th>2</th><th>3</th><th>4</th></tr></thead>'
        f'<tbody>{"".join(rows)}</tbody></table></section>'
    )


def _build_cases_section(ctx: SmokeContext) -> str:
    blocks: list[str] = []
    dim_label = {"d1": "D1 角色一致性", "d2_step1": "D2 第一步（视觉描述）", "d2_step2": "D2 第二步（剧情对齐）",
                 "d3": "D3 视觉吸引力", "d4": "D4 技术质量"}
    status_zh = {"success": "成功", "parse_error": "解析失败", "nsfw_refused": "NSFW 拒答", "error": "请求错误"}
    for c in ctx.cases:
        per_raw = c.get("per_dim_raw") or {}
        per_parsed = c.get("per_dim_parsed") or {}
        per_status = c.get("per_dim_status") or {}
        dim_blocks = []
        for dim_key, label in dim_label.items():
            raw = per_raw.get(dim_key)
            parsed = per_parsed.get(dim_key)
            status = per_status.get(dim_key, "—")
            status_class = ""
            if status == "parse_error":
                status_class = "status-parse-error"
            elif status == "nsfw_refused":
                status_class = "status-refuse"
            elif status == "error":
                status_class = "status-error"
            elif status == "success":
                status_class = "status-success"
            raw_str = json.dumps(raw, ensure_ascii=False) if raw is None else str(raw)
            parsed_str = json.dumps(parsed, ensure_ascii=False, indent=2) if parsed is not None else "（未解析）"
            status_label = status_zh.get(status, status)
            dim_blocks.append(
                f'<div class="dim-block {status_class}">'
                f'<h4>{html.escape(label)} <span class="status">[{html.escape(status_label)}]</span></h4>'
                f'<details><summary>原始输出（{len(raw_str) if raw_str else 0} 字符）</summary>'
                f'<pre>{html.escape(raw_str or "（空）")}</pre></details>'
                f'<details><summary>解析结果</summary><pre>{html.escape(parsed_str)}</pre></details>'
                "</div>"
            )
        blocks.append(
            '<article class="case">'
            f'<h3>{_safe(c.get("test_id"))} · {_safe(c.get("character_name"))} · 模型 {_safe(c.get("model_name"))}</h3>'
            f'<p class="composite-line">综合分（0-10）：<strong>{c.get("composite_display") if c.get("composite_display") is not None else "—"}</strong></p>'
            f'{"".join(dim_blocks)}'
            "</article>"
        )
    return (
        '<section><h2><span class="num">03</span>各用例原始输出</h2>'
        '<p class="section-desc">smoke 跑通的每条用例都展开为五个维度（D1 / D2 第一步 / D2 第二步 / D3 / D4），便于在出问题时快速定位是模型输出本身有问题还是 parser 有问题。</p>'
        f'{"".join(blocks)}'
        "</section>"
    )


def _build_html(ctx: SmokeContext) -> str:
    probe_html = _build_probe_section(ctx)
    dist_html = _build_dim_dist_section(ctx)
    cases_html = _build_cases_section(ctx)
    return _SMOKE_TEMPLATE.format(
        title=html.escape(ctx.title),
        css=_SMOKE_CSS,
        probe=probe_html,
        dist=dist_html,
        cases=cases_html,
    )


_SMOKE_CSS = """
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Noto+Sans+SC:wght@400;500;600;700&display=swap');
:root{
  --bg:#faf9f7;--surface:#ffffff;--surface-soft:#f5f3ef;
  --border:#e8e4dd;--text:#1f1d1a;--text-muted:#6b6862;--text-subtle:#94918a;
  --accent:#c96442;--green:#5fa572;--yellow:#d4a045;--red:#c4634d;
  --shadow-sm:0 1px 2px rgba(35,30,22,.04),0 0 0 1px rgba(35,30,22,.02);
  --radius-sm:8px;--radius-md:12px;
}
*{box-sizing:border-box;}
html,body{margin:0;padding:0;}
body{
  font-family:'Inter','Noto Sans SC',-apple-system,BlinkMacSystemFont,'PingFang SC','Hiragino Sans GB','Microsoft YaHei',sans-serif;
  background:var(--bg);color:var(--text);font-size:14px;line-height:1.6;
  -webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;
}
.page{max-width:1200px;margin:0 auto;padding:48px 32px 64px;}
header.page-header{margin-bottom:32px;}
header.page-header .eyebrow{font-size:12px;letter-spacing:.16em;text-transform:uppercase;color:var(--text-subtle);font-weight:500;margin-bottom:8px;}
header.page-header h1{margin:0 0 8px;font-size:30px;font-weight:700;letter-spacing:-.012em;}
header.page-header .subtitle{font-size:14px;color:var(--text-muted);}

section{background:var(--surface);padding:28px 32px;margin-bottom:24px;border-radius:var(--radius-md);
  box-shadow:var(--shadow-sm);border:1px solid var(--border);}
section h2{margin:0 0 6px;font-size:20px;font-weight:600;letter-spacing:-.008em;}
section h2 .num{font-family:'Inter',sans-serif;color:var(--accent);margin-right:10px;font-weight:600;}
section .section-desc{font-size:13px;color:var(--text-muted);margin:0 0 22px;}

table{border-collapse:separate;border-spacing:0;width:100%;}
th,td{padding:10px 14px;border-bottom:1px solid var(--border);font-size:13px;text-align:left;font-feature-settings:'tnum' 1;}
thead th{background:var(--surface-soft);font-weight:600;color:var(--text-muted);font-size:11px;text-transform:uppercase;letter-spacing:.08em;}
.probe-table tr.ok td:first-child{color:var(--green);font-weight:600;}
.probe-table tr.fail{background:#f7e3dd;}
.probe-table tr.fail td:first-child{color:var(--red);font-weight:600;}
.dist-table th,.dist-table td{text-align:center;}

.case{border:1px solid var(--border);border-radius:var(--radius-sm);padding:18px 22px;margin-bottom:16px;background:var(--surface);}
.case h3{margin:0 0 4px;font-size:15px;font-weight:600;}
.case .composite-line{font-size:13px;color:var(--text-muted);margin:0 0 12px;}
.case .composite-line strong{color:var(--text);font-feature-settings:'tnum' 1;}
.dim-block{border-left:3px solid var(--border);padding:10px 14px;margin:10px 0;border-radius:0 var(--radius-sm) var(--radius-sm) 0;}
.dim-block.status-success{border-left-color:var(--green);background:rgba(95,165,114,.04);}
.dim-block.status-parse-error{border-left-color:var(--red);background:rgba(196,99,77,.06);}
.dim-block.status-refuse{border-left-color:var(--yellow);background:rgba(212,160,69,.06);}
.dim-block.status-error{border-left-color:var(--text-subtle);background:var(--surface-soft);}
.dim-block h4{margin:0 0 6px;font-size:13px;font-weight:600;}
.dim-block .status{font-size:11px;color:var(--text-muted);font-weight:500;margin-left:6px;}
pre{background:var(--surface-soft);padding:12px 14px;border-radius:var(--radius-sm);font-size:12px;
  white-space:pre-wrap;overflow-x:auto;font-family:'SF Mono',Menlo,Consolas,monospace;border:1px solid var(--border);line-height:1.6;}
details summary{cursor:pointer;color:var(--text-muted);font-size:13px;padding:6px 0;}
details[open] summary{color:var(--text);font-weight:500;}
"""

_SMOKE_TEMPLATE = """<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>{title}</title>
<style>{css}</style>
</head><body>
<div class="page">
<header class="page-header">
<div class="eyebrow">KAON · IMAGE BENCHMARK · SMOKE</div>
<h1>{title}</h1>
<div class="subtitle">smoke 跑通后的连接状态、分数分布与每条用例的原始输出，便于诊断 parser 与 prompt。</div>
</header>
{probe}{dist}{cases}
</div>
</body></html>
"""
