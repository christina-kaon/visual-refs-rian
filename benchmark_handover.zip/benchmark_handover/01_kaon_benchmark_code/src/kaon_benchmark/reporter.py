"""HTML report generator: Section 1-6 self-contained single-file report."""

from __future__ import annotations

import html
import json
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from kaon_benchmark.tag_registry import TagRegistry, aggregate_scores_by_tag, parse_tag_json


# CDN scripts (Chart.js for charts; DataTables for the case detail table).
CHART_JS_CDN = "https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"
DATATABLES_CSS_CDN = "https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css"
DATATABLES_JQUERY_CDN = "https://code.jquery.com/jquery-3.7.1.min.js"
DATATABLES_JS_CDN = "https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"


@dataclass
class ReportContext:
    """Full per-case data the report needs.

    Each result dict expects:
        test_id, character_name, ref_image_path, generated_image_path,
        model_name, dialogue_context (str),
        a_tags (dict), p_tags (dict),
        dim1_score, dim2_score, dim3_score, dim4_score (float | None),
        dim1_sub_scores, dim2_sub_scores, dim3_sub_scores, dim4_sub_scores (dict | None),
        dim2_step1_description (dict | None),
        dim2_reasoning, dim3_reasoning, dim4_reasoning (str | None),
        composite_raw, composite_display (float | None),
        statuses (dict[dim_key, status_str]),
        penalty_applied (dict),
    """

    results: list[dict[str, Any]]
    registry: TagRegistry
    model_names: list[str]
    title: str = "KAON Image Benchmark Report"


def render_report(ctx: ReportContext, output_path: str | Path) -> Path:
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    html_text = _build_html(ctx)
    out.write_text(html_text, encoding="utf-8")
    return out


def _safe(v: Any) -> str:
    if v is None:
        return ""
    return html.escape(str(v))


def _fmt_score(s: float | None) -> str:
    if s is None:
        return "—"
    return f"{s:.2f}"


def _color_for_score_0_4(s: float | None) -> str:
    """Red <1.5, yellow 1.5-2.5, green >2.5 on the 0-4 scale."""
    if s is None:
        return "#bdbdbd"
    if s < 1.5:
        return "#d65a5a"
    if s <= 2.5:
        return "#e0b35a"
    return "#5aaa6a"


def _summary_stats(results: list[dict[str, Any]]) -> dict[str, Any]:
    n = len(results)
    success = sum(1 for r in results if any(r.get("statuses", {}).get(d) == "success" for d in ("d1", "d2", "d3", "d4")))
    error_count = 0
    refuse_count = 0
    for r in results:
        statuses = r.get("statuses", {})
        if any(v == "nsfw_refused" for v in statuses.values()):
            refuse_count += 1
        elif any(v in ("error", "parse_error") for v in statuses.values()):
            error_count += 1
    composites = [r["composite_display"] for r in results if r.get("composite_display") is not None]
    avg_composite = sum(composites) / len(composites) if composites else 0.0

    dim_means: dict[str, float] = {}
    for dim in ("dim1", "dim2", "dim3", "dim4"):
        vals = [r[f"{dim}_score"] for r in results if r.get(f"{dim}_score") is not None]
        dim_means[dim] = sum(vals) / len(vals) if vals else 0.0

    return {
        "total": n,
        "success": success,
        "error": error_count,
        "refuse": refuse_count,
        "avg_composite": avg_composite,
        "dim_means": dim_means,
        "success_rate": (success / n * 100.0) if n else 0.0,
    }


def _section1(stats: dict[str, Any]) -> str:
    cards = [
        ("总用例数", f"{stats['total']}"),
        ("成功率", f"{stats['success_rate']:.1f}%"),
        ("平均综合分（0-10）", f"{stats['avg_composite']:.2f}"),
        ("错误 / 拒答", f"{stats['error']} / {stats['refuse']}"),
    ]
    cards_html = "".join(
        f'<div class="card"><div class="card-label">{html.escape(label)}</div><div class="card-value">{html.escape(value)}</div></div>'
        for label, value in cards
    )

    dim_label = {"dim1": "D1 角色一致性", "dim2": "D2 剧情匹配", "dim3": "D3 视觉吸引力", "dim4": "D4 技术质量"}
    gauges_html = ""
    for dim in ("dim1", "dim2", "dim3", "dim4"):
        score = stats["dim_means"][dim]
        color = _color_for_score_0_4(score)
        pct = max(0.0, min(score / 4.0, 1.0)) * 100.0
        gauges_html += (
            f'<div class="gauge"><div class="gauge-label">{dim_label[dim]}</div>'
            f'<div class="gauge-bar"><div class="gauge-fill" style="width:{pct:.1f}%;background:{color};"></div></div>'
            f'<div class="gauge-value">{score:.2f} / 4.0</div></div>'
        )

    return (
        '<section id="section1"><h2><span class="num">01</span>概览仪表盘</h2>'
        '<p class="section-desc">整体表现快照：总量、成功率、平均综合分，以及四个评分维度的均值刻度。</p>'
        f'<div class="cards">{cards_html}</div>'
        f'<div class="gauges">{gauges_html}</div>'
        "</section>"
    )


def _section2(results: list[dict[str, Any]], model_names: list[str]) -> str:
    if len(model_names) < 2:
        return ""
    per_model_means: dict[str, dict[str, float]] = {}
    for m in model_names:
        rows = [r for r in results if r.get("model_name") == m]
        per_model_means[m] = {}
        for dim in ("dim1", "dim2", "dim3", "dim4"):
            vals = [r[f"{dim}_score"] for r in rows if r.get(f"{dim}_score") is not None]
            per_model_means[m][dim] = (sum(vals) / len(vals)) if vals else 0.0

    chart_data = {
        "labels": ["D1 角色", "D2 剧情", "D3 视觉", "D4 技术"],
        "datasets": [
            {
                "label": m,
                "data": [per_model_means[m]["dim1"], per_model_means[m]["dim2"],
                         per_model_means[m]["dim3"], per_model_means[m]["dim4"]],
            }
            for m in model_names
        ],
    }
    return (
        '<section id="section2"><h2><span class="num">02</span>模型对比</h2>'
        '<p class="section-desc">多个生成模型在四个维度上的平均得分对比（条形图）与综合形态对比（雷达图）。</p>'
        '<div class="charts-row">'
        '<div class="chart-half"><canvas id="modelBarChart"></canvas></div>'
        '<div class="chart-half"><canvas id="modelRadarChart"></canvas></div>'
        "</div>"
        f'<script>window.__modelChartData = {json.dumps(chart_data, ensure_ascii=False)};</script>'
        "</section>"
    )


def _topbottom_cards(results: list[dict[str, Any]], registry: TagRegistry, *, n_items: int = 5, min_samples: int = 5) -> str:
    rows: list[tuple[str, str, str, float, int]] = []
    for dim in registry.all_dimensions():
        agg = aggregate_scores_by_tag(
            results, dim.line, dim.key, "composite_display",
            min_samples=min_samples, registry=registry,
        )
        for entry in agg:
            rows.append((dim.line, dim.display_name, entry["tag_value"], entry["mean_score"], entry["count"]))

    if not rows:
        return ""
    rows_sorted = sorted(rows, key=lambda x: x[3])
    bottom = rows_sorted[:n_items]
    top = list(reversed(rows_sorted))[:n_items]

    def _make_card(items: list[tuple[str, str, str, float, int]], color_class: str, title: str) -> str:
        body = "".join(
            f'<li><span class="dim">{html.escape(disp)}</span>：'
            f'<span class="val">{html.escape(val)}</span> · '
            f'<span class="score">{score:.2f}</span> '
            f'<span class="count">（{count} 条）</span></li>'
            for _line, disp, val, score, count in items
        )
        return f'<div class="topbottom-card {color_class}"><h4>{title}</h4><ul>{body}</ul></div>'

    return _make_card(top, "card-top", "🟢 表现最好的标签") + _make_card(bottom, "card-bottom", "🔴 表现最差的标签")


def _heatmap_data(results: list[dict[str, Any]], registry: TagRegistry, min_samples: int = 5) -> dict[str, Any]:
    """Pre-compute heatmap rows for every tag dimension.

    Output:
        {
          "dimensions": [{"key", "display_name", "line"}, ...],
          "matrix": {
              dim_key: {
                  "tag_values": ["v1","v2",...],            # sorted by sample-count desc
                  "rows": {
                      "dim1": [{mean, count} for each tag_value],
                      "dim2": [...], "dim3": [...], "dim4": [...]
                  }
              }
          }
        }
    """
    dimensions: list[dict[str, str]] = []
    matrix: dict[str, dict[str, Any]] = {}

    for dim in registry.all_dimensions():
        is_multi = dim.multi_value
        bucket: dict[str, dict[str, list[float]]] = defaultdict(lambda: {"d1": [], "d2": [], "d3": [], "d4": []})
        bucket_count: Counter = Counter()
        tags_field = "a_tags" if dim.line == "a" else "p_tags"
        for r in results:
            tags = r.get(tags_field) or {}
            raw = tags.get(dim.key) if isinstance(tags, dict) else None
            if not raw:
                continue
            values = [v.strip() for v in str(raw).split(",")] if is_multi else [str(raw).strip()]
            for v in values:
                if not v:
                    continue
                bucket_count[v] += 1
                for d_short, score_key in (("d1", "dim1_score"), ("d2", "dim2_score"), ("d3", "dim3_score"), ("d4", "dim4_score")):
                    s = r.get(score_key)
                    if s is not None:
                        bucket[v][d_short].append(float(s))

        kept = [(v, c) for v, c in bucket_count.most_common() if c >= min_samples]
        if not kept:
            continue
        tag_values = [v for v, _ in kept]
        rows = {"d1": [], "d2": [], "d3": [], "d4": []}
        for d_short in ("d1", "d2", "d3", "d4"):
            for v in tag_values:
                vals = bucket[v][d_short]
                if vals:
                    rows[d_short].append({"mean": sum(vals) / len(vals), "count": len(vals)})
                else:
                    rows[d_short].append({"mean": None, "count": 0})

        matrix[dim.key] = {"tag_values": tag_values, "rows": rows}
        dimensions.append({"key": dim.key, "display_name": dim.display_name, "line": dim.line})

    return {"dimensions": dimensions, "matrix": matrix}


def _section3(results: list[dict[str, Any]], registry: TagRegistry) -> str:
    cards = _topbottom_cards(results, registry, n_items=5, min_samples=5)
    heatmap = _heatmap_data(results, registry, min_samples=5)
    a_options = []
    p_options = []
    for dim_meta in heatmap["dimensions"]:
        opt = (
            f'<option value="{html.escape(dim_meta["key"])}" data-line="{html.escape(dim_meta["line"])}">'
            f'{html.escape(dim_meta["display_name"])}</option>'
        )
        (a_options if dim_meta["line"] == "a" else p_options).append(opt)
    select_html = (
        '<select id="heatmap-dim-select">'
        f'<optgroup label="A 线（图像特征）">{"".join(a_options)}</optgroup>'
        f'<optgroup label="P 线（场景特征）">{"".join(p_options)}</optgroup>'
        '</select>'
    )

    return (
        '<section id="section3"><h2><span class="num">03</span>标签聚类分析</h2>'
        '<p class="section-desc">按 A 线（图像特征）/ P 线（场景特征）各维度聚合分数，找出表现最好与最差的标签值；下方热力图可切换维度查看四个评分维度的分布。</p>'
        '<div class="topbottom-row">'
        f'{cards}'
        '</div>'
        '<h3>交互式热力图</h3>'
        '<div class="heatmap-controls">'
        f'<label>维度：{select_html}</label>'
        '<label>最低样本数：<input type="number" id="heatmap-min-samples" value="5" min="1" step="1" /></label>'
        '</div>'
        '<div id="heatmap-region"></div>'
        f'<script>window.__heatmapData = {json.dumps(heatmap, ensure_ascii=False)};</script>'
        "</section>"
    )


def _section4(results: list[dict[str, Any]]) -> str:
    histograms: dict[str, list[int]] = {}
    for dim in ("dim1", "dim2", "dim3", "dim4"):
        bins = [0, 0, 0, 0, 0]
        for r in results:
            s = r.get(f"{dim}_score")
            if s is None:
                continue
            idx = max(0, min(int(s), 4))
            bins[idx] += 1
        histograms[dim] = bins

    composite_bins = [0] * 11
    for r in results:
        s = r.get("composite_display")
        if s is None:
            continue
        idx = max(0, min(int(round(s)), 10))
        composite_bins[idx] += 1

    scatter = []
    for r in results:
        x = r.get("dim1_score"); y = r.get("dim3_score"); c = r.get("composite_display")
        if x is not None and y is not None and c is not None:
            scatter.append({"x": x, "y": y, "c": c, "id": r.get("test_id")})

    fd_bins = [0, 0, 0, 0, 0]
    fd_total = 0
    fd_capped = 0
    for r in results:
        sub = r.get("dim4_sub_scores") or {}
        if "facial_distortion" in sub:
            fd_total += 1
            v = max(0, min(int(sub["facial_distortion"]), 4))
            fd_bins[v] += 1
            if v <= 1:
                fd_capped += 1
    fd_capped_pct = (fd_capped / fd_total * 100.0) if fd_total else 0.0

    payload = {
        "histograms": histograms,
        "composite": composite_bins,
        "scatter": scatter,
        "fd_bins": fd_bins,
        "fd_capped_pct": fd_capped_pct,
    }
    return (
        '<section id="section4"><h2><span class="num">04</span>分布与异常值</h2>'
        '<p class="section-desc">各维度分数与综合分的整体分布；D1×D3 散点用于发现"角色像但不好看"或"好看但不像"的异常 case。</p>'
        '<div class="charts-row">'
        '<div class="chart-half"><canvas id="dimHistChart"></canvas></div>'
        '<div class="chart-half"><canvas id="compositeHistChart"></canvas></div>'
        "</div>"
        '<div class="charts-row">'
        '<div class="chart-half"><canvas id="scatterChart"></canvas></div>'
        f'<div class="chart-half"><canvas id="fdHistChart"></canvas><div class="caption">facial_distortion ≤1 触发了 '
        f'<strong>{fd_capped_pct:.1f}%</strong> 用例的硬惩罚封顶（{fd_capped}/{fd_total} 条）</div></div>'
        "</div>"
        f'<script>window.__distData = {json.dumps(payload, ensure_ascii=False)};</script>'
        "</section>"
    )


def _section5(results: list[dict[str, Any]], registry: TagRegistry) -> str:
    pinned = registry.pinned_dimensions()
    pinned_keys = [d.key for d in pinned]
    pinned_headers = "".join(f'<th>{html.escape(d.display_name)}</th>' for d in pinned)

    headers = (
        '<th>test_id</th><th>角色</th><th>参考图</th><th>生成图</th>'
        + pinned_headers
        + '<th>D1</th><th>D2</th><th>D3</th><th>D4</th><th>综合分</th>'
        + '<th>状态</th><th>硬惩罚</th>'
    )

    rows_html: list[str] = []
    for r in results:
        statuses = r.get("statuses", {})
        worst_status = "success"
        for v in statuses.values():
            if v in ("nsfw_refused", "error", "parse_error") and worst_status == "success":
                worst_status = v
        penalty = r.get("penalty_applied", {}) or {}
        penalty_icons = []
        if penalty.get("facial_distortion_cap"):
            penalty_icons.append("⚠️FD")
        if penalty.get("dim4_cap"):
            penalty_icons.append("⚠️D4")
        if penalty.get("dim1_cap"):
            penalty_icons.append("⚠️D1")
        penalty_str = " ".join(penalty_icons) if penalty_icons else "—"

        ref = r.get("ref_image_path") or ""
        gen = r.get("generated_image_path") or ""
        ref_img = f'<img class="thumb" src="{html.escape(ref)}" loading="lazy" />' if ref else "—"
        gen_img = f'<img class="thumb" src="{html.escape(gen)}" loading="lazy" />' if gen else "—"

        a_tags = r.get("a_tags") or {}
        p_tags = r.get("p_tags") or {}
        pinned_cells = ""
        for d in pinned:
            tags_dict = a_tags if d.line == "a" else p_tags
            v = tags_dict.get(d.key) if isinstance(tags_dict, dict) else None
            pinned_cells += f"<td>{html.escape(str(v)) if v else '—'}</td>"

        score_cell = lambda s: (
            f'<td style="background:{_color_for_score_0_4(s)}33">{_fmt_score(s)}</td>'
        )
        comp = r.get("composite_display")
        comp_cell = f'<td><strong>{_fmt_score(comp)}</strong></td>' if comp is not None else "<td>—</td>"

        details_payload = json.dumps({
            "test_id": r.get("test_id"),
            "character_name": r.get("character_name"),
            "ref": ref,
            "gen": gen,
            "dialogue_context": r.get("dialogue_context") or "",
            "dim1_sub_scores": r.get("dim1_sub_scores"),
            "dim2_sub_scores": r.get("dim2_sub_scores"),
            "dim3_sub_scores": r.get("dim3_sub_scores"),
            "dim4_sub_scores": r.get("dim4_sub_scores"),
            "dim2_step1_description": r.get("dim2_step1_description"),
            "dim2_reasoning": r.get("dim2_reasoning"),
            "dim3_reasoning": r.get("dim3_reasoning"),
            "dim4_reasoning": r.get("dim4_reasoning"),
            "a_tags": a_tags, "p_tags": p_tags,
            "statuses": statuses,
            "errors": r.get("errors") or {},
        }, ensure_ascii=False)
        details_b64 = json.dumps(details_payload, ensure_ascii=False)

        rows_html.append(
            "<tr class=\"case-row\" data-details='" + details_payload.replace("'", "&#39;") + "'>"
            f"<td>{_safe(r.get('test_id'))}</td>"
            f"<td>{_safe(r.get('character_name'))}</td>"
            f"<td>{ref_img}</td><td>{gen_img}</td>"
            f"{pinned_cells}"
            f"{score_cell(r.get('dim1_score'))}{score_cell(r.get('dim2_score'))}"
            f"{score_cell(r.get('dim3_score'))}{score_cell(r.get('dim4_score'))}"
            f"{comp_cell}"
            f"<td>{_safe(worst_status)}</td>"
            f"<td>{penalty_str}</td>"
            "</tr>"
        )

    a_dims_for_detail = [d for d in registry.all_dimensions() if d.line == "a"]
    p_dims_for_detail = [d for d in registry.all_dimensions() if d.line == "p"]

    return (
        '<section id="section5"><h2><span class="num">05</span>用例详情</h2>'
        '<p class="section-desc">支持搜索与排序；点击任意一行可展开查看大图对比、对话上下文、子分数明细、reasoning 文本与完整标签信息。</p>'
        '<table id="caseTable" class="display"><thead><tr>'
        f'{headers}</tr></thead><tbody>{"".join(rows_html)}</tbody></table>'
        '<div id="case-detail-pane" class="case-detail-pane hidden">'
        '<button id="case-detail-close">关闭</button>'
        '<div id="case-detail-body"></div></div>'
        f'<script>window.__caseRegistry = {json.dumps({"a": [d.__dict__ for d in a_dims_for_detail], "p": [d.__dict__ for d in p_dims_for_detail]}, ensure_ascii=False)};</script>'
        "</section>"
    )


def _section6(results: list[dict[str, Any]], registry: TagRegistry) -> str:
    composite_sorted = sorted(
        (r for r in results if r.get("composite_display") is not None),
        key=lambda r: r["composite_display"],
    )
    n_worst = max(1, int(len(composite_sorted) * 0.10))
    worst = composite_sorted[:n_worst]
    worst_lines: list[str] = []
    for r in worst:
        gen = r.get("generated_image_path") or ""
        thumb = f'<img class="thumb" src="{html.escape(gen)}" loading="lazy" />' if gen else "—"
        worst_lines.append(
            f'<tr><td>{_safe(r.get("test_id"))}</td><td>{_safe(r.get("character_name"))}</td>'
            f'<td>{thumb}</td>'
            f'<td><strong>{_fmt_score(r.get("composite_display"))}</strong></td></tr>'
        )
    worst_rows = "".join(worst_lines)

    weak_dim_rows: list[tuple[str, str, str, float, int]] = []
    for dim in registry.all_dimensions():
        agg = aggregate_scores_by_tag(
            results, dim.line, dim.key, "composite_display",
            min_samples=5, registry=registry,
        )
        for entry in agg:
            weak_dim_rows.append((dim.line, dim.display_name, entry["tag_value"], entry["mean_score"], entry["count"]))
    weak_dim_rows.sort(key=lambda x: x[3])
    weak_top10 = weak_dim_rows[:10]
    weak_html = "".join(
        f'<tr><td>{html.escape(disp)}</td><td>{html.escape(val)}</td>'
        f'<td>{score:.2f}</td><td>{count}</td></tr>'
        for _line, disp, val, score, count in weak_top10
    )

    refuse_count = sum(1 for r in results if any(v == "nsfw_refused" for v in (r.get("statuses") or {}).values()))
    refuse_pct = (refuse_count / len(results) * 100.0) if results else 0.0
    fd_caps = sum(1 for r in results if (r.get("penalty_applied") or {}).get("facial_distortion_cap"))
    d4_caps = sum(1 for r in results if (r.get("penalty_applied") or {}).get("dim4_cap"))
    d1_caps = sum(1 for r in results if (r.get("penalty_applied") or {}).get("dim1_cap"))

    return (
        '<section id="section6"><h2><span class="num">06</span>薄弱项总结</h2>'
        '<p class="section-desc">综合分最低的 10% 用例、各标签维度的最弱项，以及硬惩罚规则的触发统计——用于定位主要失败模式。</p>'
        f'<h3>综合分最低 10% 用例（n = {n_worst}）</h3>'
        '<table class="weak-table"><thead><tr><th>test_id</th><th>角色</th><th>生成图</th><th>综合分</th></tr></thead>'
        f'<tbody>{worst_rows}</tbody></table>'
        '<h3>标签维度薄弱项（按综合分均值升序）</h3>'
        '<table class="weak-table"><thead><tr><th>维度</th><th>标签值</th><th>平均分</th><th>样本数</th></tr></thead>'
        f'<tbody>{weak_html}</tbody></table>'
        f'<h3>硬惩罚触发统计</h3>'
        f'<ul class="penalty-stats">'
        f'<li>facial_distortion ≤1 → D4 封顶：<strong>{fd_caps}</strong> 条</li>'
        f'<li>D4 ≤1.0 → 综合分封顶 3.0：<strong>{d4_caps}</strong> 条</li>'
        f'<li>D1 ≤0.5 → 综合分封顶 1.0：<strong>{d1_caps}</strong> 条</li></ul>'
        f'<h3>NSFW 拒答</h3>'
        f'<p>{refuse_count} 条 （{refuse_pct:.1f}%）</p>'
        "</section>"
    )


def _build_html(ctx: ReportContext) -> str:
    stats = _summary_stats(ctx.results)
    s1 = _section1(stats)
    s2 = _section2(ctx.results, ctx.model_names)
    s3 = _section3(ctx.results, ctx.registry)
    s4 = _section4(ctx.results)
    s5 = _section5(ctx.results, ctx.registry)
    s6 = _section6(ctx.results, ctx.registry)

    return _HTML_TEMPLATE.format(
        title=html.escape(ctx.title),
        subtitle=html.escape(
            f"共 {stats['total']} 条用例 · 成功率 {stats['success_rate']:.1f}% · "
            f"平均综合分 {stats['avg_composite']:.2f} / 10"
        ),
        chart_js=CHART_JS_CDN,
        dt_css=DATATABLES_CSS_CDN,
        dt_jquery=DATATABLES_JQUERY_CDN,
        dt_js=DATATABLES_JS_CDN,
        section1=s1, section2=s2, section3=s3,
        section4=s4, section5=s5, section6=s6,
        custom_js=_REPORT_JS,
        custom_css=_REPORT_CSS,
    )


_REPORT_CSS = """
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Noto+Sans+SC:wght@400;500;600;700&display=swap');
:root{
  --bg:#faf9f7;
  --surface:#ffffff;
  --surface-soft:#f5f3ef;
  --border:#e8e4dd;
  --border-strong:#d6d1c8;
  --text:#1f1d1a;
  --text-muted:#6b6862;
  --text-subtle:#94918a;
  --accent:#c96442;
  --accent-soft:#f6ece6;
  --accent-strong:#a84e30;
  --green:#5fa572;
  --green-soft:#e8f1ea;
  --yellow:#d4a045;
  --yellow-soft:#faf1de;
  --red:#c4634d;
  --red-soft:#f7e3dd;
  --grey-soft:#efedea;
  --shadow-sm:0 1px 2px rgba(35,30,22,.04),0 0 0 1px rgba(35,30,22,.02);
  --shadow-md:0 4px 16px rgba(35,30,22,.06),0 0 0 1px rgba(35,30,22,.04);
  --radius-sm:8px;
  --radius-md:12px;
  --radius-lg:16px;
}
*{box-sizing:border-box;}
html,body{margin:0;padding:0;}
body{
  font-family:'Inter','Noto Sans SC',-apple-system,BlinkMacSystemFont,'PingFang SC','Hiragino Sans GB','Microsoft YaHei',sans-serif;
  background:var(--bg);color:var(--text);
  font-size:14px;line-height:1.6;
  -webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;
  letter-spacing:0;
}
.page{max-width:1280px;margin:0 auto;padding:48px 32px 64px;}
header.page-header{margin-bottom:40px;display:flex;flex-direction:column;gap:8px;}
header.page-header .eyebrow{
  font-size:12px;letter-spacing:.16em;text-transform:uppercase;
  color:var(--text-subtle);font-weight:500;
}
header.page-header h1{
  margin:0;font-size:32px;font-weight:700;letter-spacing:-.012em;
  color:var(--text);font-family:'Inter','Noto Sans SC',sans-serif;
}
header.page-header .subtitle{font-size:14px;color:var(--text-muted);max-width:720px;}

section{
  background:var(--surface);
  padding:28px 32px;border-radius:var(--radius-md);
  box-shadow:var(--shadow-sm);
  margin-bottom:24px;
  border:1px solid var(--border);
}
section h2{
  margin:0 0 6px;font-size:20px;font-weight:600;letter-spacing:-.008em;
  color:var(--text);
}
section h2 .num{
  font-family:'Inter',sans-serif;color:var(--accent);
  margin-right:10px;font-weight:600;
}
section .section-desc{font-size:13px;color:var(--text-muted);margin:0 0 24px;}
section h3{font-size:15px;font-weight:600;margin:24px 0 12px;color:var(--text);}
section h4{font-size:14px;font-weight:600;margin:0 0 10px;color:var(--text);}

.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin-bottom:24px;}
.card{
  background:var(--surface-soft);
  padding:18px 20px;border-radius:var(--radius-sm);
  border:1px solid var(--border);
}
.card-label{
  font-size:11px;color:var(--text-subtle);
  text-transform:uppercase;letter-spacing:.08em;font-weight:500;
}
.card-value{font-size:28px;font-weight:600;margin-top:6px;letter-spacing:-.012em;
  font-feature-settings:'tnum' 1;color:var(--text);}

.gauges{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;}
.gauge{padding:14px 16px;background:var(--surface-soft);border-radius:var(--radius-sm);border:1px solid var(--border);}
.gauge-label{font-size:13px;color:var(--text-muted);margin-bottom:8px;font-weight:500;}
.gauge-bar{background:var(--grey-soft);border-radius:999px;height:8px;overflow:hidden;}
.gauge-fill{height:100%;transition:width .35s cubic-bezier(.4,0,.2,1);border-radius:999px;}
.gauge-value{font-size:13px;color:var(--text);margin-top:8px;font-feature-settings:'tnum' 1;font-weight:500;}

.charts-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(360px,1fr));gap:20px;margin-top:8px;}
.chart-half{
  background:var(--surface-soft);
  padding:18px;border-radius:var(--radius-sm);
  border:1px solid var(--border);min-height:320px;
}
.caption{font-size:12px;color:var(--text-muted);margin-top:10px;text-align:center;}

.topbottom-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:16px;}
.topbottom-card{padding:18px 22px;border-radius:var(--radius-sm);border:1px solid var(--border);}
.topbottom-card.card-top{background:var(--green-soft);border-color:#cee0d3;}
.topbottom-card.card-bottom{background:var(--red-soft);border-color:#e7c8c1;}
.topbottom-card h4{font-size:13px;font-weight:600;color:var(--text);margin-bottom:12px;letter-spacing:.01em;}
.topbottom-card ul{padding:0;margin:0;list-style:none;}
.topbottom-card li{font-size:13px;line-height:1.8;padding:4px 0;border-bottom:1px dashed rgba(0,0,0,.06);}
.topbottom-card li:last-child{border-bottom:0;}
.topbottom-card .dim{color:var(--text-muted);font-size:12px;}
.topbottom-card .val{font-weight:600;color:var(--text);}
.topbottom-card .score{font-weight:600;font-feature-settings:'tnum' 1;color:var(--text);}
.topbottom-card .count{color:var(--text-subtle);font-size:12px;}

.heatmap-controls{
  margin:20px 0 12px;display:flex;gap:18px;align-items:center;flex-wrap:wrap;
  padding:14px 16px;background:var(--surface-soft);border-radius:var(--radius-sm);border:1px solid var(--border);
}
.heatmap-controls label{font-size:13px;color:var(--text-muted);display:flex;align-items:center;gap:8px;}
.heatmap-controls select,.heatmap-controls input{
  font-family:inherit;font-size:13px;padding:6px 10px;border:1px solid var(--border-strong);
  border-radius:6px;background:var(--surface);color:var(--text);
}
.heatmap-controls input{width:80px;}
.heatmap-table{border-collapse:separate;border-spacing:0;margin-top:8px;width:100%;}
.heatmap-table th,.heatmap-table td{
  border-bottom:1px solid var(--border);border-right:1px solid var(--border);
  padding:10px 12px;font-size:13px;text-align:center;font-feature-settings:'tnum' 1;
}
.heatmap-table th:first-child,.heatmap-table td:first-child{border-left:1px solid var(--border);}
.heatmap-table thead th{background:var(--surface-soft);font-weight:600;border-top:1px solid var(--border);}
.heatmap-table .row-label{font-weight:600;background:var(--surface-soft);text-align:left;color:var(--text);}
.heatmap-cell{position:relative;cursor:default;}
.heatmap-cell .cnt{font-size:11px;color:var(--text-subtle);display:block;margin-top:2px;}

.weak-table{border-collapse:separate;border-spacing:0;width:100%;margin-top:6px;}
.weak-table th,.weak-table td{
  border-bottom:1px solid var(--border);padding:10px 12px;font-size:13px;text-align:left;
  font-feature-settings:'tnum' 1;
}
.weak-table thead th{background:var(--surface-soft);font-weight:600;color:var(--text);
  text-transform:uppercase;letter-spacing:.06em;font-size:11px;}

.thumb{width:56px;height:56px;object-fit:cover;border-radius:6px;border:1px solid var(--border);}

table.dataTable{border-collapse:separate !important;border-spacing:0;width:100%;margin-top:12px;}
table.dataTable thead th{
  background:var(--surface-soft);border-bottom:1px solid var(--border);
  font-weight:600;font-size:11px;color:var(--text-muted);
  text-transform:uppercase;letter-spacing:.08em;
  padding:12px 14px;
}
table.dataTable tbody td{
  vertical-align:middle;font-size:13px;
  padding:12px 14px;border-bottom:1px solid var(--border);
  font-feature-settings:'tnum' 1;
}
table.dataTable.display tbody tr.odd{background:transparent;}
table.dataTable.display tbody tr.even{background:rgba(245,243,239,.4);}
.dataTables_wrapper .dataTables_filter input,
.dataTables_wrapper .dataTables_length select{
  border:1px solid var(--border-strong);border-radius:6px;padding:6px 10px;
  font-family:inherit;font-size:13px;background:var(--surface);
}
.dataTables_wrapper .dataTables_paginate .paginate_button{
  padding:6px 12px;border-radius:6px;font-size:13px;
}
.dataTables_wrapper .dataTables_paginate .paginate_button.current{
  background:var(--accent) !important;color:#fff !important;border:0 !important;
}

.case-row{cursor:pointer;transition:background-color .12s;}
.case-row:hover{background:var(--accent-soft) !important;}
.case-detail-pane{
  position:fixed;top:5%;left:5%;right:5%;bottom:5%;
  background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);
  padding:32px 40px;overflow-y:auto;box-shadow:var(--shadow-md);z-index:1000;
}
.case-detail-pane.hidden{display:none;}
.case-detail-pane #case-detail-close{
  float:right;background:var(--text);color:var(--surface);border:0;
  padding:8px 16px;border-radius:8px;cursor:pointer;font-family:inherit;font-size:13px;font-weight:500;
}
.case-detail-pane #case-detail-close:hover{background:var(--accent);}
.case-detail-pane h2{margin:0 0 18px;font-size:22px;font-weight:600;}
.case-detail-pane h3{margin-top:24px;font-size:14px;font-weight:600;color:var(--text);}
.case-detail-pane .imgs{display:flex;gap:16px;margin:12px 0;}
.case-detail-pane .imgs img{
  max-width:48%;max-height:320px;object-fit:contain;
  border:1px solid var(--border);border-radius:var(--radius-sm);background:var(--surface-soft);
}
.case-detail-pane pre{
  background:var(--surface-soft);padding:14px 16px;border-radius:var(--radius-sm);
  overflow-x:auto;font-size:12px;font-family:'SF Mono',Menlo,Consolas,monospace;
  border:1px solid var(--border);line-height:1.6;
}
.case-detail-pane .tag-line{font-size:13px;margin:6px 0;line-height:1.8;}
.case-detail-pane .tag-line .key{color:var(--text-muted);}
.penalty-stats{display:flex;gap:12px;flex-wrap:wrap;list-style:none;padding:0;margin:8px 0 0;}
.penalty-stats li{
  background:var(--accent-soft);border:1px solid #e8d5cb;
  padding:8px 14px;border-radius:var(--radius-sm);font-size:13px;color:var(--text);
}
.penalty-stats li strong{color:var(--accent-strong);font-feature-settings:'tnum' 1;}
"""


_REPORT_JS = r"""
function colorForScore(s){
  if(s===null||s===undefined||isNaN(s))return '#bdbdbd';
  if(s<1.5)return '#d65a5a';
  if(s<=2.5)return '#e0b35a';
  return '#5aaa6a';
}

window.addEventListener('DOMContentLoaded',function(){
  // Section 2 — model bar + radar
  if(window.__modelChartData){
    var ctx1=document.getElementById('modelBarChart');
    if(ctx1){new Chart(ctx1,{type:'bar',data:window.__modelChartData,options:{responsive:true,scales:{y:{min:0,max:4}}}});}
    var ctx2=document.getElementById('modelRadarChart');
    if(ctx2){new Chart(ctx2,{type:'radar',data:window.__modelChartData,options:{responsive:true,scales:{r:{min:0,max:4}}}});}
  }

  // Section 3 — heatmap
  function renderHeatmap(){
    var sel=document.getElementById('heatmap-dim-select');
    if(!sel)return;
    var dimKey=sel.value;
    var minSamples=parseInt(document.getElementById('heatmap-min-samples').value)||1;
    var data=window.__heatmapData;
    var entry=data.matrix[dimKey];
    var region=document.getElementById('heatmap-region');
    if(!entry){region.innerHTML='<p>No data for this dimension.</p>';return;}
    var keptIdx=[];
    entry.tag_values.forEach(function(v,i){
      var anyCount=Math.max(entry.rows.d1[i].count,entry.rows.d2[i].count,entry.rows.d3[i].count,entry.rows.d4[i].count);
      if(anyCount>=minSamples)keptIdx.push(i);
    });
    if(keptIdx.length===0){region.innerHTML='<p>No tag values meet the min-samples threshold.</p>';return;}
    var html='<table class="heatmap-table"><thead><tr><th></th>';
    keptIdx.forEach(function(i){html+='<th>'+entry.tag_values[i]+'</th>';});
    html+='</tr></thead><tbody>';
    var dimLabel={d1:'D1 角色',d2:'D2 剧情',d3:'D3 视觉',d4:'D4 技术'};
    ['d1','d2','d3','d4'].forEach(function(d){
      html+='<tr><td class="row-label">'+dimLabel[d]+'</td>';
      keptIdx.forEach(function(i){
        var c=entry.rows[d][i];
        if(c.mean===null||c.mean===undefined){
          html+='<td class="heatmap-cell" style="background:#eee">—</td>';
        }else{
          html+='<td class="heatmap-cell" title="'+entry.tag_values[i]+' / '+dimLabel[d]+'\nmean='+c.mean.toFixed(2)+'\nn='+c.count+'" style="background:'+colorForScore(c.mean)+'33">'+c.mean.toFixed(2)+'<span class="cnt">n='+c.count+'</span></td>';
        }
      });
      html+='</tr>';
    });
    html+='</tbody></table>';
    region.innerHTML=html;
  }
  if(window.__heatmapData){
    var sel=document.getElementById('heatmap-dim-select');
    if(sel){
      sel.addEventListener('change',renderHeatmap);
      document.getElementById('heatmap-min-samples').addEventListener('input',renderHeatmap);
      renderHeatmap();
    }
  }

  // Section 4 — distribution charts
  if(window.__distData){
    var d=window.__distData;
    var dimHistCtx=document.getElementById('dimHistChart');
    if(dimHistCtx){
      new Chart(dimHistCtx,{type:'bar',data:{labels:['0','1','2','3','4'],datasets:[
        {label:'D1 角色',data:d.histograms.dim1},
        {label:'D2 剧情',data:d.histograms.dim2},
        {label:'D3 视觉',data:d.histograms.dim3},
        {label:'D4 技术',data:d.histograms.dim4}
      ]},options:{responsive:true,plugins:{title:{display:true,text:'各维度分数分布'}}}});
    }
    var compCtx=document.getElementById('compositeHistChart');
    if(compCtx){
      new Chart(compCtx,{type:'bar',data:{labels:['0','1','2','3','4','5','6','7','8','9','10'],datasets:[{label:'综合分（0-10）',data:d.composite}]},options:{responsive:true,plugins:{title:{display:true,text:'综合分分布'}}}});
    }
    var scCtx=document.getElementById('scatterChart');
    if(scCtx&&d.scatter.length){
      new Chart(scCtx,{type:'scatter',data:{datasets:[{label:'D1 × D3（颜色 = 综合分）',data:d.scatter.map(function(p){return{x:p.x,y:p.y};}),backgroundColor:d.scatter.map(function(p){return colorForScore(p.c/2.5);}),pointRadius:5}]},options:{responsive:true,scales:{x:{title:{display:true,text:'D1 角色一致性'},min:0,max:4},y:{title:{display:true,text:'D3 视觉吸引力'},min:0,max:4}},plugins:{title:{display:true,text:'D1 × D3 散点（每个点 = 一条用例）'}}}});
    }
    var fdCtx=document.getElementById('fdHistChart');
    if(fdCtx){
      new Chart(fdCtx,{type:'bar',data:{labels:['0','1','2','3','4'],datasets:[{label:'facial_distortion 子分数',data:d.fd_bins,backgroundColor:['#c4634d','#c4634d','#d4a045','#5fa572','#5fa572']}]},options:{responsive:true,plugins:{title:{display:true,text:'D4 — 面部扭曲（facial_distortion）子分数分布'}}}});
    }
  }

  // Section 5 — DataTables + click-to-detail
  if(window.jQuery&&window.jQuery.fn.dataTable){
    window.jQuery('#caseTable').DataTable({order:[[10,'asc']],pageLength:25});
  }
  document.querySelectorAll('.case-row').forEach(function(row){
    row.addEventListener('click',function(){
      var raw=row.getAttribute('data-details');
      if(!raw)return;
      var d;try{d=JSON.parse(raw);}catch(e){return;}
      var pane=document.getElementById('case-detail-pane');
      var body=document.getElementById('case-detail-body');
      var aDims=window.__caseRegistry.a;var pDims=window.__caseRegistry.p;
      function tagsText(tags,dims){
        var out=[];dims.forEach(function(dm){
          if(tags&&tags[dm.key]!==undefined&&tags[dm.key]!==''){
            out.push('<span class="key">'+dm.display_name+':</span> '+tags[dm.key]);
          }
        });return out.join(' | ');
      }
      var html='<h2>'+d.test_id+' — '+(d.character_name||'')+'</h2>';
      html+='<div class="imgs">';
      if(d.ref)html+='<img src="'+d.ref+'" />';
      if(d.gen)html+='<img src="'+d.gen+'" />';
      html+='</div>';
      html+='<h3>对话上下文（前 5 轮）</h3><pre>'+(d.dialogue_context||'（无）')+'</pre>';
      var dimZh={dim1:'D1 角色一致性',dim2:'D2 剧情匹配',dim3:'D3 视觉吸引力',dim4:'D4 技术质量'};
      ['dim1','dim2','dim3','dim4'].forEach(function(k){
        if(d[k+'_sub_scores']){
          html+='<h3>'+dimZh[k]+' · 子分数</h3><pre>'+JSON.stringify(d[k+'_sub_scores'],null,2)+'</pre>';
        }
      });
      if(d.dim2_step1_description){
        html+='<h3>D2 第一步 — 视觉描述</h3><pre>'+JSON.stringify(d.dim2_step1_description,null,2)+'</pre>';
      }
      ['dim2','dim3','dim4'].forEach(function(k){
        if(d[k+'_reasoning']){
          html+='<h3>'+dimZh[k]+' · 推理</h3><pre>'+d[k+'_reasoning']+'</pre>';
        }
      });
      html+='<h3>标签信息</h3>';
      html+='<div class="tag-line"><strong>A 线（图像特征）</strong>：'+(tagsText(d.a_tags,aDims)||'（无）')+'</div>';
      html+='<div class="tag-line"><strong>P 线（场景特征）</strong>：'+(tagsText(d.p_tags,pDims)||'（无）')+'</div>';
      if(Object.keys(d.errors||{}).length){
        html+='<h3>错误信息</h3><pre>'+JSON.stringify(d.errors,null,2)+'</pre>';
      }
      body.innerHTML=html;
      pane.classList.remove('hidden');
    });
  });
  document.getElementById('case-detail-close').addEventListener('click',function(){
    document.getElementById('case-detail-pane').classList.add('hidden');
  });
});
"""


_HTML_TEMPLATE = """<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>{title}</title>
<link rel="stylesheet" href="{dt_css}" />
<style>{custom_css}</style>
</head><body>
<div class="page">
<header class="page-header">
<div class="eyebrow">KAON · IMAGE BENCHMARK</div>
<h1>{title}</h1>
<div class="subtitle">{subtitle}</div>
</header>
{section1}{section2}{section3}{section4}{section5}{section6}
</div>
<script src="{chart_js}"></script>
<script src="{dt_jquery}"></script>
<script src="{dt_js}"></script>
<script>{custom_js}</script>
</body></html>
"""
