"""KAON Image Generation Benchmark Tool."""

__version__ = "0.1.0"
