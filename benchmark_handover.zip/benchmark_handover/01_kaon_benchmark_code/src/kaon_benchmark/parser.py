"""Parser: extract structured scores / visual analysis from VLM/LLM raw output."""

from __future__ import annotations

import json
import re
from typing import Any


CODE_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)```", re.DOTALL | re.IGNORECASE)
SCORES_OBJECT_RE = re.compile(r'\{\s*"scores"\s*:\s*\{[^{}]*\}\s*\}', re.DOTALL)
FULL_OBJECT_WITH_SCORES_RE = re.compile(r'\{[^{}]*"scores"\s*:\s*\{[^{}]*\}[^{}]*\}', re.DOTALL)


def _strip_fences(raw: str) -> str:
    """Strip outermost ```json ... ``` fences, if any."""
    raw = raw.strip()
    m = CODE_FENCE_RE.search(raw)
    if m:
        return m.group(1).strip()
    return raw


def _validate_scores(scores: Any, expected_keys: list[str]) -> dict[str, int] | None:
    if not isinstance(scores, dict):
        return None
    out: dict[str, int] = {}
    for key in expected_keys:
        if key not in scores:
            return None
        val = scores[key]
        if isinstance(val, bool):
            return None
        if not isinstance(val, (int, float)):
            return None
        ival = int(val)
        if ival != val or not (0 <= ival <= 4):
            return None
        out[key] = ival
    return out


def parse_sub_scores(raw_output: str, expected_keys: list[str]) -> dict[str, Any] | None:
    """Parse a JSON-style sub-score response.

    Resolution order:
      1. strip code fences
      2. parse the entire stripped string as JSON
      3. find a line / substring matching {"scores": {...}} or {"reasoning": ..., "scores": ...}
      4. regex fallback for {"scores": {...}}
      5. None on total failure (caller marks parse_error)

    Validation: all expected_keys present in scores; each value is an integer 0-4.
    `reasoning` is preserved when present (D1 has none and that's ok).

    Returns: {"scores": {...}, "reasoning": "..." | None}
    """
    if not raw_output or not isinstance(raw_output, str):
        return None
    stripped = _strip_fences(raw_output)

    candidates: list[str] = [stripped]
    candidates.extend(m.group(0) for m in FULL_OBJECT_WITH_SCORES_RE.finditer(stripped))
    candidates.extend(m.group(0) for m in SCORES_OBJECT_RE.finditer(stripped))

    seen: set[str] = set()
    for cand in candidates:
        if cand in seen:
            continue
        seen.add(cand)
        try:
            obj = json.loads(cand)
        except json.JSONDecodeError:
            continue
        if not isinstance(obj, dict):
            continue
        scores = obj.get("scores")
        validated = _validate_scores(scores, expected_keys)
        if validated is None:
            continue
        reasoning = obj.get("reasoning")
        if reasoning is not None and not isinstance(reasoning, str):
            reasoning = str(reasoning)
        return {"scores": validated, "reasoning": reasoning}

    return None


_VISUAL_REQUIRED_DESC_KEYS = {"characters", "action", "setting", "objects", "spatial", "mood"}


def parse_visual_analysis(raw_output: str) -> dict[str, Any] | None:
    """Parse the D2 Step 1 visual-analysis JSON.

    Validation: contains `description` (dict with all 6 required keys, all string values)
                and `scene_description` (non-empty string).
    """
    if not raw_output or not isinstance(raw_output, str):
        return None
    stripped = _strip_fences(raw_output)
    try:
        obj = json.loads(stripped)
    except json.JSONDecodeError:
        m = re.search(r'\{.*\}', stripped, re.DOTALL)
        if not m:
            return None
        try:
            obj = json.loads(m.group(0))
        except json.JSONDecodeError:
            return None
    if not isinstance(obj, dict):
        return None
    description = obj.get("description")
    scene_description = obj.get("scene_description")
    if not isinstance(description, dict):
        return None
    missing = _VISUAL_REQUIRED_DESC_KEYS - set(description.keys())
    if missing:
        return None
    for key in _VISUAL_REQUIRED_DESC_KEYS:
        val = description[key]
        if not isinstance(val, str) or not val.strip():
            return None
    if not isinstance(scene_description, str) or not scene_description.strip():
        return None
    return {
        "description": {k: description[k] for k in _VISUAL_REQUIRED_DESC_KEYS},
        "scene_description": scene_description,
    }


REFUSE_PATTERNS = [
    r"i cannot",
    r"i can't",
    r"i'm unable",
    r"i am unable",
    r"i won't",
    r"unable to (process|comply|provide|generate|assist)",
    r"against my (programming|guidelines|policies)",
    r"content polic(y|ies)",
    r"safety (filter|policy|guidelines)",
    r"violates? .{0,40}(policy|guidelines)",
    r"not (?:able|allowed) to",
]
_REFUSE_RE = re.compile("|".join(REFUSE_PATTERNS), re.IGNORECASE)


def detect_nsfw_refuse(raw_output: str) -> bool:
    """Heuristically detect NSFW-refusal responses.

    A refuse response is text where the model declines to produce a real evaluation
    on safety / policy grounds. We classify by lexical cue plus the absence of a
    parseable JSON score object.
    """
    if not raw_output or not isinstance(raw_output, str):
        return False
    text = raw_output.strip()
    if not text:
        return False
    if _REFUSE_RE.search(text) is None:
        return False
    if '"scores"' in text:
        return False
    return True
