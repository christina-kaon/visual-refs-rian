"""Tag registry: load tag dimension metadata + parse JSON tag columns + aggregation."""

from __future__ import annotations

import json
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


class TagRegistryError(ValueError):
    """Raised when tag_registry.yaml is malformed."""


@dataclass
class TagDimension:
    key: str
    display_name: str
    line: str  # "a" or "p"
    pinned: bool = False
    multi_value: bool = False


@dataclass
class TagRegistry:
    a_line: list[TagDimension] = field(default_factory=list)
    p_line: list[TagDimension] = field(default_factory=list)
    by_key: dict[str, TagDimension] = field(default_factory=dict)

    def all_dimensions(self) -> list[TagDimension]:
        return self.a_line + self.p_line

    def pinned_dimensions(self) -> list[TagDimension]:
        return [d for d in self.all_dimensions() if d.pinned]

    def get(self, key: str) -> TagDimension | None:
        return self.by_key.get(key)

    def is_known(self, key: str) -> bool:
        return key in self.by_key


def load_tag_registry(path: str | Path) -> TagRegistry:
    """Load tag_registry.yaml from disk."""
    p = Path(path)
    if not p.exists():
        raise TagRegistryError(f"tag_registry.yaml not found: {p}")
    with p.open("r", encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}

    registry = TagRegistry()

    for line_key, target in (("a_line", registry.a_line), ("p_line", registry.p_line)):
        line_short = "a" if line_key == "a_line" else "p"
        entries = raw.get(line_key) or []
        for entry in entries:
            if "key" not in entry:
                raise TagRegistryError(f"Tag entry missing 'key' in {line_key}")
            dim = TagDimension(
                key=entry["key"],
                display_name=entry.get("display_name", entry["key"]),
                line=line_short,
                pinned=bool(entry.get("pinned", False)),
                multi_value=bool(entry.get("multi_value", False)),
            )
            target.append(dim)
            if dim.key in registry.by_key:
                raise TagRegistryError(f"Duplicate tag key across lines: {dim.key}")
            registry.by_key[dim.key] = dim

    return registry


def parse_tag_json(raw: Any) -> dict[str, str]:
    """Parse a CSV cell containing tag JSON into a flat str→str dict.

    Empty / missing → {}. Malformed JSON → {} (caller can warn separately).
    """
    if raw is None:
        return {}
    if isinstance(raw, dict):
        return {str(k): str(v) for k, v in raw.items() if v not in (None, "")}
    s = str(raw).strip()
    if not s:
        return {}
    try:
        parsed = json.loads(s)
    except json.JSONDecodeError:
        return {}
    if not isinstance(parsed, dict):
        return {}
    return {str(k): str(v) for k, v in parsed.items() if v not in (None, "")}


def split_multi_value(value: str) -> list[str]:
    """Split a comma-separated multi-value tag string into individual values."""
    if not value:
        return []
    return [v.strip() for v in value.split(",") if v.strip()]


def apply_legacy_mapping(row: dict[str, Any], columns: set[str]) -> tuple[dict[str, str], dict[str, str]]:
    """Backward-compat: map old style_tag/category_tag columns to a_tags/p_tags.

    Returns (a_tags, p_tags) as parsed dicts.
    """
    if "a_tags" in columns:
        a_tags = parse_tag_json(row.get("a_tags"))
    else:
        style = (row.get("style_tag") or "").strip() if "style_tag" in columns else ""
        a_tags = {"category": style} if style else {}

    if "p_tags" in columns:
        p_tags = parse_tag_json(row.get("p_tags"))
    else:
        cat = (row.get("category_tag") or "").strip() if "category_tag" in columns else ""
        p_tags = {"genre": cat} if cat else {}

    return a_tags, p_tags


def aggregate_scores_by_tag(
    results: list[dict[str, Any]],
    tag_line: str,
    tag_key: str,
    score_key: str,
    min_samples: int = 5,
    registry: TagRegistry | None = None,
) -> list[dict[str, Any]]:
    """Aggregate scores across all results, grouped by a single tag dimension.

    Args:
        results: list of per-case result dicts. Each must have:
            - a_tags / p_tags (dict[str, str]) — already parsed
            - score_key field (numeric, may be None for failed cases)
        tag_line: "a" or "p"
        tag_key: dimension key (e.g. "category", "genre")
        score_key: result field to aggregate (e.g. "composite_raw")
        min_samples: drop tag values with fewer than this many cases
        registry: optional, used to honor multi_value semantics

    Returns: list of {tag_value, mean_score, count} sorted by mean_score desc.
    """
    if tag_line not in ("a", "p"):
        raise ValueError(f"tag_line must be 'a' or 'p', got {tag_line!r}")

    tags_field = "a_tags" if tag_line == "a" else "p_tags"
    multi_value = False
    if registry is not None:
        dim = registry.get(tag_key)
        if dim is not None:
            multi_value = dim.multi_value

    buckets: dict[str, list[float]] = defaultdict(list)
    for r in results:
        score = r.get(score_key)
        if score is None:
            continue
        try:
            score_f = float(score)
        except (TypeError, ValueError):
            continue
        tags = r.get(tags_field) or {}
        if not isinstance(tags, dict):
            continue
        raw_value = tags.get(tag_key)
        if not raw_value:
            continue
        if multi_value:
            for v in split_multi_value(str(raw_value)):
                buckets[v].append(score_f)
        else:
            buckets[str(raw_value).strip()].append(score_f)

    out: list[dict[str, Any]] = []
    for tag_value, scores in buckets.items():
        if len(scores) < min_samples:
            continue
        out.append({
            "tag_value": tag_value,
            "mean_score": sum(scores) / len(scores),
            "count": len(scores),
        })
    out.sort(key=lambda x: (-x["mean_score"], -x["count"]))
    return out
