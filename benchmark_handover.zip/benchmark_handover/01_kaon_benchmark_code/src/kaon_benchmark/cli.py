"""kaon-bench command-line entry point."""

from __future__ import annotations

import sys
from pathlib import Path

import click


@click.group(help="KAON Image Generation Benchmark Tool.")
@click.version_option(package_name="kaon-benchmark")
def main() -> None:
    pass


def _common_config_option(f):
    return click.option(
        "--config",
        "config_path",
        type=click.Path(exists=False, dir_okay=False, path_type=Path),
        default="config.yaml",
        show_default=True,
        help="Path to config.yaml",
    )(f)


@main.command(help="Run the full benchmark pipeline (or a slice via --limit / --dims).")
@_common_config_option
@click.option("--limit", type=int, default=None, help="Only run the first N test cases.")
@click.option("--smoke", is_flag=True, default=False, help="Smoke mode — emit a separate smoke_report.html.")
@click.option("--resume/--no-resume", default=True, help="Resume from results/progress.jsonl (default).")
@click.option("--dims", default=None, help="Comma-separated dim numbers to evaluate, e.g. '1,3'.")
def run(config_path: Path, limit: int | None, smoke: bool, resume: bool, dims: str | None) -> None:
    import asyncio
    from kaon_benchmark.config import load_config, ConfigError
    from kaon_benchmark.pipeline import run_pipeline
    from kaon_benchmark.reporter import ReportContext, render_report
    from kaon_benchmark.smoke_reporter import SmokeContext, render_smoke_report
    from kaon_benchmark.tag_registry import load_tag_registry

    try:
        config = load_config(config_path, strict_env=True)
    except ConfigError as e:
        click.echo(click.style(f"✘ config error: {e}", fg="red"))
        sys.exit(1)

    selected_dims = None
    if dims:
        try:
            selected_dims = {int(x.strip()) for x in dims.split(",") if x.strip()}
        except ValueError:
            click.echo(click.style(f"✘ --dims must be comma-separated integers; got {dims!r}", fg="red"))
            sys.exit(1)

    project_root = config_path.parent.resolve()
    registry = load_tag_registry(project_root / "tag_registry.yaml")

    # progress callback for live feedback
    seen = {"done": 0}
    def _cb(res):
        seen["done"] += 1
        click.echo(f"  [{seen['done']}] {res.test_id} statuses={res.statuses}")

    click.echo(click.style(f"\n=== kaon-bench run · {config_path} · limit={limit} smoke={smoke} dims={selected_dims} ===\n", bold=True))
    rows = asyncio.run(run_pipeline(
        config=config, config_path=config_path,
        limit=limit, smoke=smoke, selected_dims=selected_dims,
        progress_cb=_cb,
    ))

    output_dir = project_root / config.output_dir
    if smoke:
        smoke_cases = []
        for r in rows:
            statuses = r.get("statuses") or {}
            smoke_cases.append({
                "test_id": r["test_id"],
                "character_name": r.get("character_name"),
                "model_name": r.get("model_name"),
                "composite_display": r.get("composite_display"),
                "dim1_score": r.get("dim1_score"), "dim2_score": r.get("dim2_score"),
                "dim3_score": r.get("dim3_score"), "dim4_score": r.get("dim4_score"),
                "per_dim_raw": {},
                "per_dim_parsed": {
                    "d1": {"scores": r.get("dim1_sub_scores")} if r.get("dim1_sub_scores") else None,
                    "d2_step1": r.get("dim2_step1_description"),
                    "d2_step2": ({"scores": r.get("dim2_sub_scores"), "reasoning": r.get("dim2_reasoning")}
                                 if r.get("dim2_sub_scores") else None),
                    "d3": ({"scores": r.get("dim3_sub_scores"), "reasoning": r.get("dim3_reasoning")}
                           if r.get("dim3_sub_scores") else None),
                    "d4": ({"scores": r.get("dim4_sub_scores"), "reasoning": r.get("dim4_reasoning")}
                           if r.get("dim4_sub_scores") else None),
                },
                "per_dim_status": {
                    "d1": statuses.get("d1", "—"),
                    "d2_step1": statuses.get("d2_step1", "—"),
                    "d2_step2": statuses.get("d2", "—"),
                    "d3": statuses.get("d3", "—"),
                    "d4": statuses.get("d4", "—"),
                },
            })
        smoke_ctx = SmokeContext(
            probe_outcomes=[],   # no live probe in this run
            cases=smoke_cases,
            title="KAON 评测 — Smoke 报告",
        )
        render_smoke_report(smoke_ctx, output_dir / "smoke_report.html")

    ctx = ReportContext(
        results=rows,
        registry=registry,
        model_names=[g.name for g in config.generators],
        title="KAON 图像评测报告",
    )
    render_report(ctx, output_dir / "report.html")
    click.echo(click.style(f"\n✔ done. raw_scores.csv + report.html → {output_dir}", fg="green"))


@main.command(help="Probe all configured APIs with a single dummy request to verify connectivity.")
@_common_config_option
def probe(config_path: Path) -> None:
    import asyncio
    from kaon_benchmark.config import load_config, ConfigError
    from kaon_benchmark.probe import probe_all, render_probe_report

    try:
        config = load_config(config_path, strict_env=True)
    except ConfigError as e:
        click.echo(click.style(f"✘ config error: {e}", fg="red"))
        sys.exit(1)

    click.echo(click.style(f"\n=== kaon-bench probe: {config_path} ===\n", bold=True))
    outcomes = asyncio.run(probe_all(config))
    ok = render_probe_report(outcomes)
    sys.exit(0 if ok else 1)


@main.command("dry-run", help="Validate prompts, API endpoints, CSV, and tag_registry without making real API calls.")
@_common_config_option
def dry_run(config_path: Path) -> None:
    from kaon_benchmark.dryrun import run_dry_run
    ok = run_dry_run(config_path)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
