"""Native Anthropic Messages API client adapter for the evaluator pipeline.

The v4 spec describes an OpenAI-compatible chat/completions endpoint. This adapter
lets the same EvaluatorConfig front the Anthropic Messages API directly when
`base_url` ends in `api.anthropic.com` — useful when only ANTHROPIC_API_KEY is set.

Wire format:
  POST {base_url}/v1/messages
  headers: x-api-key, anthropic-version
  body: { model, max_tokens, messages: [{role, content: [{type:text|image, ...}]}] }

The adapter mirrors EvaluatorResult shape so call_chat_with_retry can swap
implementations transparently.
"""

from __future__ import annotations

import asyncio
import base64
import json
from typing import Any

import aiohttp

from kaon_benchmark.config import EvaluatorConfig
from kaon_benchmark.utils import detect_image_mime, parse_retry_after, sleep_with_backoff


ANTHROPIC_VERSION = "2023-06-01"


def is_anthropic_url(base_url: str) -> bool:
    return "api.anthropic.com" in (base_url or "")


def _convert_messages(openai_messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Translate OpenAI-style content blocks into Anthropic content blocks."""
    out: list[dict[str, Any]] = []
    for msg in openai_messages:
        role = msg["role"]
        content = msg["content"]
        if isinstance(content, str):
            out.append({"role": role, "content": content})
            continue
        new_blocks: list[dict[str, Any]] = []
        for blk in content:
            btype = blk.get("type")
            if btype == "text":
                new_blocks.append({"type": "text", "text": blk.get("text", "")})
            elif btype == "image_url":
                url = blk.get("image_url", {}).get("url", "")
                if url.startswith("data:"):
                    head, _, b64 = url.partition(",")
                    media_type = head.split(";")[0].split(":")[1]
                    new_blocks.append({
                        "type": "image",
                        "source": {"type": "base64", "media_type": media_type, "data": b64},
                    })
                else:
                    new_blocks.append({
                        "type": "image",
                        "source": {"type": "url", "url": url},
                    })
        out.append({"role": role, "content": new_blocks})
    return out


def _separate_system(messages: list[dict[str, Any]]) -> tuple[str | None, list[dict[str, Any]]]:
    sys_text: str | None = None
    rest: list[dict[str, Any]] = []
    for m in messages:
        if m["role"] == "system":
            content = m["content"]
            sys_text = content if isinstance(content, str) else " ".join(
                b.get("text", "") for b in content if b.get("type") == "text"
            )
        else:
            rest.append(m)
    return sys_text, rest


async def call_anthropic_with_retry(
    session: aiohttp.ClientSession,
    *,
    config: EvaluatorConfig,
    messages: list[dict[str, Any]],
    retry_count: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
    max_tokens: int = 2048,
    temperature: float = 0.0,
) -> tuple[str, str]:
    """Call Anthropic /v1/messages with exponential backoff + model fallback.

    Returns (raw_text, model_used).
    """
    base = config.base_url.rstrip("/")
    if not base.endswith("/v1/messages"):
        base = base + "/v1/messages" if not base.endswith("/v1") else base + "/messages"
    headers = {
        "x-api-key": config.api_key,
        "anthropic-version": ANTHROPIC_VERSION,
        "content-type": "application/json",
    }
    sys_text, conv_msgs = _separate_system(messages)
    a_msgs = _convert_messages(conv_msgs)

    models_to_try = [config.model] + list(config.model_fallback)
    last_err: str | None = None

    for model in models_to_try:
        for attempt in range(1, retry_count + 1):
            payload: dict[str, Any] = {
                "model": model,
                "max_tokens": max_tokens,
                "messages": a_msgs,
                "temperature": temperature,
            }
            if sys_text:
                payload["system"] = sys_text
            try:
                async with session.post(
                    base, headers=headers, json=payload,
                    timeout=aiohttp.ClientTimeout(total=180),
                ) as resp:
                    text_body = await resp.text()
                    status = resp.status
                    response_headers = dict(resp.headers)
            except (aiohttp.ClientError, asyncio.TimeoutError) as e:
                last_err = f"network: {e!r}"
                if attempt == retry_count:
                    break
                await sleep_with_backoff(attempt, base_delay=base_delay, max_delay=max_delay)
                continue

            if status == 200:
                try:
                    body = json.loads(text_body)
                except json.JSONDecodeError:
                    last_err = f"non-json 200: {text_body[:300]}"
                    break
                content = body.get("content", [])
                parts = [b.get("text", "") for b in content if b.get("type") == "text"]
                return "".join(parts), model

            if status in (400, 401, 403, 404):
                last_err = f"http {status}: {text_body[:300]}"
                break

            if status in (408, 429) or 500 <= status < 600:
                last_err = f"http {status}: {text_body[:300]}"
                if attempt == retry_count:
                    break
                retry_after = parse_retry_after(
                    response_headers.get("Retry-After") or response_headers.get("retry-after")
                )
                await sleep_with_backoff(
                    attempt,
                    base_delay=base_delay,
                    max_delay=max_delay,
                    retry_after=retry_after,
                )
                continue

            last_err = f"http {status}: {text_body[:300]}"
            break

    raise RuntimeError(last_err or "all retries failed")
