"""VLM/LLM evaluator: per-dimension API calls, D2 two-step pipeline, NSFW refuse."""

from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import aiohttp
import yaml

from kaon_benchmark.config import EvaluatorConfig
from kaon_benchmark.parser import detect_nsfw_refuse, parse_sub_scores, parse_visual_analysis
from kaon_benchmark.utils import (
    load_image_bytes,
    parse_retry_after,
    sleep_with_backoff,
    to_data_url,
)


log = logging.getLogger(__name__)


D1_KEYS = ["facial", "hair", "eye_color", "body", "signature"]
D2_STEP2_KEYS = ["event", "scene", "emotion", "interaction", "props"]
D3_KEYS = ["attractiveness", "expressiveness", "composition", "color_lighting", "finish"]
D4_KEYS = ["facial_distortion", "body_structure", "coherence", "physics"]


class EvaluatorError(RuntimeError):
    pass


@dataclass
class PromptBundle:
    instruction: str
    prefill: str
    trigger: str


@dataclass
class EvaluationResult:
    status: str  # "success" | "error" | "parse_error" | "nsfw_refused"
    raw: str | None = None
    parsed: dict[str, Any] | None = None
    error: str | None = None
    model_used: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)


def load_prompt(prompts_dir: str | Path, name: str) -> PromptBundle:
    path = Path(prompts_dir) / f"{name}.yaml"
    if not path.exists():
        raise EvaluatorError(f"prompt file not found: {path}")
    with path.open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    for fld in ("instruction", "prefill", "trigger"):
        if fld not in data or not str(data[fld]).strip():
            raise EvaluatorError(f"prompt {path} missing field: {fld}")
    return PromptBundle(
        instruction=str(data["instruction"]).strip(),
        prefill=str(data["prefill"]).strip(),
        trigger=str(data["trigger"]).strip(),
    )


def _content_image_block(image_bytes: bytes) -> dict[str, Any]:
    return {"type": "image_url", "image_url": {"url": to_data_url(image_bytes)}}


def _content_text_block(text: str) -> dict[str, Any]:
    return {"type": "text", "text": text}


def build_messages(
    *,
    instruction: str,
    prefill: str,
    trigger: str,
    images: list[bytes] | None = None,
    extra_text_after_instruction: str | None = None,
) -> list[dict[str, Any]]:
    """Build the canonical three-message + prefill structure used by every dim."""
    user_blocks: list[dict[str, Any]] = [_content_text_block(instruction)]
    if extra_text_after_instruction:
        user_blocks.append(_content_text_block(extra_text_after_instruction))
    if images:
        for img_bytes in images:
            user_blocks.append(_content_image_block(img_bytes))
    return [
        {"role": "user", "content": user_blocks},
        {"role": "assistant", "content": prefill},
        {"role": "user", "content": trigger},
    ]


def _normalize_base_url(base_url: str) -> str:
    base_url = base_url.rstrip("/")
    if base_url.endswith("/chat/completions"):
        return base_url
    if base_url.endswith("/v1"):
        return base_url + "/chat/completions"
    return base_url + "/v1/chat/completions"


async def _call_chat_completions(
    session: aiohttp.ClientSession,
    *,
    config: EvaluatorConfig,
    model: str,
    messages: list[dict[str, Any]],
    max_tokens: int = 2048,
    temperature: float = 0.0,
    timeout: float = 120.0,
) -> tuple[int, dict[str, Any] | str, dict[str, str]]:
    url = _normalize_base_url(config.base_url)
    headers = {
        "Authorization": f"Bearer {config.api_key}",
        "Content-Type": "application/json",
    }
    payload: dict[str, Any] = {
        "model": model,
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": temperature,
        # Gemini 3.x and other reasoning models on OpenRouter consume the
        # max_tokens budget on hidden reasoning before producing visible content.
        # Exclude reasoning so the full budget is available for the actual JSON output.
        "reasoning": {"exclude": True},
    }
    async with session.post(url, headers=headers, json=payload, timeout=aiohttp.ClientTimeout(total=timeout)) as resp:
        text_body = await resp.text()
        try:
            body: dict[str, Any] | str = json.loads(text_body)
        except json.JSONDecodeError:
            body = text_body
        return resp.status, body, dict(resp.headers)


def _extract_content(body: dict[str, Any] | str) -> str:
    if isinstance(body, str):
        return body
    try:
        choice0 = body["choices"][0]
    except (KeyError, IndexError, TypeError):
        return ""
    msg = choice0.get("message") or {}
    content = msg.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for c in content:
            if isinstance(c, dict) and c.get("type") == "text":
                parts.append(c.get("text", ""))
        return "".join(parts)
    return ""


async def call_chat_with_retry(
    session: aiohttp.ClientSession,
    *,
    config: EvaluatorConfig,
    messages: list[dict[str, Any]],
    retry_count: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
    max_tokens: int = 2048,
    temperature: float = 0.0,
) -> tuple[str, str]:
    """Call chat completions with exponential-backoff retry and per-dim model fallback.

    Returns (raw_text, model_used). Raises EvaluatorError on terminal failure.
    """
    from kaon_benchmark.anthropic_client import call_anthropic_with_retry, is_anthropic_url
    if is_anthropic_url(config.base_url):
        try:
            return await call_anthropic_with_retry(
                session,
                config=config,
                messages=messages,
                retry_count=retry_count,
                base_delay=base_delay,
                max_delay=max_delay,
                max_tokens=max_tokens,
                temperature=temperature,
            )
        except RuntimeError as e:
            raise EvaluatorError(str(e)) from e

    models_to_try = [config.model] + list(config.model_fallback)
    last_err: str | None = None

    for model in models_to_try:
        for attempt in range(1, retry_count + 1):
            try:
                status, body, headers = await _call_chat_completions(
                    session,
                    config=config,
                    model=model,
                    messages=messages,
                    max_tokens=max_tokens,
                    temperature=temperature,
                )
            except (aiohttp.ClientError, asyncio.TimeoutError) as e:
                last_err = f"network: {e!r}"
                if attempt == retry_count:
                    break
                await sleep_with_backoff(attempt, base_delay=base_delay, max_delay=max_delay)
                continue

            if status == 200:
                text = _extract_content(body)
                return text, model

            if status in (400, 401, 403, 404):
                last_err = f"http {status}: {str(body)[:300]}"
                break

            if status in (408, 429) or 500 <= status < 600:
                last_err = f"http {status}: {str(body)[:300]}"
                if attempt == retry_count:
                    break
                retry_after = parse_retry_after(headers.get("Retry-After") or headers.get("retry-after"))
                await sleep_with_backoff(
                    attempt,
                    base_delay=base_delay,
                    max_delay=max_delay,
                    retry_after=retry_after,
                )
                continue

            last_err = f"http {status}: {str(body)[:300]}"
            break

    raise EvaluatorError(last_err or "all retries failed")


async def evaluate_d1(
    session: aiohttp.ClientSession,
    *,
    config: EvaluatorConfig,
    prompt: PromptBundle,
    ref_image: bytes,
    gen_image: bytes,
    retry_count: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
) -> EvaluationResult:
    messages = build_messages(
        instruction=prompt.instruction,
        prefill=prompt.prefill,
        trigger=prompt.trigger,
        images=[ref_image, gen_image],
    )
    return await _evaluate_dim_with_parser(
        session,
        config=config,
        messages=messages,
        expected_keys=D1_KEYS,
        retry_count=retry_count,
        base_delay=base_delay,
        max_delay=max_delay,
        max_tokens=8192,
    )


async def evaluate_d2_step1(
    session: aiohttp.ClientSession,
    *,
    config: EvaluatorConfig,
    prompt: PromptBundle,
    gen_image: bytes,
    retry_count: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
) -> EvaluationResult:
    messages = build_messages(
        instruction=prompt.instruction,
        prefill=prompt.prefill,
        trigger=prompt.trigger,
        images=[gen_image],
    )
    try:
        raw, model_used = await call_chat_with_retry(
            session,
            config=config,
            messages=messages,
            retry_count=retry_count,
            base_delay=base_delay,
            max_delay=max_delay,
            max_tokens=8192,
        )
    except EvaluatorError as e:
        return EvaluationResult(status="error", error=str(e))
    if detect_nsfw_refuse(raw):
        return EvaluationResult(status="nsfw_refused", raw=raw, model_used=model_used)
    parsed = parse_visual_analysis(raw)
    if parsed is None:
        return EvaluationResult(status="parse_error", raw=raw, model_used=model_used)
    return EvaluationResult(status="success", raw=raw, parsed=parsed, model_used=model_used)


def format_step2_input(
    step1_parsed: dict[str, Any],
    narrative_text: str,
    *,
    narrative_label: str = "Narrative Context",
) -> str:
    """Compose the text payload that follows the Step-2 instruction.

    `narrative_label` distinguishes "Narrative Context" (5-turn dialogue) from
    "Prompt" (image-gen prompt) so the LLM knows what kind of anchor it's matching against.
    """
    visual_json = json.dumps(step1_parsed, ensure_ascii=False, indent=2)
    return (
        "Visual Analysis:\n"
        f"{visual_json}\n\n"
        f"{narrative_label}:\n"
        f"{narrative_text.strip() or '(empty)'}\n"
    )


async def evaluate_d2_step2(
    session: aiohttp.ClientSession,
    *,
    config: EvaluatorConfig,
    prompt: PromptBundle,
    step1_parsed: dict[str, Any],
    dialogue_context: str,
    narrative_source: str = "dialogue",
    retry_count: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
) -> EvaluationResult:
    label = "Prompt" if narrative_source == "prompt" else "Narrative Context"
    messages = build_messages(
        instruction=prompt.instruction,
        prefill=prompt.prefill,
        trigger=prompt.trigger,
        images=None,
        extra_text_after_instruction=format_step2_input(
            step1_parsed, dialogue_context, narrative_label=label,
        ),
    )
    return await _evaluate_dim_with_parser(
        session,
        config=config,
        messages=messages,
        expected_keys=D2_STEP2_KEYS,
        retry_count=retry_count,
        base_delay=base_delay,
        max_delay=max_delay,
        max_tokens=8192,
    )


async def evaluate_d3(
    session: aiohttp.ClientSession,
    *,
    config: EvaluatorConfig,
    prompt: PromptBundle,
    ref_image: bytes,
    gen_image: bytes,
    retry_count: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
) -> EvaluationResult:
    messages = build_messages(
        instruction=prompt.instruction,
        prefill=prompt.prefill,
        trigger=prompt.trigger,
        images=[ref_image, gen_image],
    )
    return await _evaluate_dim_with_parser(
        session,
        config=config,
        messages=messages,
        expected_keys=D3_KEYS,
        retry_count=retry_count,
        base_delay=base_delay,
        max_delay=max_delay,
        max_tokens=8192,
    )


async def evaluate_d4(
    session: aiohttp.ClientSession,
    *,
    config: EvaluatorConfig,
    prompt: PromptBundle,
    gen_image: bytes,
    retry_count: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
) -> EvaluationResult:
    messages = build_messages(
        instruction=prompt.instruction,
        prefill=prompt.prefill,
        trigger=prompt.trigger,
        images=[gen_image],
    )
    return await _evaluate_dim_with_parser(
        session,
        config=config,
        messages=messages,
        expected_keys=D4_KEYS,
        retry_count=retry_count,
        base_delay=base_delay,
        max_delay=max_delay,
        max_tokens=8192,
    )


async def _evaluate_dim_with_parser(
    session: aiohttp.ClientSession,
    *,
    config: EvaluatorConfig,
    messages: list[dict[str, Any]],
    expected_keys: list[str],
    retry_count: int,
    base_delay: float,
    max_delay: float,
    max_tokens: int,
) -> EvaluationResult:
    try:
        raw, model_used = await call_chat_with_retry(
            session,
            config=config,
            messages=messages,
            retry_count=retry_count,
            base_delay=base_delay,
            max_delay=max_delay,
            max_tokens=max_tokens,
        )
    except EvaluatorError as e:
        return EvaluationResult(status="error", error=str(e))
    if detect_nsfw_refuse(raw):
        return EvaluationResult(status="nsfw_refused", raw=raw, model_used=model_used)
    parsed = parse_sub_scores(raw, expected_keys)
    if parsed is None:
        return EvaluationResult(status="parse_error", raw=raw, model_used=model_used)
    return EvaluationResult(status="success", raw=raw, parsed=parsed, model_used=model_used)
