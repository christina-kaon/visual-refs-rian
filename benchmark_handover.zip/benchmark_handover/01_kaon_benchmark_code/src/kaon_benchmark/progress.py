"""JSONL append-only progress tracking with D2-step granularity."""

from __future__ import annotations

import json
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable


@dataclass(frozen=True)
class ProgressKey:
    test_id: str
    model: str
    dim: str  # e.g. "d1", "d2_step1", "d2_step2", "d3", "d4"


class ProgressLog:
    """Thread-safe JSONL append-only progress log.

    On disk format (one JSON object per line):
        {"test_id": ..., "model": ..., "dim": ..., "result": {...}, "status": "success"}
        Status values: "success", "error", "parse_error", "nsfw_refused"

    Reading: build an in-memory map of (test_id, model, dim) -> latest record.
    Writing: append one line.
    """

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._index: dict[ProgressKey, dict[str, Any]] = {}
        if self.path.exists():
            self._load()

    def _load(self) -> None:
        with self.path.open("r", encoding="utf-8") as f:
            for raw in f:
                line = raw.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if not isinstance(rec, dict):
                    continue
                test_id = rec.get("test_id")
                model = rec.get("model")
                dim = rec.get("dim")
                if test_id is None or model is None or dim is None:
                    continue
                self._index[ProgressKey(str(test_id), str(model), str(dim))] = rec

    def has(self, test_id: str, model: str, dim: str, *, statuses: Iterable[str] | None = None) -> bool:
        rec = self._index.get(ProgressKey(test_id, model, dim))
        if rec is None:
            return False
        if statuses is None:
            return True
        return rec.get("status") in set(statuses)

    def get(self, test_id: str, model: str, dim: str) -> dict[str, Any] | None:
        return self._index.get(ProgressKey(test_id, model, dim))

    def append(
        self,
        *,
        test_id: str,
        model: str,
        dim: str,
        result: Any,
        status: str,
        extra: dict[str, Any] | None = None,
    ) -> None:
        rec: dict[str, Any] = {
            "test_id": test_id,
            "model": model,
            "dim": dim,
            "result": result,
            "status": status,
        }
        if extra:
            rec.update(extra)
        line = json.dumps(rec, ensure_ascii=False)
        with self._lock:
            with self.path.open("a", encoding="utf-8") as f:
                f.write(line + "\n")
            self._index[ProgressKey(test_id, model, dim)] = rec

    def all_records(self) -> list[dict[str, Any]]:
        return list(self._index.values())

    def successes_for(self, test_id: str, model: str) -> dict[str, dict[str, Any]]:
        """Return all successful dim records for a (test_id, model) pair."""
        out: dict[str, dict[str, Any]] = {}
        for key, rec in self._index.items():
            if key.test_id == test_id and key.model == model and rec.get("status") == "success":
                out[key.dim] = rec
        return out
