"""Composite scoring with weighted sub-items and the three-step hard penalty."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


DIM1_WEIGHTS = {
    "facial": 0.30,
    "hair": 0.30,
    "eye_color": 0.15,
    "body": 0.10,
    "signature": 0.15,
}

DIM2_WEIGHTS = {
    "event": 0.30,
    "scene": 0.25,
    "emotion": 0.20,
    "props": 0.10,
    "interaction": 0.15,
}

DIM3_WEIGHTS = {
    "attractiveness": 0.25,
    "expressiveness": 0.25,
    "composition": 0.20,
    "color_lighting": 0.15,
    "finish": 0.15,
}

DIM4_WEIGHTS = {
    "facial_distortion": 0.40,
    "body_structure": 0.30,
    "coherence": 0.20,
    "physics": 0.10,
}

DIM_COMPOSITE_WEIGHTS = {
    "dim1": 0.30,
    "dim2": 0.30,
    "dim3": 0.25,
    "dim4": 0.15,
}


@dataclass
class CompositeResult:
    dim1_score: float | None
    dim2_score: float | None
    dim3_score: float | None
    dim4_score: float | None  # post facial_distortion cap
    composite_raw: float | None
    composite_display: float | None  # 0-10 scale
    penalty_applied: dict[str, bool] = field(default_factory=dict)


def weighted_dim_score(sub_scores: dict[str, int], weights: dict[str, float]) -> float:
    """Sum sub-scores * weights. Missing sub-scores raise KeyError."""
    return float(sum(sub_scores[k] * w for k, w in weights.items()))


def compute_composite(
    *,
    dim1_sub: dict[str, int] | None,
    dim2_sub: dict[str, int] | None,
    dim3_sub: dict[str, int] | None,
    dim4_sub: dict[str, int] | None,
) -> CompositeResult:
    """Compute composite_raw with the three-step hard penalty.

    Penalty execution order (must NOT be reordered — step 1 may trigger step 2):
      1. facial_distortion ≤ 1  →  dim4_score capped at 1.0
      2. dim4_score ≤ 1.0       →  composite_raw capped at 3.0
      3. dim1_score ≤ 0.5       →  composite_raw capped at 1.0

    Sub-score dicts that are None are treated as missing dimensions (the dim score
    becomes None and is excluded from the composite). When *every* dim is missing
    composite_raw is None.
    """
    penalty: dict[str, bool] = {
        "facial_distortion_cap": False,
        "dim4_cap": False,
        "dim1_cap": False,
    }

    dim1_score = weighted_dim_score(dim1_sub, DIM1_WEIGHTS) if dim1_sub else None
    dim2_score = weighted_dim_score(dim2_sub, DIM2_WEIGHTS) if dim2_sub else None
    dim3_score = weighted_dim_score(dim3_sub, DIM3_WEIGHTS) if dim3_sub else None
    dim4_score = weighted_dim_score(dim4_sub, DIM4_WEIGHTS) if dim4_sub else None

    if dim4_sub is not None and dim4_sub.get("facial_distortion", 4) <= 1:
        if dim4_score is not None:
            dim4_score = min(dim4_score, 1.0)
        penalty["facial_distortion_cap"] = True

    if all(v is None for v in (dim1_score, dim2_score, dim3_score, dim4_score)):
        return CompositeResult(None, None, None, None, None, None, penalty)

    parts: list[float] = []
    parts_total_weight = 0.0
    for key, score in (
        ("dim1", dim1_score),
        ("dim2", dim2_score),
        ("dim3", dim3_score),
        ("dim4", dim4_score),
    ):
        if score is None:
            continue
        w = DIM_COMPOSITE_WEIGHTS[key]
        parts.append(score * w)
        parts_total_weight += w
    composite_raw = sum(parts)
    if parts_total_weight > 0 and parts_total_weight < 1.0:
        composite_raw = composite_raw / parts_total_weight  # rescale when some dims missing

    if dim4_score is not None and dim4_score <= 1.0:
        composite_raw = min(composite_raw, 3.0)
        penalty["dim4_cap"] = True

    if dim1_score is not None and dim1_score <= 0.5:
        composite_raw = min(composite_raw, 1.0)
        penalty["dim1_cap"] = True

    composite_display = round(composite_raw * 2.5, 1)

    return CompositeResult(
        dim1_score=dim1_score,
        dim2_score=dim2_score,
        dim3_score=dim3_score,
        dim4_score=dim4_score,
        composite_raw=composite_raw,
        composite_display=composite_display,
        penalty_applied=penalty,
    )
