"""Image generation: call configured generator APIs to produce candidate images."""

from __future__ import annotations

import asyncio
import base64
import json
import logging
from dataclasses import dataclass
from pathlib import Path

import aiohttp

from kaon_benchmark.config import GeneratorConfig
from kaon_benchmark.utils import (
    detect_image_mime,
    parse_retry_after,
    safe_filename,
    sleep_with_backoff,
    SUPPORTED_MIME,
)


log = logging.getLogger(__name__)


class GeneratorError(RuntimeError):
    pass


@dataclass
class GenerationResult:
    status: str  # "success" | "error"
    image_path: Path | None = None
    image_bytes: bytes | None = None
    error: str | None = None
    raw_response_excerpt: str | None = None


async def _call_generator(
    session: aiohttp.ClientSession,
    *,
    config: GeneratorConfig,
    prompt: str,
    timeout: float = 180.0,
) -> tuple[int, dict | str, dict[str, str]]:
    url = config.base_url.rstrip("/")
    if not url.endswith(("/generate", "/images", "/images/generations")):
        # fall back to OpenAI Images-style endpoint when base_url is just a server URL
        url = url + "/v1/images/generations"
    headers = {
        "Authorization": f"Bearer {config.api_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": config.model,
        "prompt": prompt,
        "n": 1,
        "size": config.extra.get("size", "1024x1024"),
        "response_format": "b64_json",
    }
    extra_payload = {k: v for k, v in config.extra.items() if k not in {"size"}}
    payload.update(extra_payload)

    async with session.post(url, headers=headers, json=payload, timeout=aiohttp.ClientTimeout(total=timeout)) as resp:
        body_text = await resp.text()
        try:
            body = json.loads(body_text)
        except json.JSONDecodeError:
            body = body_text
        return resp.status, body, dict(resp.headers)


def _extract_image_bytes(body: dict | str) -> bytes | None:
    """Pull image bytes out of the response body.

    Supports OpenAI-style `{"data": [{"b64_json": "..."}]}` and `{"data": [{"url": "..."}]}`,
    plus a raw `{"image": "<b64>"}` shape used by some internal services.
    """
    if isinstance(body, str):
        return None
    data = body.get("data")
    if isinstance(data, list) and data:
        first = data[0]
        if isinstance(first, dict):
            b64 = first.get("b64_json") or first.get("image_base64")
            if b64:
                try:
                    return base64.b64decode(b64)
                except (ValueError, base64.binascii.Error):
                    return None
    raw_b64 = body.get("image") if isinstance(body, dict) else None
    if isinstance(raw_b64, str):
        try:
            return base64.b64decode(raw_b64)
        except (ValueError, base64.binascii.Error):
            return None
    return None


async def _download_url(session: aiohttp.ClientSession, url: str, *, timeout: float = 60.0) -> bytes | None:
    async with session.get(url, timeout=aiohttp.ClientTimeout(total=timeout)) as resp:
        if resp.status != 200:
            return None
        return await resp.read()


async def generate_image(
    session: aiohttp.ClientSession,
    *,
    config: GeneratorConfig,
    test_id: str,
    prompt: str,
    output_dir: str | Path,
    retry_count: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
) -> GenerationResult:
    last_err: str | None = None
    for attempt in range(1, retry_count + 1):
        try:
            status, body, headers = await _call_generator(session, config=config, prompt=prompt)
        except (aiohttp.ClientError, asyncio.TimeoutError) as e:
            last_err = f"network: {e!r}"
            if attempt == retry_count:
                break
            await sleep_with_backoff(attempt, base_delay=base_delay, max_delay=max_delay)
            continue

        if status == 200:
            img_bytes = _extract_image_bytes(body)
            if img_bytes is None and isinstance(body, dict):
                # try URL form
                data = body.get("data")
                if isinstance(data, list) and data and isinstance(data[0], dict):
                    img_url = data[0].get("url")
                    if img_url:
                        img_bytes = await _download_url(session, img_url)
            if img_bytes is None:
                last_err = f"could not extract image from response: {str(body)[:300]}"
                break
            try:
                mime = detect_image_mime(img_bytes)
            except ValueError as e:
                last_err = f"invalid image bytes: {e}"
                break
            ext = SUPPORTED_MIME[mime]
            out_dir = Path(output_dir) / safe_filename(config.name) / safe_filename(test_id)
            out_dir.mkdir(parents=True, exist_ok=True)
            img_path = out_dir / f"image.{ext}"
            img_path.write_bytes(img_bytes)
            return GenerationResult(status="success", image_path=img_path, image_bytes=img_bytes)

        if status in (400, 401, 403, 404):
            last_err = f"http {status}: {str(body)[:300]}"
            break

        if status in (408, 429) or 500 <= status < 600:
            last_err = f"http {status}: {str(body)[:300]}"
            if attempt == retry_count:
                break
            retry_after = parse_retry_after(headers.get("Retry-After") or headers.get("retry-after"))
            await sleep_with_backoff(
                attempt,
                base_delay=base_delay,
                max_delay=max_delay,
                retry_after=retry_after,
            )
            continue

        last_err = f"http {status}: {str(body)[:300]}"
        break

    return GenerationResult(status="error", error=last_err or "all retries failed")
