"""Utility helpers: image format sniffing, base64 encoding, async backoff."""

from __future__ import annotations

import asyncio
import base64
import random
from pathlib import Path
from typing import Any

import filetype


SUPPORTED_MIME = {
    "image/png": "png",
    "image/jpeg": "jpg",
    "image/webp": "webp",
    "image/gif": "gif",
}


class UnsupportedImageFormat(ValueError):
    """Raised when an image's real (magic-byte) format isn't in the supported set."""


def detect_image_mime(image_bytes: bytes) -> str:
    """Detect a real MIME type from the leading bytes of an image.

    Raises UnsupportedImageFormat if the detected type is not in our allowlist.
    """
    kind = filetype.guess(image_bytes)
    if kind is None or kind.mime not in SUPPORTED_MIME:
        detected = kind.mime if kind else "unknown"
        raise UnsupportedImageFormat(f"Unsupported image MIME: {detected}")
    return kind.mime


def load_image_bytes(path: str | Path) -> bytes:
    p = Path(path)
    if not p.exists() or not p.is_file():
        raise FileNotFoundError(f"Image not found: {p}")
    return p.read_bytes()


def encode_image_base64(image_bytes: bytes) -> tuple[str, str]:
    """Return (mime_type, base64_data) for a magic-byte-validated image."""
    mime = detect_image_mime(image_bytes)
    data = base64.b64encode(image_bytes).decode("ascii")
    return mime, data


def to_data_url(image_bytes: bytes) -> str:
    mime, data = encode_image_base64(image_bytes)
    return f"data:{mime};base64,{data}"


def compute_backoff(
    attempt: int,
    *,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
    jitter: float = 0.5,
    retry_after: float | None = None,
) -> float:
    """Exponential backoff with jitter, honoring `Retry-After` when present.

    `attempt` is 1-indexed (first retry uses attempt=1).
    """
    if retry_after is not None and retry_after > 0:
        return min(float(retry_after), max_delay)
    delay = base_delay * (2 ** max(0, attempt - 1))
    delay += random.uniform(0.0, jitter)
    return min(delay, max_delay)


async def sleep_with_backoff(
    attempt: int,
    *,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
    jitter: float = 0.5,
    retry_after: float | None = None,
) -> float:
    delay = compute_backoff(
        attempt,
        base_delay=base_delay,
        max_delay=max_delay,
        jitter=jitter,
        retry_after=retry_after,
    )
    await asyncio.sleep(delay)
    return delay


def parse_retry_after(value: Any) -> float | None:
    """Convert a Retry-After header value into seconds."""
    if value is None:
        return None
    try:
        return float(value)
    except (ValueError, TypeError):
        return None


def safe_filename(name: str) -> str:
    """Sanitize a string for filesystem use."""
    out = []
    for ch in name:
        if ch.isalnum() or ch in ("-", "_", "."):
            out.append(ch)
        else:
            out.append("_")
    return "".join(out) or "_"
