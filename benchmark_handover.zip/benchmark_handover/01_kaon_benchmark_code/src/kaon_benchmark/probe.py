"""Probe: dummy 1-shot validation of all configured generator + evaluator endpoints."""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import aiohttp
import click

from kaon_benchmark.config import Config, EvaluatorConfig, GeneratorConfig
from kaon_benchmark.evaluator import (
    PromptBundle,
    build_messages,
    call_chat_with_retry,
    EvaluatorError,
)


log = logging.getLogger(__name__)


@dataclass
class ProbeOutcome:
    name: str
    kind: str  # "generator" | "evaluator"
    model_used: str | None
    ok: bool
    detail: str


_PROBE_PROMPT = PromptBundle(
    instruction="You are a connectivity probe. Reply with exactly one short JSON object: {\"ok\": true}.",
    prefill="Understood. I will respond with the JSON object {\"ok\": true} and nothing else.",
    trigger="Please reply now.",
)


async def _probe_evaluator(
    session: aiohttp.ClientSession,
    name: str,
    config: EvaluatorConfig,
) -> ProbeOutcome:
    messages = build_messages(
        instruction=_PROBE_PROMPT.instruction,
        prefill=_PROBE_PROMPT.prefill,
        trigger=_PROBE_PROMPT.trigger,
    )
    try:
        raw, model_used = await call_chat_with_retry(
            session,
            config=config,
            messages=messages,
            retry_count=1,
            base_delay=0.5,
            max_delay=5.0,
            max_tokens=64,
            temperature=0.0,
        )
    except EvaluatorError as e:
        msg = str(e)
        if "http 400" in msg.lower() and "prefill" in msg.lower():
            return ProbeOutcome(name, "evaluator", None, False, "prefill not supported for this model")
        return ProbeOutcome(name, "evaluator", None, False, msg[:200])
    return ProbeOutcome(name, "evaluator", model_used, True, raw[:80].replace("\n", " "))


async def _probe_generator(
    session: aiohttp.ClientSession,
    config: GeneratorConfig,
) -> ProbeOutcome:
    from kaon_benchmark.generator import generate_image
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        result = await generate_image(
            session,
            config=config,
            test_id="__probe__",
            prompt="A simple solid red square. Probe test image.",
            output_dir=tmp,
            retry_count=1,
            base_delay=0.5,
            max_delay=5.0,
        )
    if result.status == "success" and result.image_bytes:
        return ProbeOutcome(config.name, "generator", config.model, True, f"got {len(result.image_bytes)} bytes")
    return ProbeOutcome(config.name, "generator", config.model, False, (result.error or "unknown")[:200])


async def probe_all(config: Config) -> list[ProbeOutcome]:
    timeout = aiohttp.ClientTimeout(total=180.0)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        gen_tasks = [asyncio.create_task(_probe_generator(session, g)) for g in config.generators]
        ev_tasks = [
            asyncio.create_task(_probe_evaluator(session, name, ev))
            for name, ev in config.evaluators.items()
        ]
        results = await asyncio.gather(*gen_tasks, *ev_tasks, return_exceptions=False)
    return list(results)


def render_probe_report(outcomes: list[ProbeOutcome]) -> bool:
    """Print a colored report. Returns True if all probes passed."""
    all_ok = True
    for o in outcomes:
        marker = click.style("✔", fg="green") if o.ok else click.style("✘", fg="red")
        model = f" [{o.model_used}]" if o.model_used else ""
        click.echo(f"{marker} {o.kind} {o.name}{model} — {o.detail}")
        if not o.ok:
            all_ok = False
    return all_ok
