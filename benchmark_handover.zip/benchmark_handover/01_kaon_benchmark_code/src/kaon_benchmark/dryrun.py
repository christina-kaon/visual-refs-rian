"""dry-run: validate prompts, config, CSV, and tag_registry without making real API calls."""

from __future__ import annotations

import csv
from pathlib import Path
from urllib.parse import urlparse

import click
import yaml

from kaon_benchmark.config import ConfigError, load_config
from kaon_benchmark.tag_registry import TagRegistryError, load_tag_registry, parse_tag_json


PROMPT_FILES = ("dim1.yaml", "dim2_step1.yaml", "dim2_step2.yaml", "dim3.yaml", "dim4.yaml")
PROMPT_REQUIRED_FIELDS = ("instruction", "prefill", "trigger")
CSV_REQUIRED_COLUMNS = ("test_id", "character_name", "ref_image_path", "prompt")


def _ok(msg: str) -> None:
    click.echo(click.style("✔ ", fg="green") + msg)


def _fail(msg: str) -> None:
    click.echo(click.style("✘ ", fg="red") + msg)


def _warn(msg: str) -> None:
    click.echo(click.style("⚠ ", fg="yellow") + msg)


def _check_prompts(prompts_dir: Path) -> bool:
    if not prompts_dir.exists():
        _fail(f"prompts dir not found: {prompts_dir}")
        return False
    all_ok = True
    for fname in PROMPT_FILES:
        fpath = prompts_dir / fname
        if not fpath.exists():
            _fail(f"prompt file missing: {fpath}")
            all_ok = False
            continue
        try:
            with fpath.open("r", encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
        except yaml.YAMLError as e:
            _fail(f"prompt YAML parse error in {fname}: {e}")
            all_ok = False
            continue
        missing = [k for k in PROMPT_REQUIRED_FIELDS if k not in data or not str(data[k]).strip()]
        if missing:
            _fail(f"{fname} missing fields: {missing}")
            all_ok = False
            continue
        _ok(f"prompt {fname} loaded ({len(data['instruction'])}-char instruction, {len(data['prefill'])}-char prefill)")
    return all_ok


def _check_endpoints(config) -> bool:
    all_ok = True
    seen: set[str] = set()
    for g in config.generators:
        url = g.base_url
        if url in seen:
            continue
        seen.add(url)
        parsed = urlparse(url)
        if not parsed.scheme or not parsed.netloc:
            _fail(f"generator {g.name}: malformed base_url {url!r}")
            all_ok = False
            continue
        _ok(f"generator {g.name} → {parsed.scheme}://{parsed.netloc} (URL well-formed; not pinged)")
    for ev_name, ev in config.evaluators.items():
        url = ev.base_url
        if url in seen:
            continue
        seen.add(url)
        parsed = urlparse(url)
        if not parsed.scheme or not parsed.netloc:
            _fail(f"evaluator {ev_name}: malformed base_url {url!r}")
            all_ok = False
            continue
        _ok(f"evaluator {ev_name} → {parsed.scheme}://{parsed.netloc} (URL well-formed; not pinged)")
    return all_ok


def _check_csv(csv_path: Path) -> bool:
    if not csv_path.exists():
        _fail(f"input CSV not found: {csv_path}")
        return False
    try:
        with csv_path.open("r", encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            cols = set(reader.fieldnames or [])
            missing = [c for c in CSV_REQUIRED_COLUMNS if c not in cols]
            if missing:
                _fail(f"CSV {csv_path} missing required columns: {missing}")
                return False
            row_count = 0
            tag_parse_failures = 0
            ref_unreachable = 0
            for row in reader:
                row_count += 1
                if "a_tags" in cols and row.get("a_tags"):
                    if parse_tag_json(row["a_tags"]) == {} and row["a_tags"].strip() not in ("", "{}"):
                        tag_parse_failures += 1
                if "p_tags" in cols and row.get("p_tags"):
                    if parse_tag_json(row["p_tags"]) == {} and row["p_tags"].strip() not in ("", "{}"):
                        tag_parse_failures += 1
                ref = row.get("ref_image_path", "").strip()
                if ref and not ref.startswith(("http://", "https://")):
                    ref_path = Path(ref)
                    if not ref_path.is_absolute():
                        ref_path = csv_path.parent / ref_path
                    if not ref_path.exists():
                        ref_unreachable += 1
            if tag_parse_failures:
                _warn(f"CSV {csv_path}: {tag_parse_failures} tag JSON parse failures (treated as empty dict)")
            if ref_unreachable:
                _warn(f"CSV {csv_path}: {ref_unreachable} local ref_image_path entries do not exist on disk")
            _ok(f"CSV {csv_path} parsed ({row_count} rows, columns: {sorted(cols)})")
        return True
    except (OSError, csv.Error) as e:
        _fail(f"CSV {csv_path} read error: {e}")
        return False


def _check_tag_registry(registry_path: Path) -> bool:
    if not registry_path.exists():
        _fail(f"tag_registry.yaml not found: {registry_path}")
        return False
    try:
        registry = load_tag_registry(registry_path)
    except TagRegistryError as e:
        _fail(f"tag_registry.yaml load error: {e}")
        return False
    pinned = [d.key for d in registry.pinned_dimensions()]
    _ok(
        f"tag_registry loaded ({len(registry.a_line)} A-line + {len(registry.p_line)} P-line dims, "
        f"pinned: {pinned})"
    )
    return True


def run_dry_run(config_path: Path) -> bool:
    click.echo(click.style(f"\n=== kaon-bench dry-run: {config_path} ===\n", bold=True))

    try:
        config = load_config(config_path, strict_env=False)
    except ConfigError as e:
        _fail(f"config load error: {e}")
        return False
    _ok(f"config loaded ({len(config.generators)} generators, {len(config.evaluators)} evaluators)")

    project_root = config_path.parent.resolve()
    prompts_dir = project_root / config.prompts_dir
    csv_path = project_root / config.input_csv
    registry_path = project_root / "tag_registry.yaml"

    checks = [
        ("prompts", _check_prompts(prompts_dir)),
        ("endpoints", _check_endpoints(config)),
        ("input CSV", _check_csv(csv_path)),
        ("tag_registry", _check_tag_registry(registry_path)),
    ]

    click.echo()
    if all(passed for _, passed in checks):
        click.echo(click.style("=== dry-run PASSED ===", fg="green", bold=True))
        return True
    failed = [name for name, passed in checks if not passed]
    click.echo(click.style(f"=== dry-run FAILED: {', '.join(failed)} ===", fg="red", bold=True))
    return False
