"""Per-case orchestration: load CSV → fetch images → 4-dim eval → score → progress + raw_scores."""

from __future__ import annotations

import asyncio
import csv
import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import aiohttp

from kaon_benchmark.config import Config
from kaon_benchmark.evaluator import (
    PromptBundle,
    EvaluationResult,
    evaluate_d1,
    evaluate_d2_step1,
    evaluate_d2_step2,
    evaluate_d3,
    evaluate_d4,
    load_prompt,
)
from kaon_benchmark.parser import parse_sub_scores
from kaon_benchmark.progress import ProgressLog
from kaon_benchmark.scorer import compute_composite, CompositeResult
from kaon_benchmark.tag_registry import TagRegistry, parse_tag_json


log = logging.getLogger(__name__)


@dataclass
class CaseInput:
    test_id: str
    character_name: str
    ref_image_path: str
    prompt: str
    dialogue_context: str
    a_tags: dict[str, str]
    p_tags: dict[str, str]
    generated_image_path: str | None  # set when CSV ships pre-generated images
    extras: dict[str, Any] = field(default_factory=dict)


def load_cases(csv_path: Path) -> list[CaseInput]:
    cases: list[CaseInput] = []
    with csv_path.open("r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            cases.append(CaseInput(
                test_id=row["test_id"],
                character_name=row.get("character_name", ""),
                ref_image_path=row.get("ref_image_path", ""),
                prompt=row.get("prompt", ""),
                dialogue_context=row.get("dialogue_context", ""),
                a_tags=parse_tag_json(row.get("a_tags", "")),
                p_tags=parse_tag_json(row.get("p_tags", "")),
                generated_image_path=(row.get("generated_image_path") or "").strip() or None,
                extras={k: v for k, v in row.items() if k not in {
                    "test_id", "character_name", "ref_image_path", "prompt",
                    "dialogue_context", "a_tags", "p_tags", "generated_image_path",
                }},
            ))
    return cases


async def _fetch_image(session: aiohttp.ClientSession, url_or_path: str) -> bytes | None:
    if not url_or_path:
        return None
    if url_or_path.startswith(("http://", "https://")):
        try:
            async with session.get(url_or_path, timeout=aiohttp.ClientTimeout(total=60)) as r:
                if r.status != 200:
                    return None
                return await r.read()
        except aiohttp.ClientError:
            return None
    p = Path(url_or_path)
    if p.exists():
        return p.read_bytes()
    return None


@dataclass
class CaseResult:
    test_id: str
    model_name: str
    case: CaseInput
    composite: CompositeResult | None = None
    eval_results: dict[str, EvaluationResult] = field(default_factory=dict)
    statuses: dict[str, str] = field(default_factory=dict)
    errors: dict[str, str] = field(default_factory=dict)


async def run_one_case(
    session: aiohttp.ClientSession,
    *,
    case: CaseInput,
    config: Config,
    prompts: dict[str, PromptBundle],
    model_name: str,
    progress: ProgressLog,
    selected_dims: set[int] | None = None,
) -> CaseResult:
    """Score a single case across 4 dims (skip generation — image must already exist)."""
    res = CaseResult(test_id=case.test_id, model_name=model_name, case=case)

    if not case.generated_image_path:
        res.statuses = {f"d{d}": "error" for d in (1, 2, 3, 4)}
        res.errors["pipeline"] = "no generated_image_path; the score-only flow requires pre-generated images"
        return res

    ref_bytes, gen_bytes = await asyncio.gather(
        _fetch_image(session, case.ref_image_path),
        _fetch_image(session, case.generated_image_path),
    )
    if gen_bytes is None:
        res.statuses = {f"d{d}": "error" for d in (1, 2, 3, 4)}
        res.errors["pipeline"] = f"could not fetch generated image: {case.generated_image_path}"
        return res
    if ref_bytes is None:
        log.warning("[%s] reference image unavailable; D1/D3 will be skipped", case.test_id)

    do_d1 = (selected_dims is None or 1 in selected_dims) and ref_bytes is not None
    do_d2 = selected_dims is None or 2 in selected_dims
    do_d3 = (selected_dims is None or 3 in selected_dims) and ref_bytes is not None
    do_d4 = selected_dims is None or 4 in selected_dims

    eval_kwargs = {
        "retry_count": config.retry_count,
        "base_delay": config.backoff_base_delay,
        "max_delay": config.backoff_max_delay,
    }

    sub_scores: dict[str, dict[str, int] | None] = {"dim1": None, "dim2": None, "dim3": None, "dim4": None}

    if do_d1:
        cfg = config.evaluator_for("dim1")
        r = await evaluate_d1(session, config=cfg, prompt=prompts["dim1"],
                              ref_image=ref_bytes, gen_image=gen_bytes, **eval_kwargs)
        res.eval_results["d1"] = r
        res.statuses["d1"] = r.status
        if r.status == "success" and r.parsed:
            sub_scores["dim1"] = r.parsed["scores"]
        elif r.error:
            res.errors["d1"] = r.error
        progress.append(test_id=case.test_id, model=model_name, dim="d1",
                        result={"raw": r.raw, "parsed": r.parsed}, status=r.status,
                        extra={"model_used": r.model_used})

    step1_parsed: dict[str, Any] | None = None
    if do_d2:
        cfg1 = config.evaluator_for("dim2_step1")
        cached = progress.get(case.test_id, model_name, "d2_step1")
        if cached and cached.get("status") == "success":
            step1_parsed = (cached.get("result") or {}).get("parsed")
            res.statuses["d2_step1"] = "success"
        else:
            r1 = await evaluate_d2_step1(session, config=cfg1, prompt=prompts["dim2_step1"],
                                         gen_image=gen_bytes, **eval_kwargs)
            res.eval_results["d2_step1"] = r1
            res.statuses["d2_step1"] = r1.status
            if r1.status == "success":
                step1_parsed = r1.parsed
            elif r1.error:
                res.errors["d2_step1"] = r1.error
            progress.append(test_id=case.test_id, model=model_name, dim="d2_step1",
                            result={"raw": r1.raw, "parsed": r1.parsed}, status=r1.status,
                            extra={"model_used": r1.model_used})

        if step1_parsed:
            cfg2 = config.evaluator_for("dim2_step2")
            # Resolve the narrative anchor according to config.d2_narrative_source.
            if config.d2_narrative_source == "prompt":
                narrative_text = case.prompt
                narrative_source = "prompt"
            elif config.d2_narrative_source == "auto":
                if case.dialogue_context.strip():
                    narrative_text = case.dialogue_context
                    narrative_source = "dialogue"
                else:
                    narrative_text = case.prompt
                    narrative_source = "prompt"
            else:
                narrative_text = case.dialogue_context
                narrative_source = "dialogue"
            r2 = await evaluate_d2_step2(session, config=cfg2, prompt=prompts["dim2_step2"],
                                         step1_parsed=step1_parsed,
                                         dialogue_context=narrative_text,
                                         narrative_source=narrative_source,
                                         **eval_kwargs)
            res.eval_results["d2_step2"] = r2
            res.statuses["d2"] = r2.status
            if r2.status == "success" and r2.parsed:
                sub_scores["dim2"] = r2.parsed["scores"]
            elif r2.error:
                res.errors["d2_step2"] = r2.error
            progress.append(test_id=case.test_id, model=model_name, dim="d2_step2",
                            result={"raw": r2.raw, "parsed": r2.parsed}, status=r2.status,
                            extra={"model_used": r2.model_used})
        else:
            res.statuses["d2"] = "error"

    if do_d3:
        cfg = config.evaluator_for("dim3")
        r = await evaluate_d3(session, config=cfg, prompt=prompts["dim3"],
                              ref_image=ref_bytes, gen_image=gen_bytes, **eval_kwargs)
        res.eval_results["d3"] = r
        res.statuses["d3"] = r.status
        if r.status == "success" and r.parsed:
            sub_scores["dim3"] = r.parsed["scores"]
        elif r.error:
            res.errors["d3"] = r.error
        progress.append(test_id=case.test_id, model=model_name, dim="d3",
                        result={"raw": r.raw, "parsed": r.parsed}, status=r.status,
                        extra={"model_used": r.model_used})

    if do_d4:
        cfg = config.evaluator_for("dim4")
        r = await evaluate_d4(session, config=cfg, prompt=prompts["dim4"],
                              gen_image=gen_bytes, **eval_kwargs)
        res.eval_results["d4"] = r
        res.statuses["d4"] = r.status
        if r.status == "success" and r.parsed:
            sub_scores["dim4"] = r.parsed["scores"]
        elif r.error:
            res.errors["d4"] = r.error
        progress.append(test_id=case.test_id, model=model_name, dim="d4",
                        result={"raw": r.raw, "parsed": r.parsed}, status=r.status,
                        extra={"model_used": r.model_used})

    res.composite = compute_composite(
        dim1_sub=sub_scores["dim1"],
        dim2_sub=sub_scores["dim2"],
        dim3_sub=sub_scores["dim3"],
        dim4_sub=sub_scores["dim4"],
    )
    return res


def case_result_to_row(res: CaseResult, registry: TagRegistry) -> dict[str, Any]:
    case = res.case
    comp = res.composite or compute_composite(dim1_sub=None, dim2_sub=None, dim3_sub=None, dim4_sub=None)

    def _sub(dim_short: str) -> dict[str, int] | None:
        ev = res.eval_results.get(dim_short)
        if ev and ev.status == "success" and ev.parsed:
            return ev.parsed.get("scores")
        return None

    def _reasoning(dim_short: str) -> str | None:
        ev = res.eval_results.get(dim_short)
        if ev and ev.parsed:
            return ev.parsed.get("reasoning")
        return None

    step1_ev = res.eval_results.get("d2_step1")
    step1_desc = None
    if step1_ev and step1_ev.status == "success" and step1_ev.parsed:
        step1_desc = step1_ev.parsed.get("description")

    return {
        "test_id": case.test_id,
        "character_name": case.character_name,
        "model_name": res.model_name,
        "ref_image_path": case.ref_image_path,
        "generated_image_path": case.generated_image_path,
        "dialogue_context": case.dialogue_context,
        "a_tags": case.a_tags,
        "p_tags": case.p_tags,
        "pinned_category": case.a_tags.get("category"),
        "pinned_genre": case.p_tags.get("genre"),
        "pinned_rating": case.p_tags.get("rating"),
        "dim1_score": comp.dim1_score,
        "dim1_sub_scores": _sub("d1"),
        "dim2_score": comp.dim2_score,
        "dim2_sub_scores": _sub("d2_step2"),
        "dim2_step1_description": step1_desc,
        "dim2_reasoning": _reasoning("d2_step2"),
        "dim3_score": comp.dim3_score,
        "dim3_sub_scores": _sub("d3"),
        "dim3_reasoning": _reasoning("d3"),
        "dim4_score": comp.dim4_score,
        "dim4_sub_scores": _sub("d4"),
        "dim4_reasoning": _reasoning("d4"),
        "composite_raw": comp.composite_raw,
        "composite_display": comp.composite_display,
        "statuses": {**res.statuses},
        "penalty_applied": comp.penalty_applied,
        "errors": dict(res.errors),
    }


def write_raw_scores_csv(rows: list[dict[str, Any]], out_path: Path) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    columns = [
        "test_id", "character_name", "model_name",
        "pinned_category", "pinned_genre", "pinned_rating",
        "dim1_score", "dim1_sub_scores",
        "dim2_score", "dim2_sub_scores", "dim2_step1_description", "dim2_reasoning",
        "dim3_score", "dim3_sub_scores", "dim3_reasoning",
        "dim4_score", "dim4_sub_scores", "dim4_reasoning",
        "composite_raw", "composite_display",
        "a_tags", "p_tags",
        "ref_image_path", "generated_image_path",
        "statuses", "penalty_applied", "errors",
    ]
    with out_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        for r in rows:
            row_out = {}
            for c in columns:
                v = r.get(c)
                if isinstance(v, (dict, list)):
                    row_out[c] = json.dumps(v, ensure_ascii=False)
                else:
                    row_out[c] = "" if v is None else v
            writer.writerow(row_out)


async def run_pipeline(
    *,
    config: Config,
    config_path: Path,
    limit: int | None = None,
    smoke: bool = False,
    selected_dims: set[int] | None = None,
    progress_cb=None,
) -> list[dict[str, Any]]:
    """Score every case in `config.input_csv` against `config.generators[*].name`.

    For now the pipeline expects `generated_image_path` to be present in the CSV
    (score-only mode). Returns the result rows.
    """
    project_root = config_path.parent.resolve()
    csv_path = project_root / config.input_csv
    cases = load_cases(csv_path)
    if limit is not None:
        cases = cases[:limit]

    prompts_dir = project_root / config.prompts_dir
    # Pick the D2 step-2 prompt variant based on the configured narrative source.
    if config.d2_narrative_source == "prompt":
        step2_name = "dim2_step2_prompt_only"
    else:
        step2_name = "dim2_step2"
    prompts = {
        "dim1": load_prompt(prompts_dir, "dim1"),
        "dim2_step1": load_prompt(prompts_dir, "dim2_step1"),
        "dim2_step2": load_prompt(prompts_dir, step2_name),
        "dim3": load_prompt(prompts_dir, "dim3"),
        "dim4": load_prompt(prompts_dir, "dim4"),
    }

    output_dir = project_root / config.output_dir
    progress = ProgressLog(output_dir / "progress.jsonl")

    model_name = config.generators[0].name if config.generators else "default"

    sem = asyncio.Semaphore(max(1, int(config.concurrency)))

    async def _wrapped(case: CaseInput) -> dict[str, Any]:
        async with sem:
            async with aiohttp.ClientSession() as session:
                res = await run_one_case(
                    session,
                    case=case, config=config, prompts=prompts,
                    model_name=model_name, progress=progress,
                    selected_dims=selected_dims,
                )
        if progress_cb:
            progress_cb(res)
        from kaon_benchmark.tag_registry import load_tag_registry
        registry = load_tag_registry(project_root / "tag_registry.yaml")
        return case_result_to_row(res, registry)

    rows = await asyncio.gather(*[_wrapped(c) for c in cases])
    write_raw_scores_csv(rows, output_dir / "raw_scores.csv")
    return rows
