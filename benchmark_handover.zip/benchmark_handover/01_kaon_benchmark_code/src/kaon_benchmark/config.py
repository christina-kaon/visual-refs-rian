"""Configuration loading with env var expansion and evaluator merge logic."""

from __future__ import annotations

import os
import re
from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


ENV_VAR_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")

DIM_KEYS = ("dim1", "dim2_step1", "dim2_step2", "dim3", "dim4")


class ConfigError(ValueError):
    """Raised when config is malformed or required env vars are missing."""


@dataclass
class GeneratorConfig:
    name: str
    base_url: str
    api_key: str
    model: str
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class EvaluatorConfig:
    base_url: str
    api_key: str
    model: str
    model_fallback: list[str] = field(default_factory=list)
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class Config:
    generators: list[GeneratorConfig]
    evaluators: dict[str, EvaluatorConfig]
    concurrency: int = 10
    retry_count: int = 3
    backoff_base_delay: float = 1.0
    backoff_max_delay: float = 60.0
    input_csv: str = "data/test_cases.csv"
    output_dir: str = "results/"
    prompts_dir: str = "prompts/"
    images_dir: str = "generated_images/"
    # D2 narrative source — "dialogue" uses dialogue_context (5-turn dialogue + trigger);
    # "prompt" uses the per-case prompt text as the narrative anchor (synthetic / prompt-only datasets).
    # "auto" picks "dialogue" when dialogue_context is non-empty, otherwise falls back to "prompt".
    d2_narrative_source: str = "dialogue"
    raw: dict[str, Any] = field(default_factory=dict)

    def evaluator_for(self, dim_key: str) -> EvaluatorConfig:
        """Return the evaluator config for a dimension key.

        Falls back to the merged 'default' evaluator if no per-dim override exists.
        """
        if dim_key not in self.evaluators:
            return self.evaluators["default"]
        return self.evaluators[dim_key]


def expand_env(value: Any, *, strict: bool = True, missing: list[str] | None = None) -> Any:
    """Recursively expand ${VAR} references in strings within a config tree.

    If strict=True and a variable is missing, raises ConfigError.
    If strict=False, leaves the literal `${VAR}` in place and appends VAR to `missing`.
    """
    if isinstance(value, str):
        def _sub(match: re.Match[str]) -> str:
            var = match.group(1)
            env_val = os.environ.get(var)
            if env_val is None:
                if strict:
                    raise ConfigError(f"Required env var ${{{var}}} is not set")
                if missing is not None and var not in missing:
                    missing.append(var)
                return match.group(0)
            return env_val
        return ENV_VAR_PATTERN.sub(_sub, value)
    if isinstance(value, dict):
        return {k: expand_env(v, strict=strict, missing=missing) for k, v in value.items()}
    if isinstance(value, list):
        return [expand_env(v, strict=strict, missing=missing) for v in value]
    return value


def _build_evaluator(merged: dict[str, Any]) -> EvaluatorConfig:
    required = ("base_url", "api_key", "model")
    missing = [k for k in required if k not in merged or merged[k] in (None, "")]
    if missing:
        raise ConfigError(f"Evaluator missing required field(s): {missing}")
    return EvaluatorConfig(
        base_url=merged["base_url"],
        api_key=merged["api_key"],
        model=merged["model"],
        model_fallback=list(merged.get("model_fallback", [])),
        extra={k: v for k, v in merged.items() if k not in {"base_url", "api_key", "model", "model_fallback"}},
    )


def merge_evaluators(raw_evaluator: dict[str, Any]) -> dict[str, EvaluatorConfig]:
    """Merge per-dimension evaluator overrides on top of the default evaluator.

    Each dim's config inherits all fields from `default`, only overriding the fields
    that are explicitly specified.
    """
    if "default" not in raw_evaluator:
        raise ConfigError("evaluator.default is required")

    default = deepcopy(raw_evaluator["default"])
    result: dict[str, EvaluatorConfig] = {"default": _build_evaluator(default)}

    for dim_key in DIM_KEYS:
        if dim_key not in raw_evaluator:
            continue
        merged = deepcopy(default)
        override = raw_evaluator[dim_key] or {}
        for k, v in override.items():
            merged[k] = v
        result[dim_key] = _build_evaluator(merged)

    return result


def load_config(path: str | Path, *, strict_env: bool = True) -> Config:
    """Load config.yaml, expand env vars, merge evaluators.

    Args:
        path: path to config.yaml
        strict_env: if False, missing ${VAR} stays as literal text (used by dry-run
            to validate file structure even when secrets aren't set)
    """
    p = Path(path)
    if not p.exists():
        raise ConfigError(f"Config file not found: {p}")

    with p.open("r", encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}

    raw = expand_env(raw, strict=strict_env)

    if "generators" not in raw or not raw["generators"]:
        raise ConfigError("config.generators must contain at least one entry")
    if "evaluator" not in raw:
        raise ConfigError("config.evaluator is required")

    generators: list[GeneratorConfig] = []
    for g in raw["generators"]:
        for fld in ("name", "base_url", "api_key", "model"):
            if fld not in g:
                raise ConfigError(f"Generator entry missing field: {fld}")
        generators.append(GeneratorConfig(
            name=g["name"],
            base_url=g["base_url"],
            api_key=g["api_key"],
            model=g["model"],
            extra={k: v for k, v in g.items() if k not in {"name", "base_url", "api_key", "model"}},
        ))

    evaluators = merge_evaluators(raw["evaluator"])

    d2_src = str(raw.get("d2_narrative_source", "dialogue")).lower()
    if d2_src not in {"dialogue", "prompt", "auto"}:
        raise ConfigError(f"d2_narrative_source must be one of dialogue/prompt/auto; got {d2_src!r}")

    return Config(
        generators=generators,
        evaluators=evaluators,
        concurrency=int(raw.get("concurrency", 10)),
        retry_count=int(raw.get("retry_count", 3)),
        backoff_base_delay=float(raw.get("backoff_base_delay", 1.0)),
        backoff_max_delay=float(raw.get("backoff_max_delay", 60.0)),
        input_csv=str(raw.get("input_csv", "data/test_cases.csv")),
        output_dir=str(raw.get("output_dir", "results/")),
        prompts_dir=str(raw.get("prompts_dir", "prompts/")),
        images_dir=str(raw.get("images_dir", "generated_images/")),
        d2_narrative_source=d2_src,
        raw=raw,
    )
