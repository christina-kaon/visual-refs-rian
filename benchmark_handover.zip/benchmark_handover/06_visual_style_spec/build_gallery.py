"""4 轨道 gallery HTML，带 checkbox + LocalStorage + 导出"""
import json, html

TRACKS = [
    ('real_A', '真人 A · K-pop fan-edit candid', '自然光 / 软光颗粒 / 日常场景 / 无攻击性精致', '#E8B5C2', '#7C4858'),
    ('real_B', '真人 B · Dark romance cinematic', '硬光大反差 / 单点 key / 雨夜霓虹 / 黑帮电影质感', '#5A3D3D', '#F2D7A1'),
    ('anime_main', '动漫主轨 · 女向暗黑系美男', 'JJK / 鬼灭 / 文豪 / dark otome 美男', '#2D3142', '#E8B5C2'),
    ('anime_sub', '动漫副轨 · 男向萌系虚拟女角色', '京阿尼软光 / 高饱和柔色 / 校园日常 / 米哈游立绘', '#F2D7A1', '#5A3D3D'),
]

data = json.load(open('/tmp/visual_refs/scraped.json'))

# 按轨道 + query 分组（保留 query 顺序），每个 query 显示其中的图
def render_track(tid, name, subtitle, bg, fg, items):
    # 按 query 分组
    by_q = {}
    order = []
    for it in items:
        q = it['q']
        if q not in by_q:
            by_q[q] = []
            order.append(q)
        by_q[q].append(it)
    
    sections = []
    for q in order:
        cards = []
        for i, it in enumerate(by_q[q]):
            cid = f"{tid}_{order.index(q)}_{i}"
            murl = html.escape(it['murl'])
            purl = html.escape(it.get('purl', ''))
            title = html.escape((it.get('title') or '')[:120])
            cards.append(f'''
            <label class="card" for="cb_{cid}">
              <input type="checkbox" id="cb_{cid}" data-url="{murl}" data-track="{tid}" />
              <img loading="lazy" src="{murl}" referrerpolicy="no-referrer" onerror="this.parentElement.classList.add('err')" />
              <div class="ovly"><a href="{purl}" target="_blank" rel="noopener" onclick="event.stopPropagation()" title="原页面">↗</a></div>
              <div class="tt">{title}</div>
            </label>''')
        sections.append(f'''
        <details open class="qg">
          <summary><span class="qn">{html.escape(q)}</span> <span class="qc">{len(by_q[q])} 张</span></summary>
          <div class="grid">{"".join(cards)}</div>
        </details>''')
    
    return f'''
    <section id="{tid}" class="track" style="--bg:{bg};--fg:{fg}">
      <header class="th">
        <div class="th-left">
          <h2>{html.escape(name)}</h2>
          <p>{html.escape(subtitle)}</p>
        </div>
        <div class="th-right">
          <span class="cnt"><span id="sel_{tid}">0</span> / {len(items)} 张选中</span>
        </div>
      </header>
      {"".join(sections)}
    </section>'''

tracks_html = []
for tid, name, subtitle, bg, fg in TRACKS:
    items = data.get(tid, [])
    tracks_html.append(render_track(tid, name, subtitle, bg, fg, items))

total = sum(len(data.get(t[0], [])) for t in TRACKS)

CSS = '''
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Noto+Sans+SC:wght@400;500;600;700&display=swap');
*{box-sizing:border-box}html,body{margin:0}
body{font-family:'Inter','Noto Sans SC',-apple-system,'PingFang SC',sans-serif;background:#faf9f7;color:#1f1d1a;font-size:14px;line-height:1.5}
.page{max-width:1400px;margin:0 auto;padding:24px}
header.top{position:sticky;top:0;background:rgba(250,249,247,.97);backdrop-filter:blur(12px);z-index:100;padding:16px 0;border-bottom:1px solid #e8e4dd;margin-bottom:24px}
header.top .row{display:flex;align-items:center;justify-content:space-between;gap:16px}
header.top h1{margin:0;font-size:20px;font-weight:700}
header.top .actions{display:flex;gap:10px;align-items:center}
header.top .nav{display:flex;gap:8px;margin-top:10px;flex-wrap:wrap}
header.top .nav a{padding:6px 12px;border:1px solid #e8e4dd;border-radius:999px;text-decoration:none;color:#1f1d1a;font-size:12px;font-weight:500}
header.top .nav a:hover{background:#f5f3ef}
button{background:#c96442;color:#fff;border:0;padding:8px 16px;border-radius:6px;font-weight:600;cursor:pointer;font-size:13px}
button.ghost{background:transparent;color:#1f1d1a;border:1px solid #e8e4dd}
button:hover{opacity:.9}
.track{margin-bottom:48px;border-radius:16px;overflow:hidden;border:1px solid #e8e4dd}
.th{background:var(--bg);color:var(--fg);padding:24px 28px;display:flex;align-items:center;justify-content:space-between}
.th h2{margin:0;font-size:22px;font-weight:700}
.th p{margin:6px 0 0;font-size:13px;opacity:.85}
.cnt{font-size:13px;font-weight:600}
.qg{margin:0;padding:18px 24px;border-top:1px solid #f0ebe2}
.qg summary{cursor:pointer;font-weight:600;display:flex;justify-content:space-between;padding:6px 0;list-style:none}
.qg summary::-webkit-details-marker{display:none}
.qn{font-size:14px;color:#1f1d1a}
.qc{font-size:11px;color:#94918a;font-weight:500}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:10px;margin-top:12px}
.card{position:relative;cursor:pointer;border-radius:8px;overflow:hidden;background:#f5f3ef;aspect-ratio:1/1;display:block}
.card input{position:absolute;top:8px;left:8px;width:20px;height:20px;z-index:2;cursor:pointer;accent-color:#c96442}
.card img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .2s}
.card:hover img{transform:scale(1.03)}
.card.err{background:#fdf6f2;display:flex;align-items:center;justify-content:center}
.card.err::after{content:"⚠ 图加载失败";font-size:11px;color:#c96442}
.card.err img{display:none}
.card input:checked ~ img{outline:3px solid #c96442;outline-offset:-3px}
.card .ovly{position:absolute;top:6px;right:6px;z-index:2}
.card .ovly a{background:rgba(0,0,0,.6);color:#fff;width:24px;height:24px;border-radius:4px;display:flex;align-items:center;justify-content:center;text-decoration:none;font-size:12px}
.card .tt{position:absolute;bottom:0;left:0;right:0;background:linear-gradient(transparent,rgba(0,0,0,.85));color:#fff;padding:18px 8px 6px;font-size:10px;line-height:1.3;opacity:0;transition:opacity .2s}
.card:hover .tt{opacity:1}
#export-pane{position:fixed;bottom:20px;right:20px;background:#fff;border:1px solid #e8e4dd;border-radius:12px;padding:14px;box-shadow:0 8px 24px rgba(0,0,0,.1);display:none;max-width:340px;z-index:200}
#export-pane.on{display:block}
#export-pane h3{margin:0 0 8px;font-size:14px}
#export-pane textarea{width:100%;height:120px;padding:8px;border:1px solid #e8e4dd;border-radius:6px;font-family:'SF Mono',Menlo,monospace;font-size:11px;resize:vertical;margin-bottom:8px}
#export-pane .btns{display:flex;gap:6px;justify-content:flex-end}
.callout{background:#f6ece6;border-left:3px solid #c96442;padding:12px 16px;border-radius:0 8px 8px 0;margin-bottom:24px;font-size:13px}
'''

JS = '''
const KEY = 'visual_refs_selected_v1';
const sel = new Set(JSON.parse(localStorage.getItem(KEY) || '[]'));
const tracks = ['real_A','real_B','anime_main','anime_sub'];

function updateCounts() {
  const byTrack = {};
  document.querySelectorAll('.card input:checked').forEach(cb => {
    const t = cb.dataset.track;
    byTrack[t] = (byTrack[t] || 0) + 1;
  });
  tracks.forEach(t => {
    const el = document.getElementById('sel_' + t);
    if (el) el.textContent = byTrack[t] || 0;
  });
  document.getElementById('total_sel').textContent = sel.size;
}

document.addEventListener('DOMContentLoaded', () => {
  // restore
  document.querySelectorAll('.card input').forEach(cb => {
    if (sel.has(cb.dataset.url)) cb.checked = true;
    cb.addEventListener('change', () => {
      if (cb.checked) sel.add(cb.dataset.url);
      else sel.delete(cb.dataset.url);
      localStorage.setItem(KEY, JSON.stringify([...sel]));
      updateCounts();
    });
  });
  updateCounts();
});

function showExport() {
  const byT = {real_A:[], real_B:[], anime_main:[], anime_sub:[]};
  document.querySelectorAll('.card input:checked').forEach(cb => {
    byT[cb.dataset.track].push(cb.dataset.url);
  });
  let txt = '';
  for (const t of tracks) {
    if (byT[t].length === 0) continue;
    txt += `\\n# ${t} (${byT[t].length})\\n` + byT[t].join('\\n') + '\\n';
  }
  document.getElementById('export-txt').value = txt.trim();
  document.getElementById('export-pane').classList.add('on');
}

function copyExport() {
  const ta = document.getElementById('export-txt');
  ta.select();
  document.execCommand('copy');
  alert('已复制到剪贴板');
}

function clearAll() {
  if (!confirm('清空全部选中？')) return;
  sel.clear();
  localStorage.removeItem(KEY);
  document.querySelectorAll('.card input').forEach(cb => cb.checked = false);
  updateCounts();
}
'''

html_out = f'''<!doctype html>
<html lang="zh-CN"><head>
<meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>真人 / 动漫 视觉参考图挑选 · Emochi</title>
<style>{CSS}</style>
</head><body>
<div class="page">
<header class="top">
  <div class="row">
    <div>
      <h1>真人 / 动漫 视觉参考图挑选 · {total} 张</h1>
      <div style="font-size:12px;color:#94918a;margin-top:3px">勾选你认为符合各轨道审美的图 · 浏览器本地存储 · 不刷新不丢</div>
    </div>
    <div class="actions">
      <span style="font-size:13px;color:#6b6862">已选 <strong id="total_sel">0</strong></span>
      <button onclick="showExport()">导出选中</button>
      <button class="ghost" onclick="clearAll()">清空</button>
    </div>
  </div>
  <div class="nav">
    <a href="#real_A">真人 A · candid</a>
    <a href="#real_B">真人 B · cinematic</a>
    <a href="#anime_main">动漫主 · 暗黑美男</a>
    <a href="#anime_sub">动漫副 · 萌系女</a>
  </div>
</header>
<div class="callout">
<strong>用法</strong>：每张图左上 ✓ 是 yes / no（点图任意位置都行）。右上 ↗ 跳原图来源页。"导出选中" 按轨道分组贴给我。
<br/><strong>说明</strong>：图源自 Bing image search per 关键词，hotlink 直引第三方 CDN。部分图可能加载不出（CDN 限流或被删），那张就跳过别管。
</div>
{"".join(tracks_html)}
</div>
<div id="export-pane">
  <h3>导出选中（按轨道分组）</h3>
  <textarea id="export-txt" readonly></textarea>
  <div class="btns">
    <button class="ghost" onclick="document.getElementById('export-pane').classList.remove('on')">关闭</button>
    <button onclick="copyExport()">复制</button>
  </div>
</div>
<script>{JS}</script>
</body></html>'''

with open('/tmp/visual_refs/gallery.html', 'w', encoding='utf-8') as f:
    f.write(html_out)
import os
sz = os.path.getsize('/tmp/visual_refs/gallery.html')
print(f"HTML saved: {sz:,} bytes / {total} images")
