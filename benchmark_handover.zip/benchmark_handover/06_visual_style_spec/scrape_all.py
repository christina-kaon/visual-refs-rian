"""批量 scrape 4 轨道 → HTML gallery"""
import re, urllib.request, urllib.parse, json, html, time, sys

TRACKS = {
    'real_A': {
        'name': '真人 A · K-pop fan-edit candid',
        'subtitle': '自然光 / 软光颗粒 / 日常场景 / 无攻击性精致',
        'color': '#E8B5C2',
        'queries': [
            'NewJeans Ditto MV',
            'NewJeans Hype Boy MV scene',
            'IU Palette album photoshoot',
            'Wonyoung IVE airport candid',
            'Karina aespa private snap instagram',
            'Jungkook BTS airport candid',
            'Min Hee-jin NewJeans visual director',
            'Korean idol natural light photography portrait',
            'Olivia Rodrigo Sour album shoot',
            'Y2K aesthetic kpop girl group',
        ],
    },
    'real_B': {
        'name': '真人 B · Dark romance cinematic',
        'subtitle': '硬光大反差 / 单点 key / 雨夜霓虹 / 黑帮电影质感',
        'color': '#5A3D3D',
        'queries': [
            'Peaky Blinders Tommy Shelby still',
            'Godfather Vito Corleone cinematography',
            'Succession Roy brothers GQ photoshoot',
            'Killing Me Healing Me Ji Sung dark scene',
            'Korean mafia drama cinematic still',
            'The Weeknd After Hours music video',
            'Helmut Newton black white men',
            'John Wick noir aesthetic scene',
            'GQ Korea men cover dark',
            'Park Chan-wook Oldboy cinematography',
        ],
    },
    'anime_main': {
        'name': '动漫主轨 · 女向暗黑系美男',
        'subtitle': 'JJK / 鬼灭 / 文豪 / dark otome 美男',
        'color': '#2D3142',
        'queries': [
            'JJK Gojo Satoru hidden inventory arc',
            'Demon Slayer Muzan dark fanart',
            'Bungou Stray Dogs Dazai aesthetic',
            'Banana Fish Ash Lynx anime',
            'Black Butler Sebastian Michaelis',
            'Psycho Pass Kogami Shinya',
            'Light and Night otome game art',
            'JJK Geto Suguru fanart',
            'Devilman Crybaby art style',
            'Hakuoki otome game CG',
        ],
    },
    'anime_sub': {
        'name': '动漫副轨 · 男向萌系虚拟女角色',
        'subtitle': '京阿尼软光 / 高饱和柔色 / 校园日常 / 米哈游立绘',
        'color': '#F2D7A1',
        'queries': [
            'K-On Kyoto Animation art',
            'Bocchi the Rock anime character',
            'Lycoris Recoil Chisato Takina',
            'Genshin Impact official character art',
            'Honkai Star Rail character illustration',
            'Princess Connect Cygames art',
            'BanG Dream concert illustration',
            'Sound Euphonium Kyoto Animation',
            'Saekano Megumi character art',
            'Arknights operator illustration',
        ],
    },
}

def scrape(query, count=30):
    q = urllib.parse.quote(query)
    url = f"https://www.bing.com/images/async?q={q}&count={count}&first=0&safesearch=moderate"
    req = urllib.request.Request(url, headers={
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120.0',
    })
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            text = r.read().decode('utf-8', errors='ignore')
    except Exception as e:
        print(f"  ERR {query}: {e}", flush=True)
        return []
    items = []
    pattern = re.compile(r'm="(\{[^"]+\})"')
    seen = set()
    for m in pattern.finditer(text):
        raw = html.unescape(m.group(1))
        try:
            d = json.loads(raw)
            murl = d.get('murl', '')
            turl = d.get('turl', '')
            purl = d.get('purl', '')
            t = d.get('t', '')
            if not murl or murl in seen: continue
            if any(b in murl.lower() for b in ['xhcdn','xhamster','pornhub','xnxx','xvideos','redtube','beeg','tubegalore','adultwork','rule34','nhentai','e-hentai']):
                continue
            seen.add(murl)
            items.append({'murl': murl, 'turl': turl, 'purl': purl, 'title': t, 'q': query})
        except: continue
    return items

# 跑全部
all_results = {}
for tid, track in TRACKS.items():
    print(f"\n=== {track['name']} ===", flush=True)
    items = []
    seen = set()
    for q in track['queries']:
        new = scrape(q, 30)
        for it in new:
            if it['murl'] not in seen:
                seen.add(it['murl'])
                items.append(it)
        print(f"  {q}: +{len(new)} new (total {len(items)})", flush=True)
        time.sleep(0.5)
    all_results[tid] = items
    print(f"  TOTAL {tid}: {len(items)}", flush=True)

# 存
with open('/tmp/visual_refs/scraped.json', 'w') as f:
    json.dump(all_results, f)
print(f"\nSaved /tmp/visual_refs/scraped.json", flush=True)
print(f"Totals: {[(t, len(v)) for t, v in all_results.items()]}", flush=True)
