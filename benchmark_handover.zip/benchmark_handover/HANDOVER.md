# Emochi Benchmark + 数据画像 工作交接

**交接对象**：@duidui
**整理人**：助手（christina）
**整理日期**：2026-05-18
**周期范围**：2026-04-15 至 2026-05-18（约 5 周）

---

## TL;DR

这份交接包含两条并行工作线：

1. **离线 image benchmark 方法学 + 工具链**（`kaon-benchmark`）—— 4 维度 VLM judge 评分系统，已跑通 v2/v3/v4/v5 多版本迭代，落地到 emochi-bench 1000 条测试集 + 100 条人工校准集的方案设计
2. **emochi 用户 / bot 数据画像分析**（多份 zip 交付）—— bot 内容生态、用户性别 / 地域 / 付费、真人 vs 动漫 image style split、6 个视觉风格 sub-spec 训练 brief

最近一周（5/17-5/18）大头工作：
- 35K bot image style 分类（PG 14 天采样 → anime/realistic dominant）
- 真人 / 动漫用户画像 split + 付费率 + 留存数据
- 真人 / 动漫各分 3 类视觉风格 sub-spec brief
- 1200 张视觉参考图 gallery（让产品挑选）

---

## 目录结构

```
benchmark_handover/
├── HANDOVER.md                           # 你正在读的文档
├── 01_kaon_benchmark_code/               # 离线 benchmark 完整代码库
│   ├── README.md                         # 启动方式
│   ├── pyproject.toml                    # 依赖
│   ├── config.yaml                       # 主配置（4 维度权重 / VLM endpoint）
│   ├── config_calibration100.yaml        # 100 条校准集配置
│   ├── tag_registry.yaml                 # tag 标签字典
│   ├── prompts/                          # 6 个 VLM judge prompt YAML
│   ├── data/                             # 测试集 + 校准集 CSV
│   ├── src/kaon_benchmark/                # Python pkg 源码
│   ├── results/                          # 最近一次 full + smoke 报告
│   └── tests/
├── 02_kaon_bench_v4_prompts/             # v4 polished prompt（D1/D2/D3/D4 + global config）
├── 03_benchmark_reports/                 # 历次 benchmark report HTML + raw csv
├── 04_data_pipeline_deliveries/          # emochi 数据画像各期 zip 交付
├── 05_recent_anime_real_split/           # 5/17 真人/动漫 split 分析
│   ├── scripts/                          # 数据管线 Python script
│   └── results/                          # 关键交付 CSV
└── 06_visual_style_spec/                 # 6 个 sub-spec 训练 brief + scraper
```

---

## 项目目标 & 硬约束

### Benchmark 目标
为 emochi（roleplay 对话产品）的**剧情分镜生图**能力建 benchmark。**不是通用 T2I 质量评估** —— 面向"叙事上下文中生成角色一致的剧情插画"。

**业务锚点**：轻小说 / 漫画 / 恋与深空的插画级体验。

### 4 维度权重（Rian 拍板，不要改）

- **D1 角色一致性**：0.30
- **D2 剧情匹配**：0.30
- **D3 视觉吸引力**：0.25
- **D4 画面质量**：0.15

### Hard penalty
- D4 ≤ 3：composite 封顶 5
- D1 ≤ 3：composite 封顶 4
- 阈值待 100 条人工校准后再定（calibration 还没跑完）

### CoT 配置（DreamBench++ Table 6 实证）
- D1 / D3 / D4：CoT OFF
- D2：CoT ON

### 量表
0-4（v1.3 已统一，之前有过 0-5 / 0-100 摇摆）

### 每条 case 输入
- ref（角色参考图）+ prompt（生图 prompt）+ 前 5 轮对话（叙事上下文）

---

## 数据源（emochi 数据画像 pipeline 用）

### StarRocks 数仓（主要分析层）
- `pub-sr-fe01-shared.flow.chat:9030`
- user / password: `query_web` / `Query@SR.flowgpt!`
- T+1.5 延迟
- 关键表：
  - `ads.ads_operation_bot_metrics_di` — bot 维度 chats / shows / users + v8_primary_tag
  - `ads.ads_operation_app_bot_personas_info_di` — bot × gender × age × country × chats
  - `dws.dws_app_user_bot_daily_di` — user × bot × chat_send_count
  - `dws.dws_app_user_revenue_di` — subscribe_orders / flux_orders
  - `dws.dws_app_user_daily_profile_metrics_di` — retention_1/7/14/30

### PG 主库（生图历史源）
- `prod-1-instance-readonly.cmg2ypxvbvye.us-east-2.rds.amazonaws.com`
- 关键表：`prod.PromptImageHistory`
  - `metadata.classifierLabel` — anime / realistic image classifier label
  - `metadata.moderationLabel` — 内容审核结果
- **注意 PG read-replica recovery conflict** —— 查全量会被 kill；用 6h 窗口 LIMIT 10000 分批采样

### LLM 路由（benchmark 调 judge 用）
- `ANTHROPIC_API_KEY` + api.anthropic.com（默认，最稳定）
- `OPENROUTER_API_KEY` + openrouter.ai（Anthropic 429 fallback）
- 现在 kaon router 已部分废弃，不要写新代码用它

---

## 01 · kaon-benchmark 完整 benchmark 代码库

**起点**：完整 Python pkg，4 维度 VLM judge 评分系统。

**当前状态**：v2 → v3 → v4 → v5（gemini）迭代过，最近一次 full run 报告在 `results/report.html`，跑了 50+ test cases。

**关键文件**：
- `config.yaml` —— 主入口（VLM endpoint / 权重 / 模型选择 / penalty 阈值）
- `prompts/dim*.yaml` —— 6 个 judge prompt（D1/D2_step1/D2_step2/D3/D4 + 一个 D2 prompt-only fallback）
- `data/calibration_100_emochi.csv` —— **100 条人工校准集** ⚠️ 这是核心 anchor
- `data/test_cases.csv` —— 测试集
- `src/kaon_benchmark/`：
  - `cli.py` —— kaon-bench dry-run / probe / run 命令
  - `generator.py` —— 调被测模型生成图
  - `evaluator.py` —— 调 VLM judge 评分
  - `scorer.py` —— 4 维度加权 + hard penalty 计算
  - `reporter.py` —— 生成完整 HTML report
  - `smoke_reporter.py` —— smoke run HTML
  - `progress.py` —— resume-from-progress.jsonl
  - `anthropic_client.py` —— Anthropic API client（v3+ 加入）

**怎么跑**：
```bash
cd 01_kaon_benchmark_code
pip install -e .
export KAON_API_KEY=...
export BASELINE_API_KEY=...
export VLM_API_KEY=...
kaon-bench dry-run --config config.yaml      # 配置 sanity check
kaon-bench probe --config config.yaml         # 探活 endpoint
kaon-bench run --config config.yaml --limit 5 --smoke    # smoke 5 条
kaon-bench run --config config.yaml           # full
```

**已知未完成**：
- 100 条人工校准跑完 → 调 hard penalty 阈值（D1/D4 = 3 是预估，没 verify）
- VLM judge 替换：现在用 Claude Opus 当 judge，calibration 之后可能要换 Gemini 2.5 Pro（Rian 提过）
- D2 step1/step2 两段式调用偶尔会卡，需要 retry 机制（v4 加了部分，不完整）

---

## 02 · kaon_bench_v4 prompt 文档

`02_kaon_bench_v4_prompts/VLM_prompt/`：

- `00_global_config_polished.md` —— 全局 instruction（量表 / output format / safety / few-shot）
- `D1/D1_character_consistency_polished.md` —— 角色一致性 prompt（ref vs 生成图）
- `D2/D2_story_match_polished.md` —— 剧情匹配 prompt（prompt + 前 5 轮对话 vs 生成图）
- `D3/D3_visual_appeal_polished.md` —— 视觉吸引力 prompt
- `D4/D4_technical_quality_polished.md` —— 画面质量 prompt

**这些 .md 是 v4 的 polished 版本**，已经合到 `01_kaon_benchmark_code/prompts/dim*.yaml`。.md 留着是因为可读性更好，便于人工迭代。

---

## 03 · 历史 benchmark 报告

`03_benchmark_reports/`：

- `kaon_bench_v2_smoke样本.html` / `kaon_bench_v2_报告样本.html` —— v2 初版
- `kaon_bench_v3_报告_d2修复.html` / `kaon_bench_v3_raw_scores.csv` —— v3 D2 prompt 修复后
- `kaon_bench_v4_opus_5条.html` / `kaon_bench_v4_opus_5条_raw.csv` —— v4 用 Opus 当 judge
- `kaon_bench_v5_gemini_5条.html` / `kaon_bench_v5_gemini_5条_raw.csv` —— v5 切 Gemini 2.5 Pro judge
- `kaon_bench_calib_smoke_报告.html` / `kaon_bench_calib_smoke_细节.html` / `kaon_bench_calib_smoke_raw_scores.csv` —— 100 条 calibration set smoke
- `kaon_benchmark_v2_delivery.zip` / `kaon_benchmark_v3_delivery.zip` —— 各版本完整代码 zip 交付

**对比看版本演进**用。reproducibility 不一定可保证（数据 / API 都会变），主要看方法学迭代。

---

## 04 · emochi 数据画像 zip 交付（历史）

`04_data_pipeline_deliveries/`：

- `emochi_bot_distribution_2026-04-29_to_05-05.zip` —— bot 语言 / nsfw / tag 分布 + top200 bot
- `emochi_user_persona_2026-05-05_to_05-11.zip` —— 用户 gender / age / country × tag 分布
- `emochi_persona_split_2026-05-10_to_05-16.zip` —— anime / realistic split 用户画像粗分
- `emochi_image_style_persona_2026-05-10_to_05-16.zip` —— bot_style.tsv（35K bot classifier mapping）+ persona_by_image_style
- `emochi_image_style_full_2026-05-10_to_05-16.zip` —— style_tag × 性别 × top5 国家完整交叉 + top100 bot 明细

**还有些 standalone csv / html**：
- `emochi_chat_gen_prompt_30d.csv/html` —— 30 天 chat 生图 prompt 样本
- `emochi_chat_genimage_pg.csv/html` —— PG 主库直接拉的真人风 50 条样本
- `emochi_chat_gen_real_human*.csv/html` —— 真人风 chat 生图 prompt 大全
- `emochi_real_human_sysprompt_avatar_result*.csv/html` —— 真人 bot sysprompt + avatar + result 三元组
- `emochi_top100_3d_real_user.csv` —— 3 天真人 top100 用户
- `emochi_real_user_3d.html` / `emochi_real_user_dashboard_2026-05-06.html` —— 真人用户 dashboard
- `emochi_ip_bot_heat_2026-05-05_to_05-11.csv` —— IP bot 热度榜

---

## 05 · 最近一周 真人/动漫 split 分析

`05_recent_anime_real_split/`：

### scripts/
- `pay_analysis.py` —— 真人/动漫 用户主风格 × 付费渗透率分析
- `style_tag_analysis.py` —— image_style × v8_primary_tag 聚合
- `run.py` —— full pipeline 主入口（style × tag breakdown + top100 bot 明细）
- `consumption_profile.py` —— 用户消费深度画像（chats per user / 付费类型 / 留存 / 重度用户 lift）

### results/
- `style_tag_breakdown.csv` —— 真人/动漫 × primary_tag × 性别 × top5 country 完整交叉
- `top100_anime_bots.csv` —— top100 动漫 bot 明细
- `top100_realistic_bots.csv` —— top100 真人 bot 明细
- `style_payment.csv` —— 5 个 user bucket × 付费率
- `persona_by_image_style.csv` —— bot 风格基础统计

### 源数据（太大没放 handover，需要重跑 query 拉）
跑这些 script 需要从 StarRocks 拉的源 TSV 在我本机 `/tmp/persona_split/`：
- `bot_style.tsv` (3.3 MB, 35K bot)
- `bot_tags_all_7d.tsv` (771 MB, 14M rows)
- `all_persona_7d.tsv` (427 MB, 9M rows)
- `user_bot_chats_7d.tsv` (1.3 GB, 28M rows)
- `paying_users_7d.tsv` / `paying_detail_7d.tsv`
- `user_retention_7d.tsv` (104 MB, 3.26M rows)

**你需要的 query 在 script 里能反推**，或者我可以专门整理一份 SQL Brief 给你。

### 关键 insight（已发现的）
- 动漫风：5.01 亿 chats / 158.3 万用户 / 女 51.2% 男 37.5% / 付费率 0.72%
- 真人风：2.33 亿 chats / 69.5 万用户 / 女 65.3% 男 24.7% / 付费率 0.41%
- 动漫付费率 1.76× 真人
- top100 真人 bot 里 BTS / Jungkook / Taehyung 占 9 个，动漫 top100 完全没有 K-pop
- Mafia / Werewolf / CEO 暗黑 trope：真人 15 个 / 动漫 11 个

---

## 06 · 视觉风格 sub-spec 训练 brief

`06_visual_style_spec/`：

- `brief.html` —— **6 个 sub-spec 完整训练方案**（live URL: https://christina-kaon.github.io/visual-refs-rian/brief.html）
- `build_brief.py` —— 生成 brief 的源代码
- `build_gallery.py` —— 1200 张视觉参考 gallery 的生成代码（Bing image search scrape）
- `scrape_all.py` —— Bing async endpoint scraper
- `scraped_image_urls.json` —— 1200 张图 metadata（URL + 来源页 + 标题 + query）

### 6 个 sub-spec（P0 / P1 优先级）

**真人 model**（3 个）：
- **真人 A · 日韩氧气感 selca**（P0）—— K-pop / NewJeans / IU 自然光谱系
- **真人 B · cinematic 危险风**（P0）—— 黑帮 / mafia / dark romance，跨欧美 + 韩港
- **真人 C · 抖红 / 小红书美颜风**（P1）—— 大眼磨皮 V-line / cottage-core / 国内扩量时需要

**动漫 model**（3 个）：
- **动漫主轨 · 日乙国乙暗黑系美男**（P0）—— JJK / 鬼灭 / 文豪 / dark otome
- **动漫副轨 · KyoAni 系软光赛璐璐**（P0）—— K-On / Bocchi / 米哈游立绘
- **动漫第三类 · 国风网红动漫风**（P1）—— 光与夜之恋 / 抖音二次元同人 LoRA

### 1200 张视觉参考 gallery
Live URL: https://christina-kaon.github.io/visual-refs-rian/
- 4 轨道 × 10 query × 30 张 = 1200
- 浏览器内 checkbox + LocalStorage + 导出选中
- Rian 在挑（5/17 发的，还没收到回执）

---

## 已知未完成 / 接棒后建议下一步

### Benchmark 工作
1. **100 条人工校准集还没跑完** —— `data/calibration_100_emochi.csv` 是核心 anchor，跑完之后才能定 hard penalty 阈值。需要协调李承燕做人工标注。
2. **judge 模型选型未决** —— v4 用 Opus，v5 实验了 Gemini 2.5 Pro，目前没结论用哪个做 production
3. **D2 两段式 prompt 偶发卡死** —— v4 加了部分 retry，需要完善
4. **emochi-bench 历史 Pearson**：D1 0.85 / D3 0.18 / D4 0.07（D2 还没正式校准过）

### 数据画像
1. **动漫第三类（国风网红动漫风）的视觉参考图没爬过** —— gallery 现在只有 4 轨道，要补第 5 轨
2. **prompt keyword × 地域分布 verify P1 优先级** —— Rian 还没确认要不要跑，建议做完再定 P1 是否提前
3. **6 个 sub-spec 的 cross-medium grammar 共享** —— brief 里写了理论，可以做 visual eval rubric 标准化（哪些 dimension 跨真人/动漫共享）

### 视觉风格 brief
- Rian 还没 review 反馈（5/18 12:13 发的，4 小时前）
- 等她 push back 后调整反锚点 / 锚点 / 优先级
- 翻英文版 forward 海外训练团队（如果要）

---

## 联系 / 问题

我的工作时间表 + 上下文都在 `oc_e9fe9476be9f1f885f36153c4de939a5` 群（emochi 主群）。如果你接手后有问题，直接在群里 @ 我或者 @Rian。

特别复杂的数据 query / 历史决策背景，建议先翻群聊（关键决策都在群里）。

— 助手 / Christina
2026-05-18
